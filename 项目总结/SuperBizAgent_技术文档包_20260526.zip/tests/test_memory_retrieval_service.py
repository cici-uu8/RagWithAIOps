import json
import tempfile
import unittest
from pathlib import Path

from app.models.memory import MemoryRecord, MemoryStatus
from app.services.memory_retrieval_service import MemoryRetrievalQuery, MemoryRetrievalService
from app.services.memory_store import MemoryStore


FIXTURE_PATH = Path(__file__).parent / "fixtures" / "memory_synthetic" / "p1_memory_records.json"
P2_LEXICAL_FIXTURE_PATH = (
    Path(__file__).parent / "fixtures" / "memory_synthetic" / "p2_lexical_recall_cases.json"
)


class MemoryRetrievalServiceTests(unittest.TestCase):
    def _build_store(self, tmpdir: str) -> MemoryStore:
        store = MemoryStore(Path(tmpdir) / "memory.sqlite3")
        for payload in json.loads(FIXTURE_PATH.read_text(encoding="utf-8")):
            store.upsert(MemoryRecord.model_validate(payload))

        deprecated = MemoryRecord.model_validate(
            {
                **json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))[0],
                "memory_id": "mem_alert_deprecated",
                "status": "deprecated",
                "summary": "Deprecated memory usage alert should never be returned",
            }
        )
        store.upsert(deprecated)
        return store

    def test_retrieves_active_alert_pattern_by_synonym_query(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            service = MemoryRetrievalService(self._build_store(tmpdir))

            response = service.retrieve(
                MemoryRetrievalQuery(
                    query="OOM 之后怎么排查",
                    namespaces=["memory://oncall/alert-patterns"],
                    memory_types=["alert_pattern"],
                    top_k=3,
                )
            )

            self.assertEqual([result.memory_id for result in response.memory_results], ["mem_alert_high_memory"])
            self.assertEqual(response.memory_results[0].memory_type, "alert_pattern")
            self.assertEqual(response.memory_results[0].status, MemoryStatus.ACTIVE)
            self.assertGreater(response.memory_results[0].score, 0)
            self.assertIn("oom", response.memory_results[0].matched_terms)
            self.assertEqual(response.trace["candidate_count"], 1)

    def test_ignores_candidate_and_deprecated_records_by_default(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            service = MemoryRetrievalService(self._build_store(tmpdir))

            response = service.retrieve(
                MemoryRetrievalQuery(
                    query="SlowResponse plan metrics logs dependency rollout",
                    namespaces=["memory://oncall/plan-templates"],
                    memory_types=["plan_template"],
                    top_k=3,
                )
            )

            self.assertEqual(response.memory_results, [])
            self.assertEqual(response.empty_message, "No active memory matched the query.")
            self.assertEqual(response.trace["candidate_count"], 0)

    def test_owner_namespace_and_type_filters_are_applied_before_ranking(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = self._build_store(tmpdir)
            other_owner = MemoryRecord.model_validate(
                {
                    **json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))[0],
                    "memory_id": "mem_alert_other_owner",
                    "owner_id": "team-b",
                    "summary": "OOM memory usage other owner",
                }
            )
            store.upsert(other_owner)
            service = MemoryRetrievalService(store)

            response = service.retrieve(
                MemoryRetrievalQuery(
                    query="OOM memory usage",
                    owner_id="team-b",
                    namespaces=["memory://oncall/alert-patterns"],
                    memory_types=["alert_pattern"],
                    top_k=3,
                )
            )

            self.assertEqual([result.memory_id for result in response.memory_results], ["mem_alert_other_owner"])
            self.assertEqual(response.trace["candidate_count"], 1)

    def test_returns_independent_memory_results_not_rag_citations(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            service = MemoryRetrievalService(self._build_store(tmpdir))

            response = service.retrieve(
                MemoryRetrievalQuery(
                    query="中文 简洁 证据边界",
                    namespaces=["memory://runtime/user-preferences"],
                    memory_types=["preference"],
                    top_k=1,
                )
            )

            result_payload = response.memory_results[0].model_dump()
            self.assertIn("evidence_refs", result_payload)
            self.assertNotIn("source_ref", result_payload)
            self.assertNotIn("citation_text", result_payload)
            self.assertEqual(response.namespaces, ["memory://runtime/user-preferences"])
            self.assertEqual(response.memory_types, ["preference"])

    def test_p2_lexical_recall_gate_meets_frozen_threshold(self):
        fixture = json.loads(P2_LEXICAL_FIXTURE_PATH.read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as tmpdir:
            store = MemoryStore(Path(tmpdir) / "memory.sqlite3")
            for payload in fixture["records"]:
                store.upsert(MemoryRecord.model_validate(payload))
            service = MemoryRetrievalService(store)

            passed = 0
            for case in fixture["queries"]:
                response = service.retrieve(
                    MemoryRetrievalQuery(
                        query=case["query"],
                        namespaces=["memory://oncall/alert-patterns"],
                        memory_types=["alert_pattern"],
                        top_k=1,
                    )
                )
                actual_memory_id = response.memory_results[0].memory_id if response.memory_results else None
                if actual_memory_id == case["expected_memory_id"]:
                    passed += 1

            self.assertEqual(len(fixture["queries"]), fixture["threshold"]["total_queries"])
            self.assertGreaterEqual(passed, fixture["threshold"]["min_expected_hits"])


if __name__ == "__main__":
    unittest.main()
