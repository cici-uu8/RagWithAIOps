"""
P5 Shadow Mode Tests

验证:
- MemoryMode.from_state() 正确解析 state
- memory_mode=off 不召回 memory
- memory_mode=shadow 召回但不注入 prompt
- memory_mode=active 召回且注入 prompt
- shadow mode 生成 trace 文件
- 兼容旧的 enable_memory_guidance flag
"""

import unittest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch, mock_open
from pathlib import Path

from app.agent.aiops.planner import planner, Plan
from app.models.memory import MemoryType, MemoryStatus
from app.models.memory_mode import MemoryMode
from app.services.memory_retrieval_service import (
    MemoryRetrievalResponse,
    MemoryRetrievalResult,
)


class TestMemoryMode(unittest.TestCase):
    """Test MemoryMode enum"""

    def test_from_state_explicit_off(self):
        """显式设置 memory_mode=off"""
        state = {"memory_mode": "off"}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.OFF)

    def test_from_state_explicit_shadow(self):
        """显式设置 memory_mode=shadow"""
        state = {"memory_mode": "shadow"}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.SHADOW)

    def test_from_state_explicit_active(self):
        """显式设置 memory_mode=active"""
        state = {"memory_mode": "active"}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.ACTIVE)

    def test_from_state_invalid_fallback_to_off(self):
        """无效值 fallback 到 OFF"""
        state = {"memory_mode": "invalid"}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.OFF)

    def test_from_state_legacy_enable_memory_guidance_true(self):
        """兼容旧的 enable_memory_guidance=True"""
        state = {"enable_memory_guidance": True}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.ACTIVE)

    def test_from_state_legacy_enable_memory_guidance_false(self):
        """兼容旧的 enable_memory_guidance=False"""
        state = {"enable_memory_guidance": False}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.OFF)

    def test_from_state_default_off(self):
        """默认 OFF"""
        state = {}
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.OFF)

    def test_from_state_explicit_overrides_legacy(self):
        """显式 memory_mode 优先于 enable_memory_guidance"""
        state = {
            "memory_mode": "shadow",
            "enable_memory_guidance": True
        }
        mode = MemoryMode.from_state(state)
        self.assertEqual(mode, MemoryMode.SHADOW)


class TestP5ShadowMode(unittest.IsolatedAsyncioTestCase):
    """Test P5 shadow mode integration"""

    def _create_mock_memory_response(self):
        """创建 mock memory response"""
        return MemoryRetrievalResponse(
            query="CPUHigh alert on service-a",
            owner_id="test-owner",
            namespaces=["memory://oncall/alert-patterns"],
            memory_types=[MemoryType.ALERT_PATTERN],
            memory_results=[
                MemoryRetrievalResult(
                    memory_id="mem_001",
                    owner_id="test-owner",
                    namespace="memory://oncall/alert-patterns",
                    memory_type=MemoryType.ALERT_PATTERN,
                    status=MemoryStatus.ACTIVE,
                    content="CPUHigh pattern",
                    summary="CPU high pattern",
                    score=0.95,
                    matched_terms=["CPUHigh"],
                    evidence_refs=[{"session_id": "sess_001"}],
                    payload={"alert_name": "CPUHigh", "root_cause": "memory leak"},
                    source="test",
                    tags=[],
                    updated_at=datetime.now(timezone.utc),
                )
            ],
            empty_message="",
            trace={"lexical_hits": 1},
        )

    async def test_memory_mode_off_no_retrieval(self):
        """memory_mode=off 不召回 memory"""
        state = {
            "input": "CPUHigh alert on service-a",
            "memory_mode": "off",
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service:

            mock_retrieve.ainvoke = AsyncMock(return_value="")
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(return_value=Plan(steps=["step1"]))
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 MemoryRetrievalService 未被调用
            mock_memory_service.assert_not_called()

            # 验证返回了计划，但没有 memory_observation
            self.assertIn("plan", result)
            self.assertNotIn("memory_observation", result)

    async def test_memory_mode_shadow_retrieves_but_not_inject(self):
        """memory_mode=shadow 召回但不注入 prompt"""
        state = {
            "input": "CPUHigh alert on service-a",
            "memory_mode": "shadow",
            "memory_owner_id": "test-owner",
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service, \
             patch("app.agent.aiops.planner.MemoryTraceService") as mock_trace_service:

            mock_retrieve.ainvoke = AsyncMock(return_value="")
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock memory service
            mock_memory_instance = MagicMock()
            mock_memory_instance.retrieve.return_value = self._create_mock_memory_response()
            mock_memory_service.return_value = mock_memory_instance

            # Mock trace service
            mock_trace_instance = MagicMock()
            mock_trace_instance.create_observation.return_value = {
                "mode": "shadow",
                "trace_id": "mem_trace_test",
                "hit_count": 1,
                "memory_ids": ["mem_001"],
                "would_inject": False,
                "full_text_path": "traces/memory/mem_trace_test.txt"
            }
            mock_trace_service.return_value = mock_trace_instance

            # Mock planner chain - 捕获传入的 experience_context
            captured_context = None

            async def capture_ainvoke(args):
                nonlocal captured_context
                captured_context = args.get("experience_context", "")
                return Plan(steps=["step1"])

            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(side_effect=capture_ainvoke)
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 memory 被召回
            mock_memory_service.assert_called_once()
            mock_memory_instance.retrieve.assert_called_once()

            # 验证 trace 被创建
            mock_trace_instance.create_observation.assert_called_once()
            call_kwargs = mock_trace_instance.create_observation.call_args[1]
            self.assertEqual(call_kwargs["mode"], MemoryMode.SHADOW)

            # 验证返回了 memory_observation
            self.assertIn("memory_observation", result)
            self.assertEqual(result["memory_observation"]["mode"], "shadow")
            self.assertFalse(result["memory_observation"]["would_inject"])

            # 验证 memory guidance 没有注入 prompt
            # captured_context 应该不包含 "运行时记忆指导"
            self.assertNotIn("运行时记忆指导", captured_context)

    async def test_memory_mode_active_retrieves_and_injects(self):
        """memory_mode=active 召回且注入 prompt"""
        state = {
            "input": "CPUHigh alert on service-a",
            "memory_mode": "active",
            "memory_owner_id": "test-owner",
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service, \
             patch("app.agent.aiops.planner.MemoryTraceService") as mock_trace_service:

            mock_retrieve.ainvoke = AsyncMock(return_value="")
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock memory service
            mock_memory_instance = MagicMock()
            mock_memory_instance.retrieve.return_value = self._create_mock_memory_response()
            mock_memory_service.return_value = mock_memory_instance

            # Mock trace service
            mock_trace_instance = MagicMock()
            mock_trace_instance.create_observation.return_value = {
                "mode": "active",
                "trace_id": "mem_trace_test",
                "hit_count": 1,
                "memory_ids": ["mem_001"],
                "would_inject": True,
            }
            mock_trace_service.return_value = mock_trace_instance

            # Mock planner chain - 捕获传入的 experience_context
            captured_context = None

            async def capture_ainvoke(args):
                nonlocal captured_context
                captured_context = args.get("experience_context", "")
                return Plan(steps=["step1"])

            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(side_effect=capture_ainvoke)
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 memory 被召回
            mock_memory_service.assert_called_once()

            # 验证 trace 被创建
            mock_trace_instance.create_observation.assert_called_once()
            call_kwargs = mock_trace_instance.create_observation.call_args[1]
            self.assertEqual(call_kwargs["mode"], MemoryMode.ACTIVE)

            # 验证返回了 memory_observation
            self.assertIn("memory_observation", result)
            self.assertEqual(result["memory_observation"]["mode"], "active")
            self.assertTrue(result["memory_observation"]["would_inject"])

            # 验证 memory guidance 注入了 prompt
            # captured_context 应该包含 "运行时记忆指导"
            self.assertIn("运行时记忆指导", captured_context)


if __name__ == "__main__":
    unittest.main()
