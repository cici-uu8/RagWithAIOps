"""
P5 planner memory integration tests

验证:
- memory guidance 默认关闭
- enable_memory_guidance=True 时才查询 memory
- memory guidance 和 document context 正确合并
- memory 召回失败不影响主流程
"""

import unittest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

from app.agent.aiops.planner import planner, Plan
from app.models.memory import MemoryType, MemoryStatus
from app.services.memory_retrieval_service import (
    MemoryRetrievalResponse,
    MemoryRetrievalResult,
)


class TestP5PlannerMemoryIntegration(unittest.IsolatedAsyncioTestCase):
    """Test P5 planner memory integration"""

    async def test_memory_guidance_disabled_by_default(self):
        """P5 memory guidance 默认关闭"""
        state = {
            "input": "CPUHigh alert on service-a",
            # enable_memory_guidance 未设置，默认 False
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service:

            # Mock retrieve_knowledge
            mock_retrieve.ainvoke = AsyncMock(return_value="")

            # Mock MCP client
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock planner_prompt pipe chain
            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(return_value=Plan(steps=["step1", "step2"]))
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 MemoryRetrievalService 未被调用
            mock_memory_service.assert_not_called()

            # 验证返回了计划
            self.assertIn("plan", result)
            self.assertIsInstance(result["plan"], list)
            self.assertEqual(result["plan"], ["step1", "step2"])

    async def test_memory_guidance_enabled_queries_memory(self):
        """enable_memory_guidance=True 时查询 memory"""
        state = {
            "input": "CPUHigh alert on service-a",
            "enable_memory_guidance": True,
            "memory_owner_id": "test-owner",
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service:

            # Mock retrieve_knowledge
            mock_retrieve.ainvoke = AsyncMock(return_value="")

            # Mock MCP client
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock memory service
            mock_memory_instance = MagicMock()
            mock_memory_response = MemoryRetrievalResponse(
                query="CPUHigh alert on service-a",
                owner_id="test-owner",
                namespaces=["memory://oncall/alert-patterns"],
                memory_types=[MemoryType.ALERT_PATTERN],
                memory_results=[
                    MemoryRetrievalResult(
                        memory_id="mem_001",
                        owner_id="test-owner",
                        namespace="memory://oncall/alert-patterns",
                        memory_type=MemoryType.ALERT_PATTERN,
                        status=MemoryStatus.ACTIVE,
                        content="CPUHigh pattern",
                        summary="CPU high pattern",
                        score=0.95,
                        matched_terms=["CPUHigh"],
                        evidence_refs=[{"session_id": "sess_001"}],
                        payload={"alert_name": "CPUHigh", "root_cause": "memory leak"},
                        source="test",
                        tags=[],
                        updated_at=datetime.now(timezone.utc),
                    )
                ],
                empty_message="",
                trace={"lexical_hits": 1},
            )
            mock_memory_instance.retrieve.return_value = mock_memory_response
            mock_memory_service.return_value = mock_memory_instance

            # Mock planner_prompt pipe chain
            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(return_value=Plan(steps=["step1", "step2"]))
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 MemoryRetrievalService 被调用
            mock_memory_service.assert_called_once()
            mock_memory_instance.retrieve.assert_called_once()

            # 验证 query 参数
            call_args = mock_memory_instance.retrieve.call_args[0][0]
            self.assertEqual(call_args.query, "CPUHigh alert on service-a")
            self.assertEqual(call_args.owner_id, "test-owner")
            self.assertIn("memory://oncall/alert-patterns", call_args.namespaces)
            self.assertIn("memory://oncall/plan-templates", call_args.namespaces)

            # 验证返回了计划
            self.assertIn("plan", result)
            self.assertEqual(result["plan"], ["step1", "step2"])

    async def test_memory_guidance_failure_does_not_break_planner(self):
        """memory 召回失败不影响主流程"""
        state = {
            "input": "CPUHigh alert",
            "enable_memory_guidance": True,
        }

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service:

            # Mock retrieve_knowledge
            mock_retrieve.ainvoke = AsyncMock(return_value="doc context")

            # Mock MCP client
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock memory service to raise exception
            mock_memory_service.side_effect = Exception("memory store unavailable")

            # Mock planner_prompt pipe chain
            mock_chain = MagicMock()
            mock_chain.ainvoke = AsyncMock(return_value=Plan(steps=["step1"]))
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            # 应该不抛异常
            result = await planner(state)

            # 验证仍然返回了计划
            self.assertIn("plan", result)
            self.assertIsInstance(result["plan"], list)
            self.assertGreater(len(result["plan"]), 0)
            self.assertEqual(result["plan"], ["step1"])

    async def test_memory_guidance_combined_with_document_context(self):
        """memory guidance 和 document context 正确合并"""
        state = {
            "input": "DiskHigh alert",
            "enable_memory_guidance": True,
        }

        captured_context = None

        with patch("app.agent.aiops.planner.retrieve_knowledge") as mock_retrieve, \
             patch("app.agent.aiops.planner.get_mcp_client_with_retry") as mock_mcp, \
             patch("app.agent.aiops.planner.planner_prompt") as mock_prompt, \
             patch("app.agent.aiops.planner.MemoryRetrievalService") as mock_memory_service:

            # Mock retrieve_knowledge 返回文档上下文
            mock_retrieve.ainvoke = AsyncMock(return_value="Document: check disk usage")

            # Mock MCP client
            mock_mcp_instance = AsyncMock()
            mock_mcp_instance.get_tools = AsyncMock(return_value=[])
            mock_mcp.return_value = mock_mcp_instance

            # Mock memory service 返回 memory guidance
            mock_memory_instance = MagicMock()
            mock_memory_response = MemoryRetrievalResponse(
                query="DiskHigh alert",
                owner_id="default",
                namespaces=["memory://oncall/plan-templates"],
                memory_types=[MemoryType.PLAN_TEMPLATE],
                memory_results=[
                    MemoryRetrievalResult(
                        memory_id="mem_plan_001",
                        owner_id="default",
                        namespace="memory://oncall/plan-templates",
                        memory_type=MemoryType.PLAN_TEMPLATE,
                        status=MemoryStatus.ACTIVE,
                        content="Disk alert plan",
                        summary="Disk investigation",
                        score=0.90,
                        matched_terms=["DiskHigh"],
                        evidence_refs=[],
                        payload={"alert_type": "DiskHigh", "plan_steps": ["check mount"]},
                        source="test",
                        tags=[],
                        updated_at=datetime.now(timezone.utc),
                    )
                ],
                empty_message="",
                trace={},
            )
            mock_memory_instance.retrieve.return_value = mock_memory_response
            mock_memory_service.return_value = mock_memory_instance

            # Mock planner_prompt pipe chain，捕获传入的 experience_context
            mock_chain = MagicMock()

            async def capture_ainvoke(args):
                nonlocal captured_context
                captured_context = args.get("experience_context", "")
                return Plan(steps=["step1"])

            mock_chain.ainvoke = capture_ainvoke
            mock_prompt.__or__ = MagicMock(return_value=mock_chain)

            result = await planner(state)

            # 验证 experience_context 包含 memory guidance 和 document context
            self.assertIsNotNone(captured_context)
            self.assertIn("运行时记忆指导", captured_context)  # memory guidance
            self.assertIn("相关经验文档", captured_context)  # document context
            self.assertIn("check disk usage", captured_context)  # document content

            # 验证 memory 在 document 之前
            memory_pos = captured_context.find("运行时记忆指导")
            doc_pos = captured_context.find("相关经验文档")
            self.assertLess(memory_pos, doc_pos)


if __name__ == "__main__":
    unittest.main()
