"""文件上传接口模块"""

from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from app.services.document_ingestion_service import DocumentIngestionService
from app.services.document_processing_queue import document_processing_queue
from app.services.knowledge_metadata_store import knowledge_metadata_store
from loguru import logger

router = APIRouter()

# 文件上传后存储的路径
UPLOAD_DIR = Path("./uploads")
# 单个文件支持最大大小
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
document_ingestion_service = DocumentIngestionService(upload_root=UPLOAD_DIR)


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    kb_id: str = Form(...),
):
    """
    上传文件并自动创建向量索引

    Args:
        file: 上传的文件
        kb_id: 目标知识库 id (required, per §10(b) 2026-05-20 decision —
            production callers must declare the target KB explicitly;
            no implicit "default" fallback at this boundary)

    Returns:
        JSONResponse: 上传结果
    """
    try:
        # 1. 验证请求文件本身；kb_id / 文件名规范化 / parser 路由由 ingestion 层统一负责。
        if not file.filename:
            raise HTTPException(status_code=400, detail="文件名不能为空")

        # 2. 读取文件内容
        content = await file.read()

        # 验证文件大小
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail=f"文件大小超过限制（最大 {MAX_FILE_SIZE} 字节）")

        # 3. 进入正式接入工作流。
        document_record = document_ingestion_service.ingest_upload(
            filename=file.filename,
            content=content,
            kb_id=kb_id,
        )
        status_evidence = document_record.status_evidence or {}
        processing_job_id = status_evidence.get("processing_job_id")
        processing_queue = status_evidence.get("processing_queue")
        logger.info(
            "文件上传成功并进入正式接入链路: doc_id={}, status={}, path={}",
            document_record.doc_id,
            document_record.status,
            document_record.original_path,
        )

        # 4. 返回响应
        response_data = {
            "filename": document_record.file_name,
            "file_path": document_record.original_path,
            "size": len(content),
            "doc_id": document_record.doc_id,
            "parser_engine": document_record.parser_engine.value,
            "status": document_record.status.value,
            "artifact_dir": document_record.artifact_dir,
            "async_processing": processing_job_id is not None,
        }
        if processing_job_id is not None:
            response_data["processing_job_id"] = processing_job_id
            response_data["processing_queue"] = processing_queue

        return JSONResponse(
            status_code=200,
            content={
                "code": 200,
                "message": "success",
                "data": response_data,
            },
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"文件上传请求无效: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"文件上传失败: {e}")
        raise HTTPException(status_code=500, detail=f"文件上传失败: {e}")


@router.get("/documents/{doc_id}")
async def get_document_status(doc_id: str):
    """查询异步文档处理状态。"""
    document_record = knowledge_metadata_store.get_document(doc_id)
    if document_record is None:
        raise HTTPException(status_code=404, detail=f"文档不存在: {doc_id}")

    confirmed_at = document_record.status_confirmed_at
    return JSONResponse(
        status_code=200,
        content={
            "code": 200,
            "message": "success",
            "data": {
                "doc_id": document_record.doc_id,
                "kb_id": document_record.kb_id,
                "filename": document_record.file_name,
                "parser_engine": document_record.parser_engine.value,
                "status": document_record.status.value,
                "status_detail": document_record.status_detail,
                "status_source": document_record.status_source,
                "status_evidence": document_record.status_evidence,
                "status_confirmed_at": confirmed_at.isoformat() if confirmed_at else None,
                "error_message": document_record.error_message,
                "artifact_dir": document_record.artifact_dir,
            },
        },
    )


@router.post("/index_directory")
async def index_directory(
    directory_path: str = Form(None),
    kb_id: str = Form(...),
):
    """
    索引指定目录下的所有文件

    Args:
        directory_path: 目录路径（可选，默认使用 uploads 目录）
        kb_id: 目标知识库 id

    Returns:
        JSONResponse: 批量索引任务引用
    """
    try:
        target_path = directory_path or str(UPLOAD_DIR)
        logger.info(f"投递目录批量索引任务: {target_path}, kb_id={kb_id}")

        job_ref = document_processing_queue.enqueue_directory_index_batch(
            target_path,
            kb_id=kb_id,
        )

        return JSONResponse(
            status_code=200,
            content={
                "code": 200,
                "message": "accepted",
                "data": {
                    "async_processing": True,
                    "batch_job_id": job_ref.job_id,
                    "processing_queue": job_ref.queue_name,
                    "directory_path": job_ref.directory_path,
                    "kb_id": job_ref.kb_id,
                },
            },
        )

    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"目录批量索引请求无效: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"目录批量索引任务投递失败: {e}")
        raise HTTPException(status_code=500, detail=f"目录批量索引任务投递失败: {e}")
