"""配置管理模块

使用 Pydantic Settings 实现类型安全的配置管理
"""

from typing import Dict, Any
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """应用配置"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # 应用配置
    app_name: str = "SuperBizAgent"
    app_version: str = "1.0.0"
    debug: bool = False
    host: str = "0.0.0.0"
    port: int = 9900

    # DashScope 配置
    dashscope_api_key: str = ""  # 默认空字符串，实际使用需从环境变量加载
    dashscope_api_base: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    dashscope_model: str = "qwen-max"
    dashscope_embedding_model: str = "text-embedding-v4"  # v4 支持多种维度（默认 1024）

    # Milvus 配置
    milvus_uri: str = ""
    milvus_host: str = "localhost"
    milvus_port: int = 19530
    milvus_timeout: int = 10000  # 毫秒

    # RAG 配置
    rag_top_k: int = 3
    rag_model: str = "qwen-max"  # 使用快速响应模型，不带扩展思考
    rerank_enabled: bool = False
    rerank_model: str = "local_lexical_v1"
    rerank_timeout_ms: int = 2000
    rerank_top_k: int = 10
    rerank_fallback_on_error: bool = True

    # 文档分块配置
    chunk_max_size: int = 800
    chunk_overlap: int = 100

    # P5 Shadow Mode 配置
    memory_shadow_allowlist: str = ""  # 逗号分隔的 owner_id 白名单，例如 "user1,user2"
    memory_shadow_sampling_rate: float = 0.0  # 采样率 (0.0 - 1.0)，默认 0% 不开启

    # MinerU 解析配置
    mineru_cli_path: str = "/Users/cici/oncall agent/pdf_eval/env/.venv/bin/mineru"
    mineru_api_url: str = ""
    mineru_method: str = "auto"
    mineru_backend: str = "pipeline"
    mineru_language: str = "ch"
    mineru_enable_formula: bool = True
    mineru_enable_table: bool = True
    mineru_mplconfigdir: str = "/private/tmp/mpl"
    mineru_postprocess_script_path: str = "/Users/cici/oncall agent/pdf_eval/scripts/mineru_postprocess.py"

    # 异步文档处理队列配置
    document_processing_redis_url: str = "redis://localhost:6379/0"
    document_processing_queue_name: str = "document_processing"
    document_processing_job_timeout_seconds: int = 1800
    document_processing_result_ttl_seconds: int = 86400
    document_processing_failure_ttl_seconds: int = 604800

    # MCP 服务配置
    mcp_cls_transport: str = "streamable-http"
    mcp_cls_url: str = "http://localhost:8003/mcp"
    mcp_monitor_transport: str = "streamable-http"
    mcp_monitor_url: str = "http://localhost:8004/mcp"

    @property
    def mcp_servers(self) -> Dict[str, Dict[str, Any]]:
        """获取完整的 MCP 服务器配置"""
        return {
            "cls": {
                "transport": self.mcp_cls_transport,
                "url": self.mcp_cls_url,
            },
            "monitor": {
                "transport": self.mcp_monitor_transport,
                "url": self.mcp_monitor_url,
            }
        }


# 全局配置实例
config = Settings()
