"""
通用 Plan-Execute-Replan 状态定义
基于 LangGraph 官方教程实现
"""

from typing import List, TypedDict, Annotated, Optional, Dict, Any
import operator


class PlanExecuteState(TypedDict, total=False):
    """Plan-Execute-Replan 状态"""

    # 用户输入（任务描述）
    input: str

    # 执行计划（步骤列表）
    plan: List[str]

    # 已执行的步骤历史
    # 使用 operator.add 实现追加式更新（而非覆盖）
    past_steps: Annotated[List[tuple], operator.add]

    # 最终响应/报告
    response: str

    # P5 memory guidance 相关字段
    # memory_mode: "off" | "shadow" | "active" (默认 "off")
    memory_mode: Optional[str]

    # 兼容旧 API 的 bool flag (优先级低于 memory_mode)
    enable_memory_guidance: Optional[bool]

    # Memory owner ID
    memory_owner_id: Optional[str]

    # Memory observation trace (planner 返回)
    memory_observation: Optional[Dict[str, Any]]
