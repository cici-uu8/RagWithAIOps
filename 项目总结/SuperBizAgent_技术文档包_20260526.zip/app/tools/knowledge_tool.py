"""知识检索工具 - 从向量数据库中检索相关信息"""

from typing import Any, Dict, List, Optional, Tuple

from langchain_core.tools import tool
from loguru import logger

from app.config import config
from app.models import RetrievalQuery
from app.services.retrieval_service import retrieval_service


@tool(response_format="content_and_artifact")
def retrieve_knowledge(
    query: str,
    knowledge_base_ids: Optional[List[str]] = None,
) -> Tuple[str, Dict[str, Any]]:
    """从知识库中检索相关信息来回答问题

    当用户的问题涉及专业知识、文档内容或需要参考资料时，使用此工具。

    Args:
        query: 用户的问题或查询
        knowledge_base_ids: Optional list of knowledge base IDs to scope the
            retrieval. When None or empty, searches across all KBs (default
            behavior). Per §10(b) decision (2026-05-20), production KBs are
            split by knowledge type (e.g. "aiops" vs "manuals"); pass the
            relevant kb_id list when the question is scoped to a particular
            domain.

    Returns:
        Tuple[str, Dict[str, Any]]: (格式化的上下文文本, 结构化检索 artifact)
    """
    try:
        kb_ids = list(knowledge_base_ids) if knowledge_base_ids else []
        logger.info(
            "知识检索工具被调用: query='{}', kb_ids={}",
            query,
            kb_ids if kb_ids else "<all>",
        )
        response = retrieval_service.retrieve(
            RetrievalQuery(
                query=query,
                top_k=config.rag_top_k,
                knowledge_base_ids=kb_ids,
            )
        )
        logger.info("检索到 {} 个相关文档", len(response.results))
        artifact = response.model_dump(mode="json")
        artifact["query"] = RetrievalQuery(
            query=query,
            top_k=response.query.top_k,
            knowledge_base_ids=list(response.query.knowledge_base_ids),
        ).model_dump(mode="json")
        for result in artifact.get("results", []):
            source_ref = result.get("source_ref")
            if isinstance(source_ref, dict):
                source_ref["kb_id"] = result.get("kb_id", source_ref.get("kb_id", ""))
                source_ref["doc_id"] = result.get("doc_id", source_ref.get("doc_id", ""))
                source_ref["chunk_id"] = result.get("chunk_id", source_ref.get("chunk_id", ""))
        return response.context_text, artifact
    except Exception as e:
        logger.error("知识检索工具调用失败: {}", e)
        error_message = f"检索知识时发生错误: {str(e)}"
        return error_message, {
            "query": RetrievalQuery(
                query=query,
                top_k=config.rag_top_k,
                knowledge_base_ids=list(knowledge_base_ids) if knowledge_base_ids else [],
            ).model_dump(mode="json"),
            "results": [],
            "context_text": error_message,
            "empty_message": error_message,
        }
