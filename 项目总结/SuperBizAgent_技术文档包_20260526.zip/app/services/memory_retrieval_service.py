"""Sidecar lexical retrieval for durable oncall memory records."""

from __future__ import annotations

import json
import re
import time
from datetime import datetime
from typing import Any, Dict, List

from pydantic import BaseModel, Field, field_validator, model_validator

from app.models.memory import MemoryRecord, MemoryStatus, MemoryType
from app.services.memory_store import MemoryStore, memory_store


class MemoryRetrievalQuery(BaseModel):
    """Query shape for sidecar memory retrieval."""

    query: str = Field(..., description="Natural-language memory lookup query")
    owner_id: str = Field("default", description="Tenant/user/team memory owner")
    namespaces: List[str] = Field(default_factory=list, description="Optional namespace filters")
    memory_types: List[MemoryType] = Field(default_factory=list, description="Optional memory type filters")
    top_k: int = Field(3, description="Maximum number of memory records to return")

    @field_validator("query", "owner_id")
    @classmethod
    def _require_non_empty_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("value is required")
        return value

    @model_validator(mode="after")
    def _validate_limits(self) -> "MemoryRetrievalQuery":
        if self.top_k <= 0:
            raise ValueError("top_k must be positive")
        return self


class MemoryRetrievalResult(BaseModel):
    """Independent memory hit result, intentionally not a RAG citation DTO."""

    memory_id: str
    owner_id: str
    namespace: str
    memory_type: MemoryType
    status: MemoryStatus
    content: str
    summary: str
    score: float
    matched_terms: List[str] = Field(default_factory=list)
    evidence_refs: List[Dict[str, Any]] = Field(default_factory=list)
    payload: Dict[str, Any] = Field(default_factory=dict)
    source: str
    tags: List[str] = Field(default_factory=list)
    updated_at: datetime


class MemoryRetrievalResponse(BaseModel):
    """Sidecar memory retrieval response."""

    query: str
    owner_id: str
    namespaces: List[str] = Field(default_factory=list)
    memory_types: List[MemoryType] = Field(default_factory=list)
    memory_results: List[MemoryRetrievalResult] = Field(default_factory=list)
    empty_message: str
    trace: Dict[str, Any] = Field(default_factory=dict)


class MemoryRetrievalService:
    """Retrieve active durable memory without touching document RAG retrieval."""

    EMPTY_MESSAGE = "No active memory matched the query."

    _SYNONYMS: Dict[str, List[str]] = {
        "中文": ["chinese"],
        "简洁": ["concise"],
        "证据边界": ["evidence boundary", "evidence boundaries", "evidence from hypotheses"],
        "证据": ["evidence"],
        "边界": ["boundary", "boundaries"],
        "排查": ["diagnosis", "diagnose", "inspect"],
        "告警": ["alert"],
        "内存": ["memory"],
        "oom": ["outofmemoryerror", "oom_kill", "out of memory"],
        "利用率": ["usage"],
        "使用率": ["usage"],
        "处理器": ["cpu"],
        "负载": ["load"],
        "过高": ["high"],
        "飙高": ["spike", "high"],
        "飙升": ["spike", "high"],
        "计算资源打满": ["cpu", "load", "high"],
        "processor": ["cpu"],
        "saturation": ["load", "high"],
        "deploy": ["deployment", "rollout"],
    }

    def __init__(self, store: MemoryStore = memory_store):
        self.store = store

    def retrieve(self, query: MemoryRetrievalQuery) -> MemoryRetrievalResponse:
        start_time = time.time()
        success = False

        try:
            candidates = self._filter_active_candidates(query)
            scored_results = [
                self._build_result(record, score, matched_terms)
                for record, score, matched_terms in (
                    self._score_record(record, query.query) for record in candidates
                )
                if score > 0
            ]
            scored_results.sort(key=lambda result: (-result.score, result.updated_at, result.memory_id))

            memory_results = scored_results[: query.top_k]
            for result in memory_results:
                self.store.record_access(result.memory_id)

            success = True
            return MemoryRetrievalResponse(
                query=query.query,
                owner_id=query.owner_id,
                namespaces=list(query.namespaces),
                memory_types=list(query.memory_types),
                memory_results=memory_results,
                empty_message=self.EMPTY_MESSAGE,
                trace={
                    "candidate_count": len(candidates),
                    "matched_count": len(scored_results),
                    "returned_count": len(memory_results),
                    "retrieval_mode": "lexical",
                },
            )
        finally:
            # 记录指标
            from app.services.shadow_mode_metrics import shadow_metrics
            latency_ms = (time.time() - start_time) * 1000
            shadow_metrics.record_memory_recall(success=success, latency_ms=latency_ms)

    def _filter_active_candidates(self, query: MemoryRetrievalQuery) -> List[MemoryRecord]:
        records = self.store.list_memories(owner_id=query.owner_id, status=MemoryStatus.ACTIVE)
        namespace_filter = set(query.namespaces)
        type_filter = set(query.memory_types)
        return [
            record
            for record in records
            if (not namespace_filter or record.namespace in namespace_filter)
            and (not type_filter or record.memory_type in type_filter)
        ]

    def _score_record(self, record: MemoryRecord, query_text: str) -> tuple[MemoryRecord, float, List[str]]:
        terms = self._expand_terms(query_text)
        search_text = self._record_search_text(record)
        matched_terms = [term for term in terms if term in search_text]
        score = float(len(matched_terms))
        return record, score, matched_terms

    def _expand_terms(self, query_text: str) -> List[str]:
        raw_terms = {
            term.strip().lower()
            for term in re.split(r"[\s,，。！？?;；:/\\|]+", query_text)
            if term.strip()
        }
        compact_query = query_text.strip().lower()
        if compact_query:
            raw_terms.add(compact_query)
        for term in self._SYNONYMS:
            if term in compact_query:
                raw_terms.add(term)

        expanded: list[str] = []
        seen: set[str] = set()
        for term in raw_terms:
            for candidate in [term, *self._SYNONYMS.get(term, [])]:
                candidate = candidate.strip().lower()
                if candidate and candidate not in seen:
                    seen.add(candidate)
                    expanded.append(candidate)
        return expanded

    def _record_search_text(self, record: MemoryRecord) -> str:
        payload_json = json.dumps(record.payload.model_dump(mode="json"), ensure_ascii=False)
        parts = [
            record.memory_id,
            record.namespace,
            record.memory_type.value,
            record.content,
            record.summary,
            " ".join(record.tags),
            payload_json,
        ]
        return "\n".join(parts).lower()

    def _build_result(
        self,
        record: MemoryRecord,
        score: float,
        matched_terms: List[str],
    ) -> MemoryRetrievalResult:
        payload = record.payload.model_dump(mode="json")
        return MemoryRetrievalResult(
            memory_id=record.memory_id,
            owner_id=record.owner_id,
            namespace=record.namespace,
            memory_type=record.memory_type,
            status=record.status,
            content=record.content,
            summary=record.summary,
            score=score,
            matched_terms=matched_terms,
            evidence_refs=self._extract_evidence_refs(record, payload),
            payload=payload,
            source=record.source,
            tags=list(record.tags),
            updated_at=record.updated_at,
        )

    def _extract_evidence_refs(
        self,
        record: MemoryRecord,
        payload: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        refs = payload.get("evidence_refs")
        if isinstance(refs, list):
            return [ref for ref in refs if isinstance(ref, dict)]
        source_event = payload.get("source_event")
        if isinstance(source_event, dict):
            return [source_event]
        return [record.evidence]


memory_retrieval_service = MemoryRetrievalService()
