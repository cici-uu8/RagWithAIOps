"""
Memory Guidance Service: 格式化 memory 为 LLM prompt guidance

P5 职责:
- 将 MemoryRetrievalResult 格式化为带标签的 guidance 文本
- 明确标注 memory 不是 document source
- 暴露 updated_at、evidence_refs、status
- 提供 replanner 可推翻的 guidance 格式
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
from textwrap import dedent

from app.models.memory import (
    MemoryRecord,
    MemoryType,
    AlertPatternPayload,
    PlanTemplatePayload,
)
from app.services.memory_retrieval_service import MemoryRetrievalResponse, MemoryRetrievalResult


class MemoryGuidanceService:
    """格式化 memory 为 LLM guidance"""

    @staticmethod
    def format_memory_guidance(
        retrieval_response: MemoryRetrievalResponse,
        include_metadata: bool = True
    ) -> str:
        """
        将 memory retrieval response 格式化为 prompt guidance

        Args:
            retrieval_response: memory 检索响应
            include_metadata: 是否包含 updated_at / evidence_refs / status

        Returns:
            格式化的 guidance 文本
        """
        if not retrieval_response.memory_results:
            return ""

        guidance_lines = [
            "## 运行时记忆指导",
            "",
            "以下内容是用户偏好、处理经验或运行时上下文。",
            "- 它们不是文档来源，不能作为文档 citation。",
            "- 每条记忆包含 updated_at 和 evidence_refs。",
            "- 如果新工具证据与旧记忆冲突，以新证据为准，并将旧记忆标记为 candidate/conflict。",
            ""
        ]

        for idx, memory in enumerate(retrieval_response.memory_results, 1):
            guidance_lines.append(f"### 记忆 {idx}: {memory.memory_type}")
            guidance_lines.append("")

            # 主要内容
            guidance_lines.append(f"**摘要**: {memory.summary}")
            guidance_lines.append("")
            guidance_lines.append(f"**内容**: {memory.content}")
            guidance_lines.append("")

            # metadata
            if include_metadata:
                guidance_lines.append(f"**状态**: {memory.status}")
                guidance_lines.append(f"**更新时间**: {memory.updated_at.isoformat()}")

                # evidence_refs
                if memory.evidence_refs:
                    evidence_summary = MemoryGuidanceService._format_evidence_summary(
                        memory.evidence_refs
                    )
                    if evidence_summary:
                        guidance_lines.append(f"**证据来源**: {evidence_summary}")

                guidance_lines.append("")

        guidance_lines.append("---")
        guidance_lines.append("")

        return "\n".join(guidance_lines)

    @staticmethod
    def _format_evidence_summary(evidence_refs: List[Dict[str, Any]]) -> str:
        """格式化 evidence_refs 为简短摘要"""
        if not evidence_refs:
            return "manual entry"

        parts = []
        for ref in evidence_refs:
            if "session_id" in ref:
                parts.append(f"session {ref['session_id'][:8]}...")
            if "source_type" in ref:
                parts.append(ref["source_type"])
            if "message_refs" in ref and ref["message_refs"]:
                parts.append(f"{len(ref['message_refs'])} messages")
            if "state_refs" in ref and ref["state_refs"]:
                parts.append(f"{len(ref['state_refs'])} state fields")

        return ", ".join(parts) if parts else "manual entry"

    @staticmethod
    def format_alert_pattern_guidance(memory: MemoryRecord) -> str:
        """格式化 alert_pattern 为专门的 guidance"""
        if memory.memory_type != MemoryType.ALERT_PATTERN:
            return ""

        payload = memory.payload
        if not payload or not isinstance(payload, AlertPatternPayload):
            return ""

        lines = [
            f"**告警模式**: {payload.alert_name}",
            f"**服务**: {payload.service or 'N/A'}",
            f"**根因假设**: {payload.root_cause}",
        ]

        if payload.fix:
            lines.append(f"**处理方案**: {payload.fix}")

        lines.append(f"**更新时间**: {memory.updated_at.isoformat()}")
        lines.append("")
        lines.append("注意: 这是历史根因假设，仍需执行 fresh checks 验证。")

        return "\n".join(lines)

    @staticmethod
    def format_plan_template_guidance(memory: MemoryRecord) -> str:
        """格式化 plan_template 为专门的 guidance"""
        if memory.memory_type != MemoryType.PLAN_TEMPLATE:
            return ""

        payload = memory.payload
        if not payload or not isinstance(payload, PlanTemplatePayload):
            return ""

        lines = [
            f"**计划模板**: {payload.alert_type}",
            "",
            "**建议步骤**:",
        ]

        for idx, step in enumerate(payload.plan_steps, 1):
            lines.append(f"{idx}. {step}")

        lines.append("")
        lines.append(f"**更新时间**: {memory.updated_at.isoformat()}")
        lines.append("")
        lines.append("注意: 这是历史成功计划，可根据新证据调整。")

        return "\n".join(lines)

    @staticmethod
    def combine_memory_and_document_context(
        memory_guidance: str,
        document_context: str
    ) -> str:
        """
        合并 memory guidance 和 document context

        Args:
            memory_guidance: 格式化的 memory guidance
            document_context: 现有的文档上下文

        Returns:
            合并后的 experience_context
        """
        parts = []

        if memory_guidance:
            parts.append(memory_guidance)

        if document_context:
            parts.append(document_context)

        return "\n".join(parts) if parts else ""
