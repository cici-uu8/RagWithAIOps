# P3-1 Dense Baseline Report

- generated_at: 2026-05-17T17:23:20
- collection: `p3_dense_baseline_20260517_172313`
- mode: `dense_only`
- query_count: 4

## Metrics
- doc_recall@1: 1.000
- doc_recall@3: 1.000
- hit@1: 1.000
- hit@3: 1.000
- citation_correctness@3: 1.000
- mrr@3: 1.000
- latency_ms: min=146, p50=170.5, p95=177, max=235, avg=180.5

## Query Details
### cpu_alarm
- query: HighCPUUsage 告警怎么处理
- gold_doc_ids: 537351dd-6aa2-5e3e-9b90-89a10270ea4e
- gold_chunk_ids: 537351dd-6aa2-5e3e-9b90-89a10270ea4e:c00000, 537351dd-6aa2-5e3e-9b90-89a10270ea4e:c00001, 537351dd-6aa2-5e3e-9b90-89a10270ea4e:c00002
- top1_doc_id: 537351dd-6aa2-5e3e-9b90-89a10270ea4e
- top1_chunk_id: 537351dd-6aa2-5e3e-9b90-89a10270ea4e:c00000
- doc_recall@3: 1
- hit@3: 1
- citation_correctness@3: 1
- mrr@3: 1.000
- latency_ms: 235

### memory_alarm
- query: HighMemoryUsage 告警怎么处理
- gold_doc_ids: 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5
- gold_chunk_ids: 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5:c00000, 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5:c00001, 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5:c00002, 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5:c00003
- top1_doc_id: 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5
- top1_chunk_id: 82ef7e0b-5b94-5e8a-a2dc-17b5df754ce5:c00000
- doc_recall@3: 1
- hit@3: 1
- citation_correctness@3: 1
- mrr@3: 1.000
- latency_ms: 164

### mineru_text
- query: 第一段正文
- gold_doc_ids: doc_pdf
- gold_chunk_ids: doc_pdf:c00001
- top1_doc_id: doc_pdf
- top1_chunk_id: doc_pdf:c00001
- doc_recall@3: 1
- hit@3: 1
- citation_correctness@3: 1
- mrr@3: 1.000
- latency_ms: 146

### mineru_table
- query: 表1 参数
- gold_doc_ids: doc_pdf
- gold_chunk_ids: doc_pdf:table:t00001
- top1_doc_id: doc_pdf
- top1_chunk_id: doc_pdf:table:t00001
- doc_recall@3: 1
- hit@3: 1
- citation_correctness@3: 1
- mrr@3: 1.000
- latency_ms: 177
