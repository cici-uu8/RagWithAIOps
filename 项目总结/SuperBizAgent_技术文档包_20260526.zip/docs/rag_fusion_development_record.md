# RAG 融合开发记录

日期: 2026-05-13

> 执行约束说明:
> 这个文件不是“开发结束后顺手写一下”的总结，而是当前仓库 RAG 融合开发的正式过程记录文件。
> 后续每一步有实质意义的开发推进，都必须同步更新这里。
> 如果代码改了、计划变了、出现问题了、临时绕路了，但这里没有记录，就视为开发记录不完整。
> 另外，这个文件的写法必须能支撑“对面试官讲项目开发过程”。
> 也就是说，记录不能只写抽象结论，必须尽量给出代码层面的关键例子、命令级验证方式、当时的取舍理由。

## 1. 文档用途

这份文档是当前项目的持续开发记录，目标不是只留“做了什么”，而是尽量完整记录下面几类信息:

1. 每个阶段为什么要做这件事。
2. 当时是如何判断顺序和边界的。
3. 做的过程中遇到了什么问题。
4. 问题最后是怎么解决的。
5. 这些过程怎么帮助对外解释这个项目，尤其是面对面试官时怎么讲清楚。

你可以把它理解成:

```text
它既是项目开发流水账，
也是后续讲项目故事、解释技术取舍、回答面试追问的素材库。
```

这份记录会持续追加，不只记录 P1-0 和 P1-1。

对后续 agent 的直接要求是:

1. 每完成一个阶段或子任务，就追加记录。
2. 每次出现问题、阻塞、顺序调整或技术取舍，也要追加记录。
3. 记录不能只写“改了什么”，还要写“为什么这样改、有什么风险、怎么解释给别人听”。
4. 记录必须尽量带代码级例子，至少要让读者知道“改动具体落在哪个类、字段、函数、文件”。
5. 如果做了验证，记录里要写清用了什么命令、遇到什么环境问题、最后怎么通过。
6. 如果这一步适合在面试中展开，记录里还要补“面试官最可能怎么追问”和“怎么用代码事实回答”。
7. 这些“面试追问”要尽量贴近真实技术面试，不要写成过于自指的问法；更常见的方向应围绕技术取舍、调试定位、验证方式、风险控制、系统边界、个人贡献和经验复盘来组织。

更贴近真实项目 deep dive 的问题，通常优先从下面几类里出:

1. 你当时为什么这样设计，而不是另一种方案。
2. 你遇到的最难问题是什么，怎么定位、怎么验证。
3. 你怎么证明改动没有把旧行为带坏。
4. 这一步解决了什么真实风险，还有什么风险故意留到后面阶段。
5. 你个人真正负责了哪一段，代码证据在哪里。
6. 如果今天重做一次，这一步你会不会换一种实现或验证方式。

## 1A. 中国大厂项目深挖提问模型

这部分不是泛泛而谈，
而是参考中文面经社区里更接近中国大厂风格的项目深挖问题后，
抽出来的提问模型。

从这些材料看，
中国大厂的技术面，尤其是腾讯/字节这类后台或平台方向，
项目追问通常会沿下面几条线展开:

1. 先确认项目边界  
   项目是做什么的，难点在哪，周期多长，你负责哪一块。

2. 再追技术实现  
   具体用了什么技术、为什么这么选、核心流程怎么跑、关键模块怎么拆。

3. 然后放大场景  
   如果量大了怎么办、并发高了怎么办、服务挂了怎么办、数据重复了怎么办。

4. 再追验证与排障  
   你怎么证明它真能工作、怎么定位问题、出了 bug 你第一步看哪、怎么区分代码问题和环境问题。

5. 最后追 trade-off 和成长  
   为什么不是另一种方案、这一步你刻意没做什么、今天重做一次会不会改。

结合这些中文面经，比较高频的项目深挖问题可以整理成这几类:

- 项目难点是什么，最难的点你怎么解决。
- 你在组内具体负责什么，别人做的和你做的边界怎么分。
- 为什么用这个技术方案，不用另一个。
- 如果用户量/数据量/并发上来，系统哪里先出问题，怎么扛。
- 如果某个服务挂掉或者某个节点宕机，怎么处理，怎么恢复。
- 你怎么验证这不是“本地能跑”，而是真的靠谱。
- 你这个方案的缺点是什么，后续准备怎么补。
- 如果线上出问题，你先看日志、指标、状态流还是数据一致性。

后面每个阶段如果要补“面试官追问”，
优先从这些问题类型里选，
而不是写成“为什么不直接说通过了”这类更像内部文档讨论的话。

我主要参考了这些中文材料来提炼这个模型:

- [牛客：腾讯后台开发实习一、二轮面经](https://www.nowcoder.com/discuss/353154952065392640)
- [牛客：腾讯CDG C++后台开发一、二、三面暑期实习面经](https://www.nowcoder.com/discuss/353157703956635648)
- [力扣中文社区：字节&腾讯 后端开发（Go）暑期实习](https://leetcode.cn/discuss/post/EEbULX/)
- [CSDN：腾讯C++后台开发实习面经](https://blog.csdn.net/m0_48634217/article/details/106759266)

---

## 2. 当前项目的主线一句话

当前项目不是在“把 WeKnora 整体接进 oncall agent”，而是在:

```text
保留 oncall agent 的 Python 应用主栈，
以 MinerU-first + pdf_eval 产物语义为运行标准，
通过复制 WeKnora 成熟实现并做最小修改，
把 oncall agent 从轻量 RAG 补成有正式知识库层的系统。
```

---

## 3. 已确认的固定决策

这些决策是后续开发的固定前提:

| 决策 | 当前答案 | 为什么重要 |
|---|---|---|
| 保留应用主栈还是迁移成新知识平台主栈 | 保留应用主栈 | 这决定了不会走“整体重构成 Go 平台”的路线。 |
| 当前最缺 parser 还是知识库层 | 最缺知识库层 | 这决定了不会先把精力放在 parser 替换上。 |
| P1/P2 是否接完整 WeKnora 服务 | 不接 | 这决定了当前阶段以本地复用和最小适配为主。 |
| `pdf_eval` 的 MinerU 产物语义是否作为运行标准 | 接受 | 这决定了 P2 的 artifact 和索引语义来源。 |
| 复用方式是复制成熟实现最小修改，还是自己设计一套 | 复制成熟实现最小修改 | 这决定了不会再造平行链路。 |

---

## 4. 开发过程总览

早期路线判断可以分成 8 个阶段:

1. 识别问题边界
2. 本地引入 WeKnora 代码基线
3. 完成 R0 只读复核
4. 固化 artifact contract
5. 写教材式讲解文档
6. 写融合决策手册
7. 写 P1/P2 可执行清单
8. 开始进入 P1 实现

这些是进入代码实现前的路线形成过程。
后续 P1/P2 的真实实现、验证和收口记录继续在“阶段记录”里追加；
不要把上面 8 项误读成当前项目的完整进度总览。

---

## 5. 阶段记录

### 阶段 A: 识别问题边界

- 时间: 当前 RAG / WeKnora 融合工作启动阶段
- 主要问题:
  - `oncall agent` 已经有可用的 Python 应用主链路，但知识库层太轻。
  - `WeKnora` 很完整，但直接整体接入代价太大。
- 当时的核心判断:
  - 问题不是“换不换一个 parser”。
  - 问题是“要不要给现有应用补上一层正式知识库结构”。
- 形成的早期结论:
  - 先做模式迁移，不做系统替换。
- 对面试官怎么讲:
  - 可以说自己一开始没有急着写代码，而是先识别“真正缺的是哪一层”。这体现的是架构判断，而不是盲改。

### 阶段 B: 本地引入 WeKnora 代码基线

- 主要动作:
  - 把 WeKnora clone 到本地，作为后续复用和只读复核的代码来源。
- 为什么要先做这步:
  - 因为用户明确要求“复用成熟代码，而不是自己造一套”。
  - 没有本地代码基线，后续就很容易变成只看 README 后臆测实现。
- 当时的风险:
  - 容易把“复用 WeKnora”说成一句口号，实际开发又回到自己写。
- 处理方式:
  - 明确把本地 WeKnora clone 设为第一参考源。
- 对面试官怎么讲:
  - 可以强调自己没有凭记忆复述外部项目，而是先把参考实现落到本地，保证复用依据具体可审。

### 阶段 C: R0 只读复核

- 主要动作:
  - 对 WeKnora 的领域对象、parser registry、MinerU adapter、chunk service、retrieval result 等关键文件做只读复核。
- 产出文档:
  - [docs/weknora_r0_reuse_review.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/weknora_r0_reuse_review.md>)
- 当时发现的问题:
  - 很多有价值的实现主体在 Go 侧，不能直接塞进当前 Python 主链路。
  - 但它们的对象结构、流程分层、接口语义非常值得复用。
- 最终结论:
  - 当前阶段几乎没有“直接原样接入即可运行”的代码。
  - 主路线应是“复制成熟实现 + 最小修改”。
- 对面试官怎么讲:
  - 这里能体现你不是泛泛说“参考了 WeKnora”，而是明确区分了“直接可用”和“结构可迁移”。

### 阶段 D: 固化 artifact contract

- 主要动作:
  - 把 P1/P2 的文档接入硬约束落成正式契约。
- 产出文档:
  - [docs/rag_ingestion_artifact_contract.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/rag_ingestion_artifact_contract.md>)
- 为什么必须先做:
  - 如果不先固定 artifact，后面最常见的问题就是:
    - 下游想读的文件上游没产出
    - 上游产出的文件没人消费
    - `cleaned.md/chunks.json/tables.json/quality_report.json` 职责混用
- 当时的关键判断:
  - P1/P2 的主要风险不是算法先进不先进，而是输入输出协议不稳。
- 对面试官怎么讲:
  - 可以强调自己先解决“系统协作契约问题”，而不是一上来就沉迷算法，这体现的是工程化思维。

### 阶段 E: 写教材式讲解文档

- 主要动作:
  - 写教材式文档，分别讲清楚 WeKnora、oncall agent、二者差异、还缺什么层。
- 产出文档:
  - [docs/weknora_oncall_agent_textbook_guide.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/weknora_oncall_agent_textbook_guide.md>)
- 后续补充:
  - 追加术语总表。
  - 再做一轮“逐段扫盲”，把正文改成更像老师讲课的说法。
- 为什么这一步有必要:
  - 不是所有问题都能靠代码和计划解决。
  - 当项目复杂到需要多轮设计判断时，必须先确保“人真的理解这个系统是什么”。
- 对面试官怎么讲:
  - 这体现的不是“写文档爱好”，而是“我能把复杂系统重新解释成别人能理解的话”。这对架构沟通很重要。

### 阶段 F: 写融合决策手册

- 主要动作:
  - 把已经确认下来的路线、先后顺序、阶段门禁、风险地图固定成手册。
- 产出文档:
  - [docs/technical_fusion_decision_manual.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/technical_fusion_decision_manual.md>)
- 解决了什么问题:
  - 让“计划”和“实际决策”不再分离。
  - 让后续写计划清单时，有统一的顺序和风险参考。
- 当时的核心判断:
  - 当前阶段的主线必须固定为:
    - 先对象
    - 再 artifact
    - 再索引幂等
    - 再 retrieval/citation
- 对面试官怎么讲:
  - 可以用它说明你不是只会列任务，而是会把路线、边界和风险变成可执行的决策系统。

### 阶段 G: 写 P1/P2 可执行清单

- 主要动作:
  - 把前面的分析计划、决策手册和 artifact contract 收束成正式可执行 checklist。
- 产出文档:
  - [docs/p1_p2_execution_checklist.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/p1_p2_execution_checklist.md>)
- 解决了什么问题:
  - 避免后续开发时“知道方向，但不知道第一步先敲什么文件”。
- 当时的核心设计:
  - 给每一项都补上:
    - 前置条件
    - 必做项
    - 不允许
    - 产出物
    - 验收标准
    - 风险提示
- 对面试官怎么讲:
  - 这能体现你会把高层架构方案落成真正能执行的工程清单。

### 阶段 H: P1-0 执行前检查

- 当前状态: 已完成
- 本次动作:
  - 确认固定前提 5 条成立。
  - 确认当前只推进 P1-0 与 P1-1，不偷跑 P1-2/P1-3。
  - 确认 `md/txt` 兼容路径是必须保留的边界。
- 为什么要单独记这一项:
  - 因为很多项目失败不是技术做不到，而是执行过程中边界一直在变。
- 本次没有出现的新问题:
  - 方向没有再摇摆，说明前期文档化工作已经把路线定稳了。
- 对面试官怎么讲:
  - 可以说自己在开始改代码前，会先做一次“执行前检查”，确认不会边做边换方向。

### 阶段 I: P1-1 最小领域对象落地

- 当前状态: 已完成
- 本次动作:
  - 新增 [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>)
  - 更新 [app/models/__init__.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/__init__.py>)
- 本次目标:
  - 建立最小 `KnowledgeBase`
  - 建立最小 `DocumentRecord`
  - 建立最小 `ChunkRecord`
  - 同时补上 `ParserEngine`、`DocumentStatus`、`ChunkingConfig`、`SourceRef`
- 为什么这样做:
  - 因为后续不管是 artifact、状态、索引、citation，都需要一个正式对象层来挂载。
- 参考来源:
  - `WeKnora/internal/types/knowledgebase.go`
  - `WeKnora/internal/types/knowledge.go`
  - `WeKnora/internal/types/chunk.go`
  - `WeKnora/internal/types/docparser.go`
- 遇到的实际问题:
  - 现有项目里只有 `DocumentChunk` 这种轻量模型，没有文档生命周期对象。
  - WeKnora 的对象更完整，但 Go 代码不能直接接入当前 Python 主链路。
- 解决方式:
  - 不试图直接复用 Go 类型。
  - 采用“按字段语义复制 + 最小 Python 化”的方式，在 `app/models/knowledge.py` 中重建最小版本。
- 本次刻意没做的事:
  - 没有改现有上传逻辑。
  - 没有改现有 `document_splitter_service`。
  - 没有提前落 `KnowledgeMetadataStore`。
  - 没有提前改检索输出。
- 当前结果:
  - P1 所需的对象层已经有了第一个正式落点。
  - 还没有进入状态存储、索引回填和运行链路接入。
- 对面试官怎么讲:
  - 这一步能体现“先立概念模型，再接流程”的工程思路。
  - 可以强调自己刻意控制范围，没有因为对象层落地就顺手改掉旧逻辑。

#### 阶段 I 的代码级推进细节

这一小节专门补“如果面试官继续追问，你到底改了什么代码”，避免记录只剩抽象结论。

##### 1. 先看现有代码缺什么

在开始写新模型前，先看了现有的 [app/models/document.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/document.py>)。

当时发现现有模型只有一个很轻的 `DocumentChunk`:

```python
class DocumentChunk(BaseModel):
    content: str
    start_index: int
    end_index: int
    chunk_index: int
    title: Optional[str]
```

这个模型能表达“切出来的一段文本”，但表达不了下面这些后续一定会需要的信息:

- 这段内容属于哪个知识库
- 这段内容属于哪份文档
- 这份文档当前处理状态是什么
- 这段内容未来怎么做稳定引用

也就是说，现有模型更像“文本切片模型”，不是“知识库领域对象模型”。

面试可以这样讲:

```text
我不是上来就新增模型，而是先看现有模型到底差在哪。
我发现它能表达 chunk，但不能表达 document lifecycle 和 stable source identity，
所以后面 artifact、状态、citation 都没有正式挂点。
```

##### 2. 为什么新建 `knowledge.py`，而不是直接改 `document.py`

当时有两个可选方案:

1. 直接在 `app/models/document.py` 里不断加字段
2. 新建一个单独的 `app/models/knowledge.py`

最后选了方案 2。

原因是:

- `document.py` 里现有的 `DocumentChunk` 语义比较轻，更接近“现有切分结果的表现层对象”。
- 当前要补的是一整套 WeKnora-style 的知识库领域对象，不只是给旧 chunk 多挂几个字段。
- 如果直接往 `DocumentChunk` 上硬塞，会把“旧轻量模型”和“新知识库对象层”搅在一起，后面更难讲清边界。

所以这一步的设计取舍是:

```text
保留旧的轻量 chunk 模型，
另外新建知识库领域模型文件，
让旧链路还能继续跑，同时为后续 P1/P2 接入预留正式对象层。
```

面试可以这样讲:

```text
我没有为了少建一个文件，就把所有语义都塞回旧模型里。
我更在意的是边界是否清楚：旧模型继续服务旧链路，新模型承接知识库层升级。
```

##### 3. 具体新增了哪些对象

这一步不是泛泛地“新增一些模型”，而是明确新增了下面几类对象:

- `ParserEngine`
- `DocumentStatus`
- `KnowledgeBaseType`
- `ParserEngineRule`
- `ChunkingConfig`
- `KnowledgeBase`
- `SourceRef`
- `DocumentRecord`
- `ChunkRecord`

这些对象对应的作用分别是:

| 对象 | 代码里负责什么 | 为什么在 P1 就先加 |
|---|---|---|
| `ParserEngine` | 固定 `plain_text` / `mineru` 这类引擎名 | 后面 parser 路由必须吃这个字段 |
| `DocumentStatus` | 固定文档生命周期状态枚举 | 后面 ingestion 和 artifact 校验必须挂状态 |
| `ChunkingConfig` | 承接 chunking 和 parser 路由规则 | 后面会用到 `resolve_parser_engine()` |
| `SourceRef` | 统一来源引用结构 | 后面 citation 的核心锚点 |
| `DocumentRecord` | 表达文档对象本身 | 后面 artifact_dir/status/parser_engine 都要挂这里 |
| `ChunkRecord` | 表达 chunk 的正式身份 | 后面写入 Milvus metadata 和 retrieval 时要用 |

##### 4. 代码层面的关键例子 1: 先把状态固定，而不是散落写字符串

我在 [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>) 里先加了:

```python
class DocumentStatus(StrEnum):
    UPLOADED = "uploaded"
    UPLOAD_FAILED = "upload_failed"
    PARSE_PENDING = "parse_pending"
    PARSING = "parsing"
    PARSED = "parsed"
    PARSE_FAILED = "parse_failed"
    INDEX_PENDING = "index_pending"
    INDEXING = "indexing"
    INDEXED = "indexed"
    INDEX_FAILED = "index_failed"
```

这样做的原因不是“写枚举更好看”，而是:

- 后面 `DocumentIngestionService` 一定会改状态
- 后面 artifact 校验失败时一定要落状态
- 如果状态值散落在各个服务里写字符串，后续极容易拼错或语义漂移

面试可以这样讲:

```text
我优先把文档状态枚举抽出来，是因为后面接入 PDF 以后，
系统第一次会真正拥有“上传、解析、索引”这些正式阶段。
如果状态不先统一，后面每个服务都会用自己的字符串，最后没法收口。
```

##### 5. 代码层面的关键例子 2: 把 parser 路由规则先模型化

我没有等到 `P2-1` 再第一次接触 parser 路由，而是在 P1 模型里先放进了:

```python
class ParserEngineRule(BaseModel):
    file_types: List[str]
    engine: ParserEngine

class ChunkingConfig(BaseModel):
    ...
    parser_engine_rules: List[ParserEngineRule] = Field(default_factory=list)

    def resolve_parser_engine(self, file_type: str) -> Optional[ParserEngine]:
        ...
```

这一步的工程意义是:

- 后面 `ParserEngineRouter` 不是凭空设计
- 当前对象层已经知道“路由规则会长什么样”
- 这样 P2 接入时，不会再为了路由规则重改对象模型

也就是说，这一步虽然还没写 router 服务，但已经先把 router 要吃的数据结构定下来了。

面试可以这样讲:

```text
我在 P1 就把 parser engine rule 模型化了，
这样后面真正写 Router 的时候不是再重新设计输入结构，
而是直接消费已经定好的领域对象。
```

##### 6. 代码层面的关键例子 3: 为什么要单独做 `SourceRef`

在这一步里，我单独做了一个:

```python
class SourceRef(BaseModel):
    kb_id: str
    doc_id: str
    chunk_id: str
    source_file: str
    page_start: Optional[int]
    page_end: Optional[int]
    heading_path: List[str]
    content_type: str
    parser_engine: ParserEngine
```

这里的核心思路是:

- 以后 citation 不能在回答阶段临时拼
- 来源身份要从 chunk 产生时就确定下来
- 所以 `SourceRef` 必须先成为正式对象

这一步很关键，因为它其实提前把“后面怎么引用来源”定住了。

面试可以这样讲:

```text
我没有把来源信息只当成 metadata 的零散字段，
而是单独做成 SourceRef 对象。
这样后面从 artifact 到 chunk 到 retrieval 到 answer，
引用链会有一个统一的载体，而不是每一层临时拼字符串。
```

##### 7. 代码层面的关键例子 4: `DocumentRecord` 和 `ChunkRecord` 为什么这样设计

`DocumentRecord` 的关键字段我放了这些:

- `doc_id`
- `kb_id`
- `file_name`
- `file_ext`
- `original_path`
- `artifact_dir`
- `parser_engine`
- `status`
- `parser_version`
- `error_message`
- `metadata`

这里的重点不是字段数量，而是字段组合表达了一个很明确的工程意图:

```text
这不是一份“上传过的文件信息”，
而是一份“系统正式管理的文档记录”。
```

同样，`ChunkRecord` 里我放了:

- `chunk_id`
- `doc_id`
- `kb_id`
- `content`
- `chunk_index`
- `start_index`
- `end_index`
- `heading_path`
- `page_start/page_end`
- `content_type`
- `source_ref`
- `quality_flags`
- `metadata`
- `parent_chunk_id`

这里的设计重点是:

- 它不是只表达“文本内容”
- 它同时表达“身份、位置、类型、来源、质量”

这样后面无论是索引、检索、引用还是 QA，都不需要重新发明这些语义。

##### 8. 代码层面的关键例子 5: 先改 `__init__.py` 导出，而不是让模型变成孤岛

除了新建模型文件，我还改了 [app/models/__init__.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/__init__.py>)，把新对象显式导出。

这个动作很小，但很重要，因为它意味着:

- 新模型不是“先扔在某个文件里，以后再说”
- 它从一开始就被视为模型层正式组成部分

面试官如果继续追问“你是真的在搭结构，还是只是先放个草稿”，这个点就能说明你在按模块边界做正式落地。

##### 9. 这一步遇到的真实问题和处理方式

本轮实现中有一个非常真实的小问题:

- 我做完模型后，用 `python3 -m py_compile` 做最小语法校验。
- 系统默认 Python 试图把 `.pyc` 写到系统缓存目录:
  `/Users/cici/Library/Caches/com.apple.python/...`
- 当前环境没有这个路径的写权限，所以第一次校验失败了。

这里失败的原因不是代码错误，而是环境缓存路径权限问题。

我的处理方式是:

- 不改代码
- 不跳过验证
- 改成用项目外可写缓存目录执行:

```bash
PYTHONPYCACHEPREFIX="/private/tmp/pycache_super_biz_agent" python3 -m py_compile ...
```

然后校验通过。

这个细节其实很适合面试时讲，因为它说明:

- 你没有把一切失败都误判成代码问题
- 你能分辨“代码错误”和“环境问题”
- 你会给出最小扰动的修复方式

##### 10. 如果面试官追问“这一轮开发最重要的工程判断是什么”

我会建议你回答:

```text
最重要的判断不是“字段名怎么起”，
而是我选择先把对象层立起来，并且让这些对象从一开始就对齐 WeKnora 的语义，
而不是继续在旧轻量模型上打补丁。

这样后面做 artifact、状态流、索引幂等、retrieval/citation 时，
都会有稳定挂点，不会每一层都再返工模型。
```

##### 11. 更贴近中国大厂技术面会怎么追问这一轮

这一节不是泛泛准备，而是专门为“面试官会继续往下钻”准备的。

###### 追问 1: 你为什么不直接在原来的 `DocumentChunk` 上加字段?

建议回答:

```text
我当时先看了现有的 `app/models/document.py`，
里面的 `DocumentChunk` 只有 `content/start_index/end_index/chunk_index/title` 这些字段。

如果直接在它上面继续加 `kb_id/doc_id/status/source_ref/parser_engine/artifact_dir`，
会把“旧轻量切片模型”和“新知识库领域对象”混在一起。

所以我选择保留旧模型服务旧链路，
另外新建 `app/models/knowledge.py` 承接 WeKnora-style 的对象层，
这样后面 P1/P2 接入时边界更清楚。
```

面试官为什么会信这个回答:

- 因为你提到了旧文件名。
- 你提到了旧类的具体字段。
- 你解释的是边界问题，不是空泛地说“为了更优雅”。

###### 追问 2: 你说“对齐 WeKnora 语义”，具体怎么对齐的?

建议回答:

```text
我不是照着名字随便翻译，而是按对象职责对齐。

比如 WeKnora 的 `KnowledgeBase` 在我这里先对应成最小 `KnowledgeBase`，
保留 `kb_id/name/type/chunking_config`；
WeKnora 的 `Knowledge` 我对应成 `DocumentRecord`，
重点保留 `doc_id/kb_id/file_name/file_ext/original_path/artifact_dir/parser_engine/status/error_message`；
WeKnora 的 `Chunk` 我对应成 `ChunkRecord`，
重点补了 `chunk_id/doc_id/kb_id/content/chunk_index/start_index/end_index/source_ref`。

也就是说，我优先复制的是对象职责和后续链路一定要依赖的字段语义，
而不是把所有 Go 侧字段原样搬过来。
```

面试官为什么会信这个回答:

- 因为你说得出三组对象是一一对应的。
- 你能说出保留了哪些关键字段，不是只会说“参考了 WeKnora”。

###### 追问 3: 为什么 P1 就引入 `ParserEngineRule` 和 `ChunkingConfig`，这不是 P2 的事吗?

建议回答:

```text
这是一个典型的“先定数据结构还是先写服务”的问题。

我选择在 P1 就先把 `ParserEngineRule` 和 `ChunkingConfig` 模型化，
因为 P2 的 `ParserEngineRouter` 一定要消费这类结构。

如果我等到 P2 再第一次设计它们，
那 P1 里刚落下来的 `KnowledgeBase` 模型大概率还得再改一遍。

所以我在 P1 先把数据结构固定，
P2 再去写真正的路由服务，这样对象层不会返工。
```

面试官为什么会信这个回答:

- 这是很真实的工程取舍，不是教科书答案。
- 你解释了“为什么提前放模型，但没有提前写服务”。

###### 追问 4: 为什么单独做 `SourceRef`，不直接放进 `metadata`?

建议回答:

```text
因为 `metadata` 很容易变成一个“什么都能塞”的口袋。

我当时判断 `source_ref` 不是普通附加信息，
而是后面 citation 要贯穿 artifact、chunk、Milvus metadata、retrieval result 的核心对象。

所以我把它单独做成了 `SourceRef`，
里面固定 `kb_id/doc_id/chunk_id/source_file/page_start/page_end/heading_path/content_type/parser_engine`。

这样后面不是每一层自己拼一套来源字段，
而是从一开始就有统一载体。
```

面试官为什么会信这个回答:

- 你不是笼统说“为了规范”，而是指出了 `metadata` 口袋化的问题。
- 你说清了 `SourceRef` 将来要贯穿哪些层。

###### 追问 5: 这一轮你怎么验证自己没写坏?

建议回答:

```text
这一轮我没有去跑业务链路，因为我刻意把范围控制在对象层落地。

但我做了最小语法校验：
先用 `python3 -m py_compile` 检查新文件，
第一次失败不是代码问题，而是系统 Python 想把 `.pyc` 写到系统缓存目录，权限不够。

我没有跳过校验，而是把 `PYTHONPYCACHEPREFIX` 指到 `/private/tmp/pycache_super_biz_agent`，
然后重新跑 `py_compile`，校验通过。

所以这个阶段我验证的是“模型文件本身没语法问题、基础结构可导入”，
而不是假装已经把运行链路接完了。
```

面试官为什么会信这个回答:

- 你没有吹大验证范围。
- 你讲得出具体命令、失败原因和修复方式。

###### 追问 6: 这一轮你刻意没做什么?

建议回答:

```text
我刻意没碰三类东西：

第一，没有改 `md/txt` 现有切分逻辑；
第二，没有提前落 `KnowledgeMetadataStore`；
第三，没有提前改 retrieval 输出。

原因是这一轮的目标非常收敛，只是先把知识库对象层立起来。
如果顺手把后面几层也一起改了，
那就很难判断问题究竟出在对象模型，还是出在 metadata store、索引、retrieval。
```

面试官为什么会信这个回答:

- 真做过项目的人通常都知道“刻意不做什么”。
- 这能体现你有范围控制能力，不是一路顺手改到底。

### 阶段 J: P1-2 Metadata Store 落地

- 当前状态: 已完成
- 本次动作:
  - 新增 [app/services/knowledge_metadata_store.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/knowledge_metadata_store.py>)
- 本次目标:
  - 给文档和 chunk 建一个最小、正式、脱离 Milvus 的 metadata 存储层。
- 为什么现在做:
  - 因为 `P1-1` 只是把对象层立起来了。
  - 如果没有 `Metadata Store`，这些对象还只是代码里的定义，系统运行后依旧只有“文件 + Milvus metadata”。
- 参考来源:
  - `WeKnora/internal/application/service/chunk.go`
  - `WeKnora/internal/types/interfaces/chunk.go`
- 本次结果:
  - 增加了最小 `KnowledgeMetadataStore`
  - 支持:
    - `upsert_document`
    - `get_document`
    - `transition_document_status`
    - `update_document_status`
    - `replace_chunks`
    - `list_chunks_by_doc_id`
    - `delete_chunks_by_doc_id`
    - `list_documents`
- 为什么选择这种落地形式:
  - 当前阶段目标是“先接上最小生命周期存储”，不是立即引入数据库迁移。
  - 所以先用项目内 JSON 文件落一个可工作的最小 metadata store。
- 关键取舍:
  - 我没有让 Milvus JSON metadata 继续充当唯一状态存储。
  - 我也没有现在就引入 SQLite/ORM 层，避免这一步扩面过大。

#### 阶段 J 的代码级推进细节

##### 1. 为什么 metadata store 不能继续只靠 Milvus

如果继续只靠 Milvus metadata，会出现几个问题:

- 文档状态没有正式对象，只能散在向量记录里
- 没法很自然地按 `doc_id` 管整份文档
- 后面 parser 失败、artifact 缺失时，没有一个正式地方落状态

所以这一步的核心判断是:

```text
Milvus 适合做检索索引，
但不适合充当文档生命周期的唯一事实来源。
```

##### 2. 为什么先做 JSON 文件版 store，而不是直接上数据库

当时可以选:

1. 直接上 SQLite
2. 直接上 ORM
3. 先做一个最小文件型 store

我选了第 3 个。

原因是:

- `P1-2` 的目标只是先把“正式 metadata 层”接出来
- 这一步如果直接引入数据库，会把讨论从“元数据边界”扩成“持久化方案设计”
- 现在最需要的是先证明对象层和索引链路能正式接住

所以我在 [app/services/knowledge_metadata_store.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/knowledge_metadata_store.py>) 里先做了一个最小 JSON store，并把路径固定到:

```text
./uploads/_metadata/knowledge_metadata_store.json
```

面试可以这样讲:

```text
我当时刻意没把问题升级成数据库选型，
先用最小文件型 store 把生命周期边界接出来，
后面如果需要再平滑换成 SQLite 或更正式存储。
```

##### 3. 为什么 `KnowledgeMetadataStore` 要同时管 document 和 chunk

我没有把它拆成两个完全独立的 store，原因是当前阶段最核心的问题就是:

```text
同一个 doc_id 对应的文档状态和 chunk 集合，必须能放在同一条最小链路里管理。
```

所以这里的设计是:

- `_documents: Dict[str, DocumentRecord]`
- `_chunks_by_doc: Dict[str, Dict[str, ChunkRecord]]`

这样 `doc_id` 就成了最小主轴。

面试可以这样讲:

```text
我不是为了抽象漂亮拆两个仓库，
而是围绕当前阶段最重要的主键 `doc_id` 去组织最小生命周期存储。
```

##### 4. 这一轮最关键的代码点

最关键的不是“能写入 JSON”，而是把操作能力收束成后面一定会用到的动作:

```python
def upsert_document(...)
def transition_document_status(...)
def update_document_status(...)  # compatibility wrapper
def replace_chunks(...)
def delete_chunks_by_doc_id(...)
```

这几个动作对应的都是后面真实链路一定会发生的事情:

- 上传或更新文档记录
- 改状态
- 替换整份文档的 chunk 集合
- 重传前删除旧 chunk

也就是说，这一步的真正价值是:

```text
不是做了个存 JSON 的工具，
而是先把后续主链路一定要用的生命周期动作定义出来。
```

##### 5. 更贴近中国大厂技术面会怎么追问这一轮

###### 追问 1: 为什么不继续只用 Milvus metadata?

建议回答:

```text
因为 Milvus metadata 更适合做检索附带信息，
不适合当文档生命周期的唯一事实来源。

我后面会需要正式处理 document status、chunk replacement、doc_id 级别的幂等清理，
这些都不应该继续只依赖向量库里的散 JSON 字段。
```

###### 追问 2: 为什么现在不直接上 SQLite?

建议回答:

```text
因为这一轮的核心任务不是存储方案最终定型，
而是先把 metadata 生命周期边界接出来。

如果我现在就引入 SQLite/ORM，
很容易把范围从 P1-2 的元数据边界问题，扩成数据库设计问题。

所以我先选了一个最小文件型 store，
让 document/chunk 生命周期先有正式落点，后面再平滑替换底座。
```

###### 追问 3: 这一轮你真正新增了什么能力?

建议回答:

```text
这轮我新增的不是“看得见的 UI 功能”，
而是系统内部第一次有了独立于 Milvus 的 document/chunk 生命周期存储层。

具体代码上，我新增了 `KnowledgeMetadataStore`，
支持 upsert 文档、改状态、按 doc_id 替换 chunk、按 doc_id 删除 chunk，
这些动作是后面接 artifact、幂等索引、citation 的前置能力。
```

### 阶段 K: P1-3 md/txt 兼容索引改造

- 当前状态: 已完成
- 本次动作:
  - 更新 [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)
  - 更新 [app/tools/knowledge_tool.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/tools/knowledge_tool.py>)
- 本次目标:
  - 在不破坏现有 `md/txt` 上传主链路的前提下，把稳定 `kb_id/doc_id/chunk_id/source_ref` 接入 metadata。
- 为什么现在做:
  - 对象层和 metadata store 已经有了。
  - 如果不把它们真正接进现有索引链路，前面两步仍然只是“静态结构准备”。

#### 阶段 K 的代码级推进细节

##### 1. 为什么优先改 `vector_index_service.py`

当前 `md/txt` 主链路的真实入口，不是在模型层，而是在:

- 读取文件
- 删除旧数据
- 调分割器
- 写入向量库

这整个过程都集中在 [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)。

所以如果要做到“兼容旧行为、补新 metadata”，最自然的落点就是这个文件，而不是先去改 API 层或检索层。

##### 2. 具体改了什么

这一步最关键的改动包括:

- 给 `index_single_file()` 增加了 `kb_id` 入口参数，默认仍是 `default`
- 新增 `_build_doc_id()`
- 新增 `_build_document_record()`
- 新增 `_build_chunk_records()`
- 新增 `_extract_heading_path()`
- 新增 `_locate_chunk_offsets()`

这组改动的整体思路是:

```text
保持“读文件 -> 切分 -> 入库”的旧主流程不变，
但在这个流程周围补上 document/chunk 的正式身份。
```

##### 3. 为什么 `doc_id` 用的是稳定 UUID，而不是随机 UUID

我这里不是每次 `uuid4()` 重新生成，而是:

```python
return str(uuid5(NAMESPACE_URL, f"{kb_id}:{normalized_path}"))
```

这样做的原因是:

- `P1-3` 的重点之一就是给 legacy `md/txt` 路径补稳定身份
- 如果每次重新生成随机 `doc_id`，同一文件每次上传都会变成新文档身份
- 那后面按 `doc_id` 做幂等清理就站不住

所以这里的工程判断是:

```text
对 legacy md/txt 路径，先基于 kb_id + 规范化路径生成稳定 doc_id，
保证同一文件在兼容路径下有稳定身份。
```

###### 面试官追问: 为什么不用文件内容 hash 作为 doc_id?

建议回答:

```text
内容 hash 也能做稳定标识，但当前 legacy 路径原本就有明显的“文件路径”语义，
而且兼容旧删除逻辑也是按 `_source` 路径在做。

所以我优先选了基于 `kb_id + normalized_path` 的稳定 UUID，
这样和旧链路的语义更一致，也更方便过渡到后面的 doc_id 幂等清理。
```

##### 4. 为什么要在 `vector_index_service` 里先创建 `DocumentRecord`

我在真正读文件前，就先构建并 upsert 了一个 `DocumentRecord`，
然后在流程中更新它的状态:

- `uploaded`
- `index_pending`
- `indexing`
- `indexed`
- 出错时 `index_failed`

这样做的意义是:

```text
即使当前还没接 PDF 解析和 artifact 六件套，
legacy md/txt 路径也已经第一次拥有了正式状态流。
```

这一步是给后面 P2 的 ingestion 工作流打地基。

##### 5. 为什么要在构建 chunk 时直接回填 `source_ref`

在 `_build_chunk_records()` 里，我没有等到检索阶段再去拼来源，而是构建 chunk 时就创建了:

```python
source_ref = SourceRef(
    kb_id=kb_id,
    doc_id=doc_id,
    chunk_id=chunk_id,
    source_file=path.name,
    page_start=None,
    page_end=None,
    heading_path=heading_path,
    content_type=content_type,
    parser_engine=ParserEngine.PLAIN_TEXT,
)
```

然后把它同时写进:

- `ChunkRecord.source_ref`
- LangChain `Document.metadata["source_ref"]`

这背后的关键判断是:

```text
引用对象必须在 chunk 生成时就有，
而不是等到检索输出时再临时拼。
```

##### 6. 为什么还保留旧的 `_source/_file_name/_extension`

这一步最容易犯的错误，就是一激动把旧 metadata 体系全换掉。

但我这里刻意保留了:

- `_source`
- `_file_name`
- `_extension`

同时新增:

- `kb_id`
- `doc_id`
- `chunk_id`
- `content_type`
- `parser_engine`
- `heading_path`
- `source_ref`

这是一种很典型的“兼容式升级”策略:

```text
旧字段先保留，保证旧链路不炸；
新字段补进去，给后续新链路提供正式身份。
```

###### 面试官追问: 为什么不一步到位把旧字段删掉?

建议回答:

```text
因为 P1 的目标是兼容升级，不是接口清洗。

当前还有现有检索格式化逻辑依赖 `_file_name` 等旧键，
如果我在 P1 就直接删旧字段，会把“补知识库对象层”变成“顺手破坏旧链路”。

所以我选的是双轨并存：旧键保留，新键补齐。
```

##### 7. 为什么还改了 `knowledge_tool.py`

严格说，P1-3 的核心是索引改造，但我还是顺手补了 [app/tools/knowledge_tool.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/tools/knowledge_tool.py>)，原因是:

- 如果 metadata 已经有 `doc_id/chunk_id/source_ref`
- 但检索工具还完全不展示这些字段
- 那外部就看不到这次兼容升级到底带来了什么

所以我加了:

- `_parse_source_ref()`
- `_build_citation_text()`

然后在格式化上下文时，把:

- 文件名
- `doc_id`
- `chunk_id`
- 页码
- 标题路径

尽量串成可见的定位信息。

这一步还不是完整 `RetrievalServiceV2`，但它让 P1 的“稳定来源字段”第一次在工具输出层可见。

##### 8. 这一步遇到的真实工程问题

这轮没有遇到新的语法级错误，但它有一个很真实的工程难点:

```text
怎么在不改现有分割算法的前提下，给 chunk 补稳定 start/end/source_ref/doc_id?
```

我的处理方式是:

- 不碰 `document_splitter_service` 主逻辑
- 在 `vector_index_service` 里通过 `_locate_chunk_offsets()` 去反向定位 chunk 在原文中的位置
- 优先保持兼容，而不是为了位置更完美去重写 splitter

这其实就是“先稳住边界，再逐步变强”的典型工程取舍。

##### 9. 更贴近中国大厂技术面会怎么追问这一轮

###### 追问 1: 你为什么不去改 `document_splitter_service`，直接在那里补 chunk_id/source_ref?

建议回答:

```text
因为 P1-3 的目标是兼容索引改造，不是重做切分逻辑。

`document_splitter_service` 是当前 legacy md/txt 行为的核心，
如果我在这一步直接改它，就很容易把问题混成“对象层升级”和“切分算法变化”两件事。

所以我选择在 `vector_index_service` 包一层，
保持旧 splitter 输出不回退，再把新身份字段补进去。
```

###### 追问 2: 你怎么保证同一 md/txt 文件以后有稳定身份?

建议回答:

```text
我没有用随机 UUID，而是基于 `kb_id + normalized_path` 生成稳定 `doc_id`。
这样同一路径下的 legacy 文件每次进索引时身份是稳定的，
后面做按 `doc_id` 的幂等清理才有意义。
```

###### 追问 3: 这一轮最重要的新增能力是什么?

建议回答:

```text
最重要的不是“又能多搜点东西”，
而是 legacy md/txt 路径第一次拥有了正式的 document identity、chunk identity 和 source_ref。

也就是说，系统不再只知道“这是某个文件切出来的几段文本”，
而开始知道“这是哪个知识库里的哪份文档、哪一个 chunk、后续该怎么稳定引用”。
```

### 阶段 L: P1-4 回归门

- 当前状态: 部分完成
- 本次目标:
  - 验证 `P1-1`、`P1-2`、`P1-3` 不是只把结构写出来了，而是真的让 `md/txt` 兼容链路带上了稳定 metadata 和可见引用信息。
- 本次遇到的现实问题:
  - 当前机器没有 `docker` 命令。
  - `localhost:19530` 未开放，Milvus 没起。
  - 这意味着不能诚实地声称“真实 Milvus 端到端回归已通过”。

#### 阶段 L 的代码级推进细节

##### 1. 我没有因为环境不全就跳过回归

面对 P1-4，当时其实有两种错误做法:

1. 直接说“看代码应该没问题”，假装回归通过
2. 一看到 Milvus 没起，就完全不做任何验证

我没有选这两种，而是做了一个折中但诚实的方案:

```text
先做无 Milvus 依赖的逻辑级回归，
把这次新增的对象层、metadata store、md/txt metadata 接线、citation 格式先验证掉；
再把“真实 Milvus 端到端未完成”明确记成环境阻塞。
```

##### 2. 为什么能做“无 Milvus 依赖”的回归

问题在于，当前 [app/services/vector_store_manager.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_store_manager.py>) 模块导入时就会初始化向量存储，并尝试连接 Milvus。

这导致一个很实际的工程问题:

```text
如果直接正常 import `vector_index_service`，
它会顺带 import `vector_store_manager`，
而当前机器又没有 Milvus，
那验证脚本一开始就会死在环境层。
```

##### 3. 我具体怎么绕过这个环境依赖

这一步不是嘴上说“mock 一下”，而是做了非常具体的模块级替换。

我在验证脚本里先构造了一个假的 `vector_store_manager` 模块，并放进 `sys.modules`:

```python
fake_module = types.ModuleType('app.services.vector_store_manager')
fake_module.vector_store_manager = fake_vsm
sys.modules['app.services.vector_store_manager'] = fake_module
```

然后再去 import:

- `app.services.vector_index_service`
- `app.tools.knowledge_tool`

这样这两个模块在导入时，吃到的就不是“真实会连 Milvus 的 manager”，而是一个测试用 fake manager。

面试可以这样讲:

```text
我不是把 Milvus 相关代码整段注释掉，
而是用模块注入的方式，让现有索引代码在不改生产实现的前提下，
吃到一个 fake vector store manager，从而验证我的 P1 改造逻辑。
```

##### 4. fake vector store manager 具体承担了什么

这一步里，fake manager 不是什么抽象概念，而是最小实现了 3 个动作:

- `delete_by_source()`
- `add_documents()`
- `get_vector_store()`

其中 `get_vector_store()` 返回的 fake vector store，又提供了:

- `as_retriever()`
- `invoke()`

这样我就能复用现有:

- `VectorIndexService.index_single_file()`
- `retrieve_knowledge()`

而不是自己手工拼一套“看起来像验证”的旁路逻辑。

##### 5. 这轮实际验证了什么

我用了两个样本:

- `aiops-docs/cpu_high_usage.md`
- 把 `aiops-docs/memory_high_usage.md` 复制成 `/private/tmp/p1_memory_sample.txt`

然后验证了这些点:

1. `md` 与 `txt` 都能走现有切分主逻辑
2. `KnowledgeMetadataStore` 里能看到至少 2 份 `DocumentRecord`
3. `md` 样本能生成稳定 `doc_id`
4. `ChunkRecord` 里有:
   - `kb_id`
   - `doc_id`
   - `chunk_id`
   - `source_ref`
5. `ChunkRecord.metadata` 里保留了:
   - `_source`
   - `doc_id`
   - `source_ref`
6. `retrieve_knowledge` 的格式化文本里已经能看到:
   - `doc: ...`
   - `chunk: ...`

##### 6. 这轮还遇到了一个很真实的小坑

第一次写验证脚本时，我用了:

```python
context, docs = retrieve_knowledge.invoke({...})
```

结果失败了，报的是:

```text
ValueError: too many values to unpack (expected 2)
```

原因不是业务逻辑坏了，而是:

- `retrieve_knowledge` 被 `@tool` 包装后
- `.invoke(...)` 的返回形态已经不是“普通 Python 函数返回二元组”那种语义了

我后来改成直接验证底层函数:

```python
context, docs = retrieve_knowledge.func('CPU 告警')
```

然后继续完成验证。

这个点很值得记，因为它说明:

- 你真的跑过验证
- 你不是只会写 happy path 结论
- 你能分辨“LangChain tool wrapper 行为”和“业务函数本身”的差异

##### 7. 这轮真实结论是什么

真实结论不是“P1-4 全通过”，而是:

```text
P1-4 已完成逻辑级回归，
确认对象层、metadata store、md/txt metadata 接线、citation 文本增强都工作正常；
但真实 Milvus-backed 端到端回归尚未完成，
因为当前机器没有 Docker，Milvus 也未启动。
```

这也是为什么我在 checklist 里把 `P1-4` 标成了“部分完成”，而不是“已完成”。

##### 8. 更贴近中国大厂技术面会怎么追问这一轮

###### 追问 1: 在 Milvus 环境不完整的情况下，你是怎么划定这轮回归验收边界的?

建议回答:

```text
我把这一步拆成了两层:

第一层是我这轮真正改进去的内容，
也就是 document/chunk identity、metadata store、source_ref、citation 文本这条逻辑链有没有接通。

第二层才是完整运行环境里的 Milvus-backed smoke。

当时第一层我已经能通过 fake vector store 把逻辑链验证掉，
但第二层受环境限制跑不起来，
所以我把阶段状态写成“部分完成”，
避免把环境没覆盖到的部分也算成已经通过。
```

###### 追问 2: 为什么这里要用 fake vector store 验证，而不是直接改生产代码或继续等环境?

建议回答:

```text
因为这一步的核心验收点不是 Milvus 检索效果，
而是我刚接进去的对象层和 metadata/citation 延续链有没有工作。

如果为了验证这部分逻辑去改生产实现，
会把“验证边界”和“正式代码边界”搅在一起；
如果只是等环境，
那这轮其实什么也没验证到。

所以我选择用 fake vector store manager 保持生产代码不动，
先把逻辑链路验证掉，再把真实 Milvus 那部分单独记成环境阻塞。
```

###### 追问 3: 你怎么确认这轮改动真正把 metadata/source_ref/citation 链接通了?

建议回答:

```text
我不是只看“能不能跑完”，
而是沿着实际数据链逐项看:

- `DocumentRecord` 里有没有稳定 `doc_id`
- `ChunkRecord` 里有没有 `chunk_id/source_ref`
- LangChain `Document.metadata` 里有没有 `kb_id/doc_id/chunk_id/source_ref`
- `retrieve_knowledge` 返回文本里能不能看到稳定 citation 信息

也就是说，我验证的是“同一份文档身份能不能从上传阶段一直延续到检索输出”，
而不是只看最后有没有返回一段文本。
```

---

## 6. 当前代码改动记录

到目前为止，已经新增或更新的关键文件包括:

| 文件 | 类型 | 作用 |
|---|---|---|
| [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>) | 新增 | P1 最小领域对象模型 |
| [app/models/__init__.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/__init__.py>) | 更新 | 导出新模型 |
| [docs/rag_ingestion_artifact_contract.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/rag_ingestion_artifact_contract.md>) | 已有文档 | 固定 P1/P2 artifact 契约 |
| [docs/weknora_r0_reuse_review.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/weknora_r0_reuse_review.md>) | 已有文档 | 只读复核结果 |
| [docs/weknora_oncall_agent_textbook_guide.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/weknora_oncall_agent_textbook_guide.md>) | 已有文档 | 教材与讲解资料 |
| [docs/technical_fusion_decision_manual.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/technical_fusion_decision_manual.md>) | 已有文档 | 决策与风险手册 |
| [docs/p1_p2_execution_checklist.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/p1_p2_execution_checklist.md>) | 已有文档 | 可执行 checklist |
| [docs/rag_fusion_development_record.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/rag_fusion_development_record.md>) | 新增 | 过程记录与面试素材 |

---

## 7. 面试讲法建议

这一节专门服务“怎么把这个项目讲给面试官听”。

### 7.1 最简洁版本

可以这样讲:

```text
这个项目原本是一个已经能工作的 Python RAG + AIOps 应用，
但知识库层比较轻，只有 md/txt 上传和向量检索。

我没有直接重构主框架，而是先把 WeKnora 当成成熟知识库系统来复核，
确认哪些对象、parser 边界、chunk/service、retrieval 结果值得复用。

然后先固化 artifact contract 和执行顺序，
再开始落最小领域对象模型，
后续按“对象 -> artifact -> 幂等 -> citation”的顺序推进，
目的是在不破坏现有应用主栈的前提下，把它补成更正式的知识库系统。
```

### 7.2 面试官可能追问的问题

#### 问题 1: 为什么不直接接入 WeKnora 服务?

建议回答:

```text
因为当前项目的主价值在 Python 应用层已经跑起来了，
直接接完整 WeKnora 服务会把问题从“补知识库层”变成“系统迁移”，
成本和风险都过高。

当前阶段更稳的做法是复用 WeKnora 成熟边界，
但保留 oncall agent 的应用主栈。
```

#### 问题 2: 为什么先做对象层，不先做 PDF 接入?

建议回答:

```text
因为 PDF 接入会带来 artifact、状态、chunk、citation 等一系列问题。
如果对象层没先固定，后面接进来的东西都会挂在旧散结构上，迟早返工。
所以我先做最小领域对象，是为了后面所有链路有正式落点。
```

#### 问题 3: 你是怎么控制范围、防止项目越做越散的?

建议回答:

```text
我先把路线写成决策手册和执行清单，
明确哪些当前必须做，哪些现在不做，
并且要求每一步都写前置条件、验收标准和风险提示。
这样开发不是靠临场记忆推进，而是靠同一套文档边界推进。
```

#### 问题 4: 如果面试官追问“你在这个项目里除了写方案，真正落了哪些工程结果”?

建议回答:

```text
这些文档不是装饰，而是为了把高风险的架构改造变成可执行工程。
例如在 P1-1 到 P2-3 这条线上，
我已经陆续把文档里的边界落成了:

- `KnowledgeBase / DocumentRecord / ChunkRecord`
- `KnowledgeMetadataStore`
- `ParserEngineRouter`
- `DocumentIngestionService`
- `MinerUParserAdapter`

也就是说，
这些文档不是单独存在的，
而是一路被落实成模型、状态流、上传链路、解析链路和回归测试。
```

---

## 8. 当前未解决问题

这些问题还没有进入实现，后续要继续记录:

- `KnowledgeMetadataStore` 选什么最小落地形式。
- `md/txt` 兼容索引如何把新对象字段稳定回填到 metadata。
- `MinerUParserAdapter` 最终是直接调用共享逻辑，还是先走受控命令。
- `doc_id` 幂等清理如何与现有 `_source` 删除逻辑兼容。
- `RetrievalServiceV2` 如何在不破坏当前 Agent 工具入口的前提下渐进接入。

这些未解问题的存在是正常的，因为它们属于后续阶段，不应该在 P1-1 提前扩做。

---

## 9. 后续记录规则

从现在开始，后续每完成一个任务，都建议按下面模板追加:

```text
阶段:
任务:
目标:
为什么现在做:
参考来源:
实际修改:
遇到的问题:
解决方式:
验收情况:
对面试官怎么讲:
```

这样后面不管是项目复盘还是面试表述，都不会只剩一堆零散记忆。

---

## 10. 阶段 M: P1-4 回归门收口

- 当前状态: 已完成
- 本次目标:
  - 把 `P1-4` 从“脚本级部分验证”收口成可重复执行的正式回归，并补齐 checklist 里尚未打勾的“旧链路响应不回退”。

### 为什么现在做

`P1-4` 在本项目里不是“再看一眼代码”那么简单，
它是 `P2-0` 前的硬门禁。

而此前虽然已经证明:

- `md/txt` 的对象层和 metadata 线接通了
- citation 文本也能带 `doc_id/chunk_id/source_ref`

但还有两件事没有正式收口:

1. 旧 `/api/upload` 响应到底有没有被这轮 P1 改造顺手带坏
2. 当前验证能不能脱离“临时脚本结论”，变成别人接手也能重复跑的检查

### 这一步看到的真实问题

这轮最关键的发现不是 Milvus 没起，
而是旧链路在当前环境下连 import 都可能死掉。

具体导入链是:

```text
app.api.file
-> app.services.vector_index_service
-> app.services.vector_store_manager
-> app.services.vector_embedding_service
```

而原来的实现里:

- `vector_embedding_service` 会在模块导入时立刻创建 DashScope client
- `vector_store_manager` 会在模块导入时立刻初始化 Milvus VectorStore

这会带来两个后果:

1. 只要 `.env` 里没有真实 `DASHSCOPE_API_KEY`，`app.api.file` 就无法导入
2. 即使 `/api/upload` 代码本身已经写了“索引失败只记日志，上传仍算成功”，也会在进入接口前就死在 import 阶段

这说明问题已经不只是“缺环境”，
而是旧链路的可验证性被导入时的强依赖绑死了。

### 我这次实际改了什么

本轮只做了两类最小改动。

#### 1. 把 embedding 初始化从 import 时机延后到首次真实调用

更新了:

- [app/services/vector_embedding_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_embedding_service.py>)

新增了 `LazyDashScopeEmbeddings`，
保留原有 `vector_embedding_service` 对外名字不变，
但把真正的 `DashScopeEmbeddings(...)` 创建推迟到:

- `embed_documents(...)`
- `embed_query(...)`

首次被调用时。

这样我没有改外部接口，
只是把“没有 key 就立刻炸”改成“真正要做 embedding 时再校验 key”。

#### 2. 把 Milvus VectorStore 初始化从 import 时机延后到首次真实使用

更新了:

- [app/services/vector_store_manager.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_store_manager.py>)

具体做法是:

- 去掉 `__init__()` 里立刻 `_initialize_vector_store()`
- 增加 `_ensure_vector_store()`
- 在 `add_documents()` / `get_vector_store()` / `similarity_search()` 里按需初始化
- 在 `delete_by_source()` 里显式 `milvus_manager.connect()` 再取 collection

这一步仍然没有改上传接口协议、切分逻辑、metadata 结构，
只是把旧链路的外部依赖从“导入就强连”改回“用到时再连”。

### 为什么选这条小改法，而不是做更大重构

这里其实有更重的做法，
比如直接抽一层完整的 dependency injection，或者重做 vector/search service 装配方式。

但那已经不是 `P1-4` 了，
会把当前门禁工作扩成架构重整。

这一步更合适的做法是:

```text
不改旧接口，
不改 md/txt 主链路算法，
只把导入时的强依赖推迟到真实调用时。
```

这样补的是“可验证性”和“旧响应不回退”，
不是提前做 P2/P3 的结构升级。

### 这轮正式补了哪些回归

新增:

- [tests/test_p1_4_regression.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_p1_4_regression.py>)

注意这次没有用 `pytest`，
而是改成了 `unittest`，
原因不是风格偏好，而是当前 `.venv` 里并没有安装 `pytest`。

我最终落了 3 个可重复执行的回归:

#### 1. `md/txt` 索引后的 metadata enrichment 回归

验证点:

- `doc_id` 稳定生成
- `chunk_id` 稳定生成
- `source_ref` 已落到 `ChunkRecord`
- LangChain `Document.metadata` 里同时保留:
  - `kb_id`
  - `doc_id`
  - `chunk_id`
  - `_source`
  - `_file_name`
  - `_extension`

这里仍然沿用了 fake vector store manager，
因为这条回归要验证的是 P1 加进去的对象层与 metadata 线，
不是外部 embedding 服务质量。

#### 2. 旧 `/api/upload` 成功响应形状回归

验证点:

- Markdown 文件上传仍返回 `200`
- 响应主结构仍是:
  - `code`
  - `message`
  - `data`
- `filename / file_path / size` 仍然可见
- 索引函数仍会收到保存后的文件路径

#### 3. 旧 `/api/upload` 在索引失败时的兼容行为回归

验证点:

- 即使 `index_single_file()` 抛错
- 文件上传仍成功
- 返回仍是 `200 + success`
- 文件实际已经保存到上传目录

这条很重要，因为它直接对应当前接口代码里已经存在的兼容语义:

```text
上传成功和索引成功不是同一个结果层级，
索引失败只记日志，不应把上传接口主响应改成直接失败。
```

### 这轮遇到的一个很实际的小坑

我原本想直接继续用 `pytest` 跑，
但当前项目 `.venv` 里并没有装 `pytest`。

检查结果是:

```text
.venv/bin/pytest -> not found
.venv/bin/python -m pip show pytest -> Package(s) not found
```

如果这时为了跑测试再去拉 dev 依赖，
会把 `P1-4` 门禁工作扩成环境安装问题。

所以这次我没有把问题转成“装更多东西”，
而是把这组回归用例写成标准库 `unittest`，
保证:

- 当前 `.venv` 直接能跑
- 不增加新的外部依赖
- 其他人接手也能重复执行

### 这次实际怎么验的

本轮我实际执行了:

```bash
.venv/bin/python -c "import app.api.file; print('ok')"
.venv/bin/python -m unittest tests.test_p1_4_regression -v
.venv/bin/python -m compileall app tests
```

其中第二条跑过了 3 条回归:

- `test_index_single_file_enriches_chunk_metadata_with_stable_ids`
- `test_upload_keeps_success_response_shape_for_markdown`
- `test_upload_still_returns_success_when_indexing_fails`

全部通过。

### 这轮后的真实结论

这次之后，
`P1-4` 可以从“部分完成”更新为“已完成”。

理由不是“外部环境终于齐了”，
而是:

1. `md/txt` 逻辑级回归已经有正式测试
2. 旧 `/api/upload` 响应兼容性已经有正式测试
3. 当前 P1 checklist 的门禁关注点是“旧行为不回退”，这次已经被可重复证据覆盖

同时我也保留了一个诚实的环境备注:

```text
当前工作站依然没有 live Milvus + DashScope smoke 条件，
因为 localhost:19530 未开放，DASHSCOPE_API_KEY 也未就绪。
```

但这条现在属于环境 readiness note，
不是继续卡住 `P1-4` 的 merge blocker。

### 更贴近中国大厂技术面会怎么追问这一轮

#### 追问 1: 你是怎么定位到旧上传链路在当前环境下会死在 import 阶段的?

建议回答:

```text
我不是先猜“环境有问题”，
而是顺着 import 链一层层看:

app.api.file
-> vector_index_service
-> vector_store_manager
-> vector_embedding_service

然后我实际跑 `.venv/bin/python -c "import app.api.file"`，
拿到的是缺少 `DASHSCOPE_API_KEY` 时在模块导入阶段直接抛错。

这说明问题不只是“运行时没配环境”，
而是旧链路的可测试性已经被导入时强依赖卡死了。
```

#### 追问 2: 为什么这里选择 lazy init，而不是做一轮更大的依赖注入重构?

建议回答:

```text
因为当前阶段的目标很窄，
我要修的是“旧链路在缺省环境下无法导入和验证”，
不是趁机重做整个 service 装配方式。

lazy init 的好处是:

- 不改对外接口
- 不改上传响应
- 不改切分和 metadata 结构
- 只把强依赖从 import 时机推迟到首次真实调用

它正好解决当前问题，而且改动面最小。
```

#### 追问 3: 你怎么证明这个修复没有把旧上传行为带坏?

建议回答:

```text
我不是只做了 import 测试，
还补了两类行为回归:

- 正常上传时，`/api/upload` 仍然返回原来的成功 envelope
- 索引失败时，上传接口仍然保持 success 语义，只把失败落到内部状态和日志

同时还保留了 md/txt metadata enrichment 的回归，
所以我验证的是“旧接口表面行为 + 内部 identity/metadata 链”两层都没坏。
```

---

## 11. 阶段 O: P2-0 执行前检查

- 当前状态: 已完成
- 本次目标:
  - 按 checklist 严格确认 `P2-0` 的三个前置条件是否已经满足，只做放行核查，不提前进入 `P2-1` 实现。

### 这一步为什么单独记

`P2-0` 看起来像文档动作，
但它在这个项目里其实是“能不能正式进入 P2”的放行门。

如果这里不把依据写清楚，
后面很容易出现两种问题:

1. 明明已经在决策文档里确认过的前提，又在实现前被反复重谈
2. 清单状态和项目状态文件不一致，导致后续开发者不知道下一步到底从哪开始

### 这轮实际核查了什么

这次我只核对了 3 个条件，对应 checklist 原文:

1. `P1-4` 已完成
2. 已接受 `pdf_eval` 产物语义是主项目运行标准
3. 已明确 `.md/.txt -> plain_text`，`.pdf/.docx/.xlsx -> mineru` 是固定主路由

### 具体证据落在哪

#### 1. `P1-4` 已完成

证据在:

- [docs/p1_p2_execution_checklist.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/p1_p2_execution_checklist.md>)
- [PROJECT_STATE.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/PROJECT_STATE.md>)

其中 `PROJECT_STATE.md` 已明确写到:

```text
P1-0 through P1-4 are now complete in the app layer
```

所以这条前置条件已经满足，不再是待确认项。

#### 2. 已接受 `pdf_eval` 产物语义作为运行标准

证据在:

- [docs/technical_fusion_decision_manual.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/technical_fusion_decision_manual.md>)

这份手册在固定决策表里已经明确写了:

```text
是否接受 `pdf_eval` 的 MinerU 产物语义作为主项目运行时标准? -> 接受
```

这不是推断，
而是已经被锁进执行手册的决策。

#### 3. 主路由规则已明确

证据同样在:

- [docs/technical_fusion_decision_manual.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/technical_fusion_decision_manual.md>)

控制方式里已经写明:

```text
.md/.txt -> plain_text
.pdf/.docx/.xlsx -> mineru
```

也就是说，
`P2-0` 缺的不是“方向没定”，
而是“还没把这个固定路由正式落成代码”。

这恰好就是下一步 `P2-1 ParserEngineRouter 固化` 的工作边界。

### 这轮后的结论

这一步之后，
`P2-0` 可以正式从 `未开始` 更新为 `已完成`。

同时要把下一步入口切换成:

```text
P2-1 ParserEngineRouter 固化
```

而不是继续停留在“再讨论要不要接受 pdf_eval 语义”或者“再讨论主路由该怎么定”。

### 如果按中国大厂项目深挖来问：你怎么判断一个阶段已经具备继续推进的条件?

建议回答:

```text
我不是按感觉说“差不多可以继续了”，
而是对照执行清单，把前置条件一条条落到项目里的证据文件上。

像 P2-0 这一步，我确认的不是实现是否已经开始，
而是后续实现依赖的关键前提有没有被正式锁定。

只有当 P1-4 完成、pdf_eval 语义被接受、主路由规则被明确后，
我才把 P2-0 标成完成，并把下一步切到 P2-1。
```

#### 追问 2: 如果 checklist 上写了，但项目里还没有对应证据文件，你会怎么判?

建议回答:

```text
那我不会把它当成真正完成。

对我来说，checklist 只是待办或验收标准，
真正能证明阶段可推进的，还是仓库里已经落地的文件、代码和测试结果。
```

#### 追问 3: 为什么这种“是否具备继续推进的条件”不能只靠感觉判断?

建议回答:

```text
因为感觉无法复现，也不方便交接。

把前置条件写成证据文件后，
后面别人接手时也能直接看到为什么这一阶段可以推进，而不是重新猜。
```

---

## 11A. 记录的面试适配性审查

- 当前状态: 已完成
- 本次目标:
  - 不只修“问题怎么问”，还检查这份开发记录的叙述结构本身是否更有利于真实技术面试的深挖。

### 当前这份记录里对面试有利的部分

从项目 deep dive 的角度看，
这份记录已经有几个明显优点:

1. 阶段边界清楚  
   P1 / P2、每一步的前置条件、验收和风险都比较明确，适合回答“你怎么拆阶段、怎么控 scope”。

2. 代码落点清楚  
   大部分阶段都能明确说出改到了哪个文件、哪个类、哪个函数，这很适合回答“你具体做了什么，不是只在写方案吧”。

3. 验证链条清楚  
   `unittest`、compile、真实 smoke、环境阻塞都被分开记录，适合回答“你怎么验证”和“你怎么区分逻辑问题与环境问题”。

4. 风险意识清楚  
   不是只写 happy path，而是会把故意留到下一阶段的风险单独说明，适合回答“为什么这一步到这里就停”。

### 当前这份记录里对面试不够友好的部分

如果完全不修，
这份记录还是有几个地方容易让面试表达显得“太像项目管理记录，而不够像技术复盘”:

1. 有些问题太自指  
   比如“为什么不直接说通过了”，更像写文档时自我辩解，不像面试官真实会问的话。

2. 有些段落太强调阶段状态  
   比如“能不能放行”“为什么先不标完成”，这些在项目内部是有价值的，
   但面试时更自然的问法通常是“你怎么划定验收边界”“你怎么决定先做什么、后做什么”。

3. 价值表达还可以更贴近业务/系统结果  
   现在很多段落已经能说清技术细节，
   但还可以继续多强调“这个改动解决了什么真实系统风险”，而不是只说“状态从 A 变到 B”。

### 这次调整的方向

所以这次我做的不是只改字面问题，
而是把 interview-QA 的组织方式往下面几类真实高频追问上靠:

- 技术选型与 trade-off
- 调试路径与定位方法
- 验证方法与证据强度
- 风险是怎么被拆解和关闭的
- 个人负责的关键代码边界
- 如果重做一次，哪里会换实现方式

### 后续还应继续保持的写法

从现在开始，
如果后面继续追加新的阶段记录，
更有利于大厂面试的写法应该优先满足这三条:

1. 先说“解决了什么真实技术问题”，再说“阶段状态变成什么”
2. 先说“为什么选这个方案”，再说“另一个方案为什么没选”
3. 先给“代码证据 + 验证证据”，再给“我怎么讲给面试官听”

这样这份文档读起来会更像:

```text
一个工程师做复杂项目时的真实技术决策与验证轨迹
```

而不是:

```text
一份只有内部阶段状态更新意义的项目推进流水账
```

## 11B. 中国大厂高频追问补位

- 当前状态: 已完成
- 本次目标:
  - 补上这份项目当前最容易被中国大厂技术面继续追问、但原记录里还不够强的几个维度：高并发、大文件、失败恢复、幂等、可观测性。

### 1. 如果问到高并发：你这套链路并发上来会先卡在哪里?

建议回答:

```text
现在这套实现还不是面向大并发最终态，
我会先明确指出瓶颈，而不是空口说它能扛住。

当前最先会暴露的问题有三类：

第一，`KnowledgeMetadataStore` 现在还是单机 JSON 文件 + 进程内 `RLock`，
它适合当前开发阶段的单实例流程验证，
但不适合多实例并发写 document/chunk 生命周期。

第二，上传和解析产物现在都先落本地磁盘，
如果并发文档数和大文件数同时上来，
磁盘 IO、目录扫描和 CLI 子进程竞争都会成为瓶颈。

第三，MinerU 路径是重 CPU / 重 IO 的解析任务，
如果直接跟在线请求线程绑死，并发一高响应时间会抖得很厉害。

所以我当前阶段做的不是假装它已经高并发可用，
而是先把并发治理真正需要的边界拆出来：
稳定 `doc_id`、正式状态流、parser route、artifact_dir、失败状态和重试入口。

这让后面可以自然演进到：
metadata 落 SQLite/Postgres，
解析进任务队列，
按 `doc_id` 做串行化或幂等控制，
而不是在一条扁平上传链路上硬堆并发补丁。
```

### 2. 如果问到大文件：大 PDF / 大 Office 文件进来，你现在怎么扛?

建议回答:

```text
现在这套流程对“大文件可处理”和“大文件高效处理”要分开看。

可处理层面：
我已经把原件、raw 输出、postprocess 产物全都按 `doc_id` 拆到独立 artifact 树下，
所以单个大文件至少不会和别的文档产物互相污染。

但效率层面我会诚实承认，当前还有两个明显短板：

第一，`/api/upload` 现在还是先把整个文件读进内存再交给 ingestion service；
这对开发阶段够用，但不是大文件最终态。

第二，MinerU 解析现在虽然已经从上传入口解耦，
但 CLI 调用依然是重任务，真正的异步化和任务排队还没做。

所以如果面试官问“你现在是不是已经把大文件问题解决了”，
我不会这么说。

我会说：
我当前解决的是大文件正式进入系统后的身份、目录、状态和失败边界；
而大文件的流式上传、异步调度、资源隔离，是后面要继续补的工程能力。
```

### 3. 如果问到失败恢复：解析失败之后怎么恢复，不会留下脏状态吗?

建议回答:

```text
这一块现在已经比最开始强很多了，
因为失败不再只是打一条日志，而是有正式状态和落点。

当前文档生命周期已经有：

- `upload_failed`
- `parse_failed`
- `index_failed`

而且 `DocumentRecord` 会把：

- `original_path`
- `artifact_dir`
- `error_message`

都保留下来。

这意味着解析失败之后，
我至少还能知道是哪份文档、卡在哪一阶段、原件和中间产物落在哪里。

另外，`DocumentIngestionService.process_deferred_document(doc_id)` 也已经存在，
说明这条链路在设计上已经允许“文档先入系统，后续再继续处理”，
不是一次请求里成败全绑死。

如果面试官再追问“那自动重试呢”，
我会明确说：当前还没有完整的 retry scheduler / backoff 机制，
但状态机和重处理入口已经先接出来了，
后面补任务队列时会比一开始容易很多。
```

### 4. 如果问到幂等：重复上传、重复解析、重复索引怎么避免脏数据?

建议回答:

```text
这个项目现在的幂等要分 legacy `md/txt` 和新文档链路两块说。

legacy `md/txt`：
我已经让它具备稳定 `doc_id`，
而且索引时会按 `_source` 删除旧向量、按 `doc_id` 删除旧 chunk，
所以同一路径文件重复进索引，不会一直堆脏 chunk。

新文档链路：
当前 `doc_id` 是基于 `kb_id + safe_filename + content_hash` 生成的，
这样同一内容的同名上传可以保持稳定身份，
而不是每次随机生成一个新文档。

但我要诚实补一句：
现在真正完整的“按 doc_id 清旧索引 + 清旧解析产物 + 重新入库”的统一幂等收口，
还要靠后面的 `P2-6 doc_id 幂等清理` 去做。

也就是说，
我当前已经把幂等真正依赖的前置条件都搭好了：
稳定 `doc_id`、document status、chunk replace、deferred processing 入口；
但最终一致性的硬收口，我不会提前冒充已经全部完成。
```

### 5. 如果问到可观测性：线上出了问题，你现在靠什么定位?

建议回答:

```text
当前这套系统的可观测性已经有基础，但还不是“大厂完整平台化”的水平。

现在已经有的东西主要是三层：

第一层，状态可观测：
`DocumentRecord.status` 能告诉我文档卡在 uploaded / parsing / parsed / indexing 的哪一段。

第二层，错误可观测：
`error_message` 会保留解析或索引阶段的失败原因，
MinerU CLI 失败时我也会把 stdout/stderr 带出来，而不是只抛一个 exit code。

第三层，产物可观测：
每份文档都有自己的 `original_path`、`artifact_dir`、`raw_output_dir`、`markdown_path`，
所以排障时我能直接去看原件、raw 输出、postprocess 结果，而不是靠猜。

但如果面试官问“那 metrics / tracing / dashboard 呢”，
我不会说已经有。

当前还没有完整的：

- 各阶段耗时指标
- 失败率统计
- parser 级 SLA
- artifact 完整性仪表盘
- trace/span 级链路观测

我会把这部分定义成：
当前可观测性已经足够支撑开发和功能验收，
但离大厂线上系统期望的 metrics + tracing + alerting 还有距离。
```

### 6. 这些补位内容对当前开发记录的反思

如果站在中国大厂项目深挖的角度回看，
原来的开发记录有一个明显问题：

```text
阶段、状态、边界写得已经比较好，
但“规模化、失败场景、恢复路径、观察手段”这些面试高频点写得还不够集中。
```

这会导致两个后果：

1. 你自己其实做了不少正确的边界设计，
   但文档没有把这些设计提炼成“能直接回答大厂面试”的语言。
2. 面试官一旦开始追“如果量上来怎么办、失败后怎么恢复、怎么证明不是偶然跑通”，
   你要临场现编，而不是从记录里直接提炼。

所以从面试友好性看，
后续开发记录应该继续维持两层写法：

- 第一层: 你这一步改了什么代码、跑了什么验证
- 第二层: 这些改动在高并发/失败恢复/幂等/可观测性上意味着什么

这样这份记录才不只是“过程可追踪”，
而是“天然可转成大厂面试里的项目讲法”。

---

## 12. 阶段 P: P2-1 ParserEngineRouter 固化

- 当前状态: 已完成
- 本次目标:
  - 把文档里已经定死的 parser 主路由正式落成代码边界，并补齐可重复回归，不提前扩进 `P2-2` 的上传工作流改造。

### 为什么这一步不能继续只停在文档里

到 `P2-0` 为止，
我们已经确认过:

- `pdf_eval` 产物语义被接受为运行标准
- 主路由是 `.md/.txt -> plain_text`，`.pdf/.docx/.xlsx -> mineru`

但如果这一步还只存在于手册里，
后面就会出现一个很典型的问题:

```text
大家都知道“应该这么走”，
但真正实现时还是可能在不同模块里各写一段 extension 判断，
最后 upload、adapter、indexer 三边规则各不一样。
```

所以 `P2-1` 的真正目的不是“先支持 PDF 上传”，
而是先把“谁来决定 parser_engine”这件事收成正式边界。

### 这轮为什么没有去改上传 API 范围

这里有个很容易误入的扩做方向:

```text
既然路由已经写出来了，
那是不是顺手把 /api/upload 也放开到 pdf/docx/xlsx？
```

我这轮刻意没这么做，
因为那已经会进入 `P2-2 DocumentIngestionService` 的职责:

- 保存原件
- 创建 `DocumentRecord`
- 选择 parser
- 管状态流
- 校验 artifact

如果在 `P2-1` 就把上传入口放开，
就会出现“路由有了，但 ingestion/status/artifact 还没接住”的半接入状态。

所以这一步我只做:

```text
先把 route formalize，
不改当前 public upload boundary。
```

### 这轮实际改了什么

#### 1. 新增正式路由边界

新增:

- [app/services/parser_engine_router.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/parser_engine_router.py>)

这里的核心不是“写 if/else”，
而是把 WeKnora 那套思路最小 Python 化:

- 固定默认规则
- 独立 service 边界
- 可列举的 engine descriptor
- 保留配置覆盖入口

默认规则现在已经是正式代码:

```text
md/txt   -> plain_text
pdf/docx/xlsx -> mineru
```

#### 2. 保留 `ParserEngineRule` / `ResolveParserEngine()` 的覆盖缝

我没有把 router 写成完全硬编码、以后没法接知识库配置的形状。

这轮继续复用了 P1 已经落好的:

- `ParserEngineRule`
- `ChunkingConfig.resolve_parser_engine()`

并让 router 优先吃:

```text
chunking_config.parser_engine_rules
```

如果没有配置覆盖，
再退回当前阶段的固定默认规则。

这一步很重要，
因为它保证了:

- 当前阶段的固定主路由已经被锁定
- 未来如果知识库配置要做细化，也不用推翻这层边界

#### 3. 补了 `ParserEngineInfo` 风格描述结构

在:

- [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>)

里新增了 `ParserEngineInfo`，
并通过:

- [app/models/__init__.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/__init__.py>)

导出。

我这里没有提前做真实 availability 检查，
但已经把后续会用到的结构形状定住了:

- `name`
- `description`
- `file_types`
- `available`
- `unavailable_reason`

这就是 checklist 里说的“为后续可用性检查预留 `ParserEngineInfo` 风格描述”。

#### 4. 让现有索引路径真的开始吃 router

更新了:

- [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)

这一步很关键，
因为如果 router 只是个新文件、没被现有链路消费，
那它还是“半死代码”。

我这次具体改成了:

- `index_single_file()` 先通过 `parser_engine_router.resolve_path(path)` 得到 `parser_engine`
- `DocumentRecord.parser_engine` 不再继续硬编码 `plain_text`
- `ChunkRecord.source_ref.parser_engine` 和 chunk metadata 里的 `parser_engine` 也统一吃同一个解析结果

虽然当前 public path 还只有 `md/txt`，
解析出来还是 `plain_text`，
但路由边界已经被真正接上了。

### 为什么我认为这是“最小可接受实现”

如果只新增一个 `parser_engine_router.py`，
却不让当前链路消费它，
这一步很容易沦为“为将来准备”的装饰性代码。

如果反过来顺手放开 PDF 上传，
那又会越界冲进 `P2-2`。

所以这轮真正平衡的位置是:

```text
路由正式化 + 当前链路开始消费 + public upload boundary 先不变
```

这正好对应 `P2-1`，不会偷跑到后续阶段。

### 这轮正式补了哪些回归

新增:

- [tests/test_parser_engine_router.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_parser_engine_router.py>)

这次我仍然沿用 `unittest`，
原因跟 `P1-4` 一样:

- 当前 `.venv` 里没有 pytest
- 我需要的是当前环境立刻可跑的正式门禁，而不是再拉一层工具依赖

这轮回归包含 6 类检查:

#### 1. 固定主路由命中

验证:

- `.md -> plain_text`
- `.txt -> plain_text`
- `.pdf -> mineru`
- `.docx -> mineru`
- `.xlsx -> mineru`

#### 2. 支持扩展名集合稳定

验证 `supported_file_types()` 返回:

```text
["md", "txt", "pdf", "docx", "xlsx"]
```

这条是为了保证后面做 `P2-2` 时，
不会在别的模块里偷偷长出一组不同的文件类型集合。

#### 3. 配置覆盖缝有效

验证 `ChunkingConfig.parser_engine_rules` 可以覆盖默认规则，
例如把 `pdf` 临时改成 `plain_text` 时，router 确实会优先吃配置。

这一步不是为了当前业务要改路由，
而是为了确认 P1 提前落下的 `ParserEngineRule` 不是摆设。

#### 4. `ParserEngineInfo` 形状稳定

验证 `plain_text` 和 `mineru` 都能返回:

- `name`
- `description`
- `file_types`
- `available`
- `unavailable_reason`

#### 5. 不支持类型时报错清晰

验证像 `csv` 这种当前不在 P2 主路由里的类型，
会抛出清晰的 `ValueError`，
而不是偷偷走某个默认引擎。

这条很关键，
因为契约已经明确禁止“静默回退”。

#### 6. 现有 md/txt 索引路径已消费 router

最后一条回归不是只测 router 自己，
而是验证:

- `VectorIndexService.index_single_file()`

在处理 legacy `txt` 样本时，
`DocumentRecord.parser_engine` 已经来自 router 结果，而不是继续吃旧硬编码。

### 这轮我实际跑了什么

本轮实际执行:

```bash
.venv/bin/python -m unittest tests.test_parser_engine_router -v
.venv/bin/python -m unittest tests.test_p1_4_regression -v
.venv/bin/python -m compileall app tests
```

结果:

- 新增的 `P2-1` 路由回归 6 项全部通过
- 之前的 `P1-4` 回归 3 项继续通过
- 编译检查通过

这说明这次改动没有把之前收口好的 `md/txt` 边界碰坏。

### 这轮后的真实结论

`P2-1` 现在可以标记为完成。

因为 checklist 关心的三件事都已经满足:

1. 固定主路由已落成代码
2. `ParserEngineInfo` 风格描述已预留
3. 不同扩展名命中的 engine 已可预测、可复现

同时我也刻意保留了一个明确边界:

```text
当前 public upload API 仍然只支持 md/txt；
pdf/docx/xlsx 的真实接入、状态流和 artifact 工作流属于 P2-2。
```

### 如果按中国大厂项目深挖来问：这一轮代码量不大，但真正解决了什么工程问题?

建议回答:

```text
表面上像是在写扩展名映射，
但真正重要的是把 parser 选择从“散在各模块的隐式判断”
收成了一个正式边界。

我参考了 WeKnora 的 ParserEngineRule / ResolveParserEngine / engine registry 结构，
在 Python 里落了最小 Router，
同时让现有索引路径开始真正消费这个边界，
并补了可重复的回归测试。

这样后面接 P2-2 的 ingestion 和 P2-3 的 MinerU adapter 时，
就不会再出现每一层都自己判断一次文件类型的分叉风险。
```

#### 追问 2: 为什么要把 parser 选择收成正式边界，而不是继续散在各模块里?

建议回答:

```text
因为散在各模块的判断会让每一层都重复写文件类型逻辑，
后面只要再加一个 parser，改动面就会继续扩散。

把 parser 选择收成正式边界后，
后续扩展只需要改 router，不会再把上传、索引和解析耦成一团。
```

#### 追问 3: 这一轮怎么保证 md/txt 兼容没有被打坏?

建议回答:

```text
我保留了 legacy md/txt 的主路径，
并且通过回归测试验证扩展名命中和旧索引行为仍然可预测、可复现。

这一步不是重写旧链路，
而是在旧链路上先建立 parser 决策边界。
```

---

## 14. 阶段 Q: P2-2 DocumentIngestionService 落地

- 当前状态: 已完成
- 本次目标:
  - 把上传保存、`DocumentRecord` 建立、parser 选择、状态推进和后续索引触发收成正式 ingestion 工作流，同时明确把 MinerU 真实解析留给 `P2-3`。

### 为什么这一步不能继续靠 `/api/upload` 里临时拼

在 `P2-1` 之前，
当前上传链路基本还是:

```text
保存文件 -> 直接 index_single_file()
```

这对 legacy `md/txt` 来说还能工作，
但一旦要把 PDF/DOCX/XLSX 变成正式输入，
这个路径就会立刻不够用。

因为你至少要有这些正式落点:

- 原件存哪
- `doc_id` 怎么来
- `artifact_dir` 怎么定
- `parser_engine` 谁说了算
- 状态怎么从 uploaded 推进到 parse/index

如果这些还分散在 `/api/upload` 里临时拼，
后面 `P2-3` 接 MinerU adapter 时一定会返工。

### 这轮实际做了什么

#### 1. 新增 `DocumentIngestionService`

新增:

- [app/services/document_ingestion_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/document_ingestion_service.py>)

这一步把原来的“上传后临时做几件事”收成了一个正式服务，
责任是:

- 规范化文件名
- 生成 `doc_id`
- 保存原件到 canonical 路径
- 建立 `DocumentRecord`
- 通过 `ParserEngineRouter` 选择 parser
- 决定后续走 plain-text 同步链，还是进入 MinerU 的 `parse_pending`

#### 2. canonical 原件路径和 artifact 根目录已经落成代码

现在原件和 artifact 目录不再是隐含约定，
而是正式由 service 生成:

```text
uploads/documents/<kb_id>/<doc_id>/original/<safe_filename>
uploads/documents/<kb_id>/<doc_id>/artifacts
```

这正对应 artifact contract 里的目录语义。

#### 3. 生成 `DocumentRecord.original_path` / `artifact_dir`

这一轮不只是存文件，
而是在文档真正进入系统时就把下面这些字段一起落下来:

- `doc_id`
- `kb_id`
- `file_name`
- `file_ext`
- `original_path`
- `artifact_dir`
- `parser_engine`
- `status`

这意味着文档不再只是“磁盘上某个文件 + 将来再猜它属于谁”，
而是第一次以正式 document identity 进入主项目。

#### 4. plain-text 分支已经走正式状态流

当前 `plain_text` 分支现在会经过:

```text
uploaded
-> parse_pending
-> parsing
-> parsed
-> index_pending
-> indexing
-> indexed
```

这里我没有新写一套文本 parser，
而是让 ingestion 服务把状态推进和 document identity 先接好，
然后交给已有的索引层继续完成 plain-text 路径。

#### 5. `VectorIndexService` 学会消费已有 `DocumentRecord`

更新了:

- [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)

这次新增了:

```text
index_document_record(document_record)
```

这一步很重要，
因为如果索引层只能吃“裸 file_path”，
那新的 ingestion 服务还得把刚建好的 `DocumentRecord` 丢掉重算一遍，
身份和状态就又散了。

我现在让索引层可以直接消费已有 `DocumentRecord`，
所以:

- 上传阶段生成的 `doc_id`
- 上传阶段选定的 `parser_engine`
- 上传阶段写好的 `original_path/artifact_dir`

都能继续沿用，不需要重新拼。

#### 6. `/api/upload` 已正式走 ingestion 服务

更新了:

- [app/api/file.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/api/file.py>)

现在上传接口不再自己保存文件后直接调 `index_single_file()`，
而是改成:

```text
读取内容 -> 进入 DocumentIngestionService -> 返回正式文档结果
```

同时我保留了旧响应的主结构:

- `code`
- `message`
- `data`

只是把 `file_path` 切成了 canonical `original_path`，
并新增了:

- `doc_id`
- `parser_engine`
- `status`
- `artifact_dir`

### 为什么我让 MinerU 分支现在停在 `parse_pending`

这一步最容易被误会成“P2-2 没做完”，
但其实这是刻意保留的阶段边界。

原因很简单:

`P2-2` 的职责是正式 ingestion 工作流，
不是 MinerU adapter 本身。

所以这轮我选择的是:

```text
让 PDF/DOCX/XLSX 先正式进入系统，
拥有 canonical original_path / doc_id / artifact_dir / parser_engine / parse_pending；
但不假装自己已经完成了 MinerU 解析。
```

也就是说，
MinerU 路径现在不是“没接住”，
而是“被正式接住后，明确停在 parse_pending，等待 P2-3”。

这比偷偷回退到 plain_text，
或者假装已经 parsed，
都要诚实得多。

### 这轮正式补了哪些回归

新增:

- [tests/test_document_ingestion_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_document_ingestion_service.py>)

这轮回归包括:

#### 1. plain-text 文档进入正式接入链路并完成索引

验证:

- 原件落到 canonical `uploads/documents/.../original/...`
- `artifact_dir` 创建完成
- `parser_engine=plain_text`
- 文档最终状态到 `indexed`

#### 2. MinerU 路径正式入系统但停在 `parse_pending`

验证:

- `manual.pdf` 能被正式接收
- `parser_engine=mineru`
- 不调用 plain-text 索引器
- 状态停在 `parse_pending`

#### 3. API 级 PDF 上传已被正式接受

验证 `/api/upload` 已接受 `pdf`，
并返回:

- `doc_id`
- `parser_engine=mineru`
- `status=parse_pending`
- canonical `file_path`
- `artifact_dir`

### 这轮我还回归了之前的边界

我没有只跑新测试，
还重新跑了:

```bash
.venv/bin/python -m unittest tests.test_parser_engine_router -v
.venv/bin/python -m unittest tests.test_p1_4_regression -v
```

其中我还同步更新了:

- [tests/test_p1_4_regression.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_p1_4_regression.py>)

让它适应“上传接口现在改走 ingestion 服务，但主响应 envelope 和成功语义不变”的新现实。

### 这轮实际跑了什么

本轮实际执行:

```bash
.venv/bin/python -m unittest tests.test_document_ingestion_service -v
.venv/bin/python -m unittest tests.test_parser_engine_router -v
.venv/bin/python -m unittest tests.test_p1_4_regression -v
.venv/bin/python -m compileall app tests
```

全部通过。

### 这轮后的真实结论

`P2-2` 可以标为完成。

因为 checklist 要求的几件事已经满足:

1. 上传目录与 artifact 目录结构已经固定
2. `DocumentRecord.original_path` / `artifact_dir` 已生成
3. 状态流已经不是“上传后立刻索引”的临时路径

但这里有一条风险我刻意没有标完成:

```text
接入服务存在，但状态流仍然不闭合
```

这条现在只能算“部分缓解”，
因为:

- `plain_text` 分支已经闭环
- `mineru` 分支还要等 `P2-3` 接 adapter 才能从 `parse_pending` 真正走到 `parsed/index_pending`

所以我在 checklist 里把这条风险继续保留成未完成，
而不是把阶段完成误写成“所有分支都闭环了”。

### 如果按中国大厂项目深挖来问：为什么这一步算完成了，但你没有把 MinerU 分支也算闭环?

建议回答:

```text
因为我区分了“阶段目标完成”和“所有后续风险都归零”。

P2-2 的目标是把上传、原件保存、文档身份、parser 选择、状态推进
收成正式 ingestion 工作流。
这一步已经完成了。

但 MinerU 的真实解析闭环属于下一步 P2-3 的职责，
所以我把 MinerU 文档诚实地停在 parse_pending，
并把那条风险继续保留为未完成。

这样阶段边界和风险边界是清楚的，不会把后续工作偷算进当前阶段。
```

#### 追问 2: 为什么 ingestion 要负责 doc_id、artifact_dir 和状态推进，而不是继续塞在 upload handler 里?

建议回答:

```text
因为 upload handler 适合做请求入口，不适合承载文档生命周期管理。

把 doc_id、artifact_dir 和状态流放进 ingestion service，
后面 parser、索引和异常处理都能围绕同一个文档对象工作。
```

#### 追问 3: 这样拆出来之后，后面接 MinerU 分支为什么更稳?

建议回答:

```text
因为上传链路和 parser 语义已经分开了。

后面 MinerU 再怎么调整 CLI、postprocess 或输出目录，
都只会影响 parser adapter，不会把 `/api/upload` 一起拖着重改。
```

---

## 15. 阶段 R: P2-3 MinerUParserAdapter 接入

- 当前状态: 已完成
- 本次目标:
  - 给 `mineru` 分支接上真实 parser adapter，把文档从 `parse_pending` 推到 `parsing -> parsed -> index_pending`，同时继续沿用 `pdf_eval` 已验收的后处理语义。

### 为什么这一步不能直接写在 `DocumentIngestionService` 里

`P2-2` 已经把上传和文档身份接住了，
但如果这一步把 MinerU CLI 调用、raw 输出定位、postprocess 复用、parse 失败处理都直接塞回 ingestion service，
后面会很快出现两个问题:

1. upload 语义和 parser 语义重新耦死
2. 一旦 MinerU 参数、raw 输出格式或后处理入口调整，改动面会散回上传层

所以这一步我还是单独立了:

- [app/services/mineru_parser_adapter.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/mineru_parser_adapter.py>)

让“怎么调 MinerU”成为正式边界。

### 这轮实际做了什么

#### 1. 主项目里新增了 `MinerUParserAdapter`

它现在负责:

- 校验 `DocumentRecord.parser_engine == mineru`
- 把状态推进到 `parsing`
- 调本地 MinerU CLI
- 定位 raw 输出目录和 Markdown 文件
- 调 `pdf_eval/scripts/mineru_postprocess.py`
- 把状态推进到 `parsed -> index_pending`
- 在失败时写回 `parse_failed`

#### 2. 参数和入口已经接入主项目配置

我在:

- [app/config.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/config.py>)

里新增了 MinerU 相关配置，包括:

- `mineru_cli_path`
- `mineru_api_url`
- `mineru_method`
- `mineru_backend`
- `mineru_language`
- `mineru_enable_formula`
- `mineru_enable_table`
- `mineru_mplconfigdir`
- `mineru_postprocess_script_path`

这一步对应 checklist 里的“对接主项目配置与本地 artifact 目录”。

#### 3. raw 输出落在文档自己的 artifact 树下

当前 raw 输出目录已经是:

```text
<artifact_dir>/raw/<stem>/auto/
```

也就是说，
MinerU 原始产物不再需要借道 `pdf_eval/outputs/` 历史实验目录。

这一步非常关键，
因为 checklist 明确要求:

```text
不直接读取 pdf_eval/outputs 历史实验目录
```

我这里复用的是 `pdf_eval` 的 postprocess 代码，
不是它的历史输出。

#### 4. 后处理语义直接复用 `pdf_eval` 脚本

我没有在主仓库重写新的 `cleaned/chunks/tables/quality` 语义，
而是直接加载:

- [pdf_eval/scripts/mineru_postprocess.py](/Users/cici/oncall agent/pdf_eval/scripts/mineru_postprocess.py)

并用它对当前文档自己的 raw 输出目录做 postprocess。

这等于把“语义对齐”这件事前置解决了，
不是等到 P2-4/P2-5 再发现两边已经悄悄分叉。

#### 5. `DocumentIngestionService` 已能继续处理 deferred MinerU 文档

新增了:

```text
process_deferred_document(doc_id)
```

这让当前流程变成:

```text
上传 -> parse_pending
后续继续处理 -> MinerUParserAdapter -> index_pending
```

也就是说，
`mineru` 分支不再卡死在 `parse_pending`。

### 这轮正式补了哪些回归

新增:

- [tests/test_mineru_parser_adapter.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_mineru_parser_adapter.py>)

覆盖了 3 类情况:

#### 1. 成功路径

fake CLI 输出 + fake postprocess 后，
文档能从:

```text
parse_pending -> parsing -> parsed -> index_pending
```

并带上:

- `raw_output_dir`
- `markdown_path`
- `postprocess_report`

#### 2. 失败路径

如果 MinerU CLI 报错，
文档状态会被写成:

```text
parse_failed
```

同时错误信息保留在 `error_message`。

#### 3. ingestion service 的 deferred 路由

验证 `DocumentIngestionService.process_deferred_document()` 在 `mineru` 文档上确实会把工作转给 adapter，
而不是又掉回别的旁路。

### 这轮还做了一次真实 smoke

为了不只停在 fake 测试，
我用 `pdf_eval/inputs/expanded_corpus/contracts_regulations/beijing_construction_worker_labor_contract_template.pdf`
做了一次真实 smoke。

第一次在当前沙箱里失败，
不是因为 adapter 逻辑错，
而是因为 MinerU CLI 在未显式传 `--api-url` 时会尝试临时起本地服务，
而沙箱禁止它绑定本地随机端口。

错误是:

```text
PermissionError: [Errno 1] Operation not permitted
```

我随后在沙箱外重跑了同一条 smoke，
结果成功:

- 文档从 `parse_pending` 进入 `index_pending`
- raw markdown 路径成功落出
- postprocess 也跑通

所以这里真正的结论是:

```text
adapter 逻辑是通的，
沙箱内的失败是本地端口绑定限制，不是实现缺陷。
```

### 这轮后的真实结论

`P2-3` 可以标成完成。

因为 checklist 关心的三件事都已经满足:

1. 请求参数 / 超时 / 输出定位核心结构已经有正式 adapter
2. 主项目配置与本地 artifact 目录已经接上
3. 没有读取 `pdf_eval/outputs/` 历史结果，而是复用 postprocess 代码处理当前文档自己的 raw 输出

而且 `P2-2` 留下的那条风险:

```text
接入服务存在，但状态流仍然不闭合
```

这次也已经可以明确标记 `已完成`，
因为 `mineru` 分支现在不再停在 `parse_pending`。

### 如果按中国大厂项目深挖来问：这一步看起来像调 CLI，你真正补齐了哪些系统能力?

建议回答:

```text
我不是只写了个 subprocess wrapper，
而是把 MinerU 在主项目里的几个关键边界都落了下来：

- 配置从哪进
- raw 输出落哪
- 怎么定位 markdown/images
- 怎么复用既有 postprocess 语义
- parse 失败怎么回写状态
- 文档怎么从 parse_pending 推到 index_pending

而且我除了 fake 单测，还跑了一次真实合同 PDF smoke。
第一次失败时我也拿到了具体 stderr，确认是沙箱端口绑定限制；
切到沙箱外后，同一条链路成功到了 index_pending。
```

#### 追问 2: 为什么要把 MinerU 的 CLI 调用、postprocess 和状态回写都收进一个独立 adapter?

建议回答:

```text
因为这几件事本来就属于同一个 parser 边界。

独立 adapter 可以把 CLI 调用、raw 输出定位、后处理复用和失败回写
关在一个模块里，失败也更容易定位。
```

#### 追问 3: 这一步最重要的不是“能跑”，那它最重要的工程价值是什么?

建议回答:

```text
最重要的是把 parse 失败的责任边界明确下来。

这样以后 MinerU 参数、输出格式或 postprocess 变化时，
我只需要改 adapter，不需要动 ingestion 和索引层。
```

---

## 16. 阶段 S: P2-4 artifact 六件套落地

- 当前状态: 已完成
- 本次目标:
  - 把六件套从“已经产出来了”推进到“有 manifest 声明、有严格校验、缺件就不允许继续”，同时不提前进入 `P2-5` 的 chunk/index 语义。

### 为什么这一步不能等到 `P2-5` 再做

如果把 artifact manifest 和缺件校验放到 `P2-5` 再做，
会有一个很实际的问题:

```text
indexer 会一边负责“读什么”，
一边负责“判断上游产物是不是完整”。
```

这样一来，
一旦出现缺文件、字段漂移、路径不一致，
你很难分清:

- 是 parser adapter 没产对
- 还是 indexer 读错了

所以我这一步刻意把问题前置:

```text
P2-4 先把“产物声明”和“产物完整性校验”单独收口，
P2-5 再只负责消费 chunks/tables 做索引。
```

### 这轮实际做了什么

#### 1. 新增 `ArtifactManifestService`

新增:

- [app/services/artifact_manifest_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/artifact_manifest_service.py>)

这个 service 现在负责三件事:

- `build_manifest(document_record)`
- `write_manifest(document_record)`
- `validate_manifest(artifact_dir)`

这意味着 manifest 的结构、写法、校验逻辑不再散在 parser adapter 和未来 indexer 里。

#### 2. 把 manifest 结构正式模型化

我还在:

- [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>)

里新增了 `ArtifactManifest`，
把下面这些字段正式定住:

- `schema_version`
- `kb_id`
- `doc_id`
- `source_file`
- `artifact_dir`
- `parser_engine`
- `parser_version`
- `postprocess_version`
- `status`
- `required_files`
- `created_at`

这一步的重点不是“再多加一个模型”，
而是避免 manifest 继续只是临时 `dict` 约定。

#### 3. 现在 `MinerUParserAdapter` 会先写 manifest，再决定能不能进 `index_pending`

更新了:

- [app/services/mineru_parser_adapter.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/mineru_parser_adapter.py>)

当前顺序已经变成:

```text
MinerU raw 输出
-> postprocess
-> 生成 artifact_manifest.json
-> validate_manifest()
-> 只有校验通过才进入 index_pending
```

也就是说，
现在不是“能产一点 Markdown 就算解析成功”，
而是必须把六件套真正凑齐，文档才允许继续进入下游索引阶段。

#### 4. 提供了后续索引阶段的正式校验入口

我还在:

- [app/services/document_ingestion_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/document_ingestion_service.py>)

里加了:

```text
validate_artifacts_for_index(doc_id)
```

这一步的意义是:

- `P2-5` 不需要再自己硬编码“六件套文件名在哪”
- 后续 indexer 只需要先调这条正式入口，再去消费 `chunks.json/tables.json`

### 这轮正式补了哪些回归

新增:

- [tests/test_artifact_manifest_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_artifact_manifest_service.py>)

以及扩展:

- [tests/test_mineru_parser_adapter.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_mineru_parser_adapter.py>)

关键覆盖点有三类:

#### 1. manifest 能正确写出并通过校验

验证:

- manifest 文件存在
- schema 是 `artifact_manifest_v1`
- `required_files` 映射正确

#### 2. 缺任一关键文件时会直接失败

我专门补了 `tables.json` 缺失的测试。

这一步不是在 indexer 里发现错误，
而是在 parser adapter 结束前就直接把文档转成:

```text
parse_failed
```

这正对应 checklist 里的“缺任一关键文件时直接失败”。

#### 3. 真实样本六件套真的落出了

除了单测，
我又跑了一次真实合同 PDF smoke，
并确认文档自己的 `artifact_dir` 下实际存在:

- `artifact_manifest.json`
- `cleaned.md`
- `chunks.json`
- `tables.json`
- `blocks.json`
- `quality_report.json`

### 这轮后的真实结论

`P2-4` 可以标成完成。

因为 checklist 关心的两件事现在都成立了:

1. 六件套路径、文件名、字段语义已经有正式 manifest 约束
2. 手工删除关键文件后，文档会在进入 `index_pending` 前被拦下

而且 `P2-4` 那条风险:

```text
只产出 Markdown，剩下文件靠推测补，后续整条链不稳
```

这次也已经可以明确标成 `已完成`，
因为当前路径已经不是“只要有 Markdown 就继续”，
而是明确要求完整 bundle。

### 如果按中国大厂项目深挖来问：为什么 manifest 现在就值得单独做，而不是等 indexer 写好再说?

建议回答:

```text
因为这一步解决的不是“怎么索引”，
而是“上游解析产物什么时候算完整、什么时候不允许继续”。

如果把 manifest 和缺件校验拖到 indexer 里，
indexer 就会同时承担产物完整性判断和 chunk/tables 读取两件事，
后面出了问题很难分层定位。

我把这个边界前置到 P2-4，
是为了让 parser adapter 对自己的输出完整性负责，
让 P2-5 只管消费正式输入。
```

#### 追问 2: 为什么 manifest 需要单独建模，而不是继续当作一个 dict 约定?

建议回答:

```text
因为 dict 约定很容易在不同模块里慢慢漂移，
最后谁都觉得自己写对了，但字段语义已经不一致了。

把 manifest 单独建模后，
schema、required_files 和状态字段就能被统一校验。
```

#### 追问 3: 这个边界前置之后，P2-5 得到的好处是什么?

建议回答:

```text
P2-5 就能只管消费完整输入，不需要再判断上游产物是不是完整。

这样 parser adapter 负责“产物是否完整”，indexer 负责“怎么索引”，
两层职责就不会打架。
```

### 如果按中国大厂项目深挖来问：手工删一个 `tables.json` 为什么要直接失败，不能先让系统尽量继续跑吗?

建议回答:

```text
因为这里的目标不是“表面上多跑几步”，
而是保证后续索引和引用语义可信。

如果已经声明 `tables.json` 是正式主输入，
但文件没了系统还继续往下跑，
那后面得到的结果就是不完整却没有被明确标记。

这种状态比直接失败更危险，
因为它会制造看起来成功、实际上缺数据的假阳性。

所以我宁愿在 P2-4 就把它卡死，
也不把不完整产物放到索引层再赌运气。
```

#### 追问 2: 为什么要在 parser adapter 结束前就直接失败，而不是让后面的 indexer 再补救?

建议回答:

```text
因为补救会把责任边界冲淡。

如果上游产物已经缺了关键文件，最清楚的做法就是让 parser 直接失败，
这样后面的人一眼就知道问题出在解析产物，而不是索引逻辑。
```

#### 追问 3: 这个 fail-fast 策略对后续排查有什么实际价值?

建议回答:

```text
它能把错误从“系统最后看起来没成功”变成“上游哪一个文件缺了”。

这样日志、测试和人工排查都能直接对齐到具体缺件，
不会把一个输入完整性问题拖成索引层的假故障。
```

---

## 13. 风险回写规则补充

- 当前状态: 已完成
- 本次目标:
  - 把“风险如果已经在后续步骤中被解决，就必须明确标成已完成”写成执行清单规则，并回补到已经解决的风险项上。

### 为什么要补这条规则

如果没有这条规则，
很容易出现一种很别扭的状态:

```text
代码和验证已经把风险解决了，
但 checklist 里还保留着旧风险表述，
后面读文档的人会误以为这些风险仍然悬空。
```

这会直接带来两个问题:

1. 阶段判断失真，看不出哪些风险只是历史提醒、哪些风险还是真的未解决
2. 后续实现时重复围绕已经解决的问题兜圈子

### 这次具体怎么落

我把这条要求加进了:

- [docs/p1_p2_execution_checklist.md](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/docs/p1_p2_execution_checklist.md>)

新规则的意思很直接:

```text
如果某阶段列出的风险在后续步骤中被实际解决，
必须回写到清单中，并明确把该风险标成 `已完成`，
不能只在后续阶段口头说明。
```

### 这次顺手回补了哪些已解决风险

#### 1. P1-2 的接口壳风险

现在已经补成:

```text
已完成: KnowledgeMetadataStore 已被 vector_index_service 实际接入 legacy md/txt 索引链路
```

#### 2. P1-3 的 metadata 断层风险

现在已经补成:

```text
已完成: P1-4 正式回归已经覆盖新旧 metadata 共存
```

#### 3. P2-1 的路由散落风险

现在已经补成:

```text
已完成: parser_engine_router 已成为正式边界，vector_index_service 已开始消费
```

### 这条规则后面会怎么用

从现在开始，
后续阶段如果再解决前面挂着的风险，
处理方式不应该只是:

```text
在当前阶段写一句“这个问题已经好了”
```

而应该是:

```text
同时回写到原风险所在的 checklist 段落，
明确标注 `已完成`
```

这样文档会更像真实执行状态，
而不是一串只会累积、不会收口的历史提醒。

---

## 17. 阶段 T: P2-5 ChunkBuilder / Indexer 落地

- 当前状态: 已完成
- 本次目标:
  - 先补最小 artifact contract adapter / validator，再把 MinerU prepared artifacts 接入 `VectorIndexService` 写入路径；不把 P2-6 幂等清理或 P2-7 citation 偷算进本阶段。

### 为什么 P2-5 不能一上来就写向量入库

`P2-4` 已经证明六件套会落盘、缺件会失败，
但这还不等于 `chunks.json` / `tables.json` 已经天然适合索引层直接消费。

原因是当前主仓库复用了 `pdf_eval/scripts/mineru_postprocess.py`，
而 `pdf_eval` 的 `chunks.json` 仍然偏实验产物形状:

```text
id / text / pages / heading_path / block_ids / block_types / char_count
```

主项目运行时契约要求的是:

```text
doc_id / chunk_id / content / page_start / page_end / content_type / parser_engine / source_ref
```

所以这一小步先做 adapter，
把实验产物稳定翻译成主仓库运行时 chunk 契约，
避免后续 indexer 一边猜字段、一边写向量库。

### 这轮具体改了哪些代码

#### 1. 新增 artifact chunk builder

新增:

- [app/services/artifact_chunk_builder_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/artifact_chunk_builder_service.py>)

它的职责很窄:

- 只读取 manifest 指向的 `chunks.json`
- 只读取 manifest 指向的 `tables.json`
- 读取 `quality_report.json` 做索引准入判断
- 不读取 `cleaned.md` 来猜正文或表格结构
- 输出 index-ready `ChunkRecord`
- 同时输出给后续 vector indexer 使用的 LangChain `Document`

正文 chunk 当前按下面方式规范化:

```text
raw id: c00001
runtime chunk_id: <doc_id>:c00001
content: raw text/content
page_start/page_end: 从 pages 或显式页码字段得到
source_ref: kb_id/doc_id/chunk_id/source_file/page/heading_path/content_type/parser_engine
```

表格 chunk 当前按下面方式规范化:

```text
raw table_id: t00001
runtime chunk_id: <doc_id>:table:t00001
content: tables.json.markdown
structured_payload: rows + caption + quality_flags
```

这样后续 indexer 拿到的不是模糊的 JSON，
而是已经带稳定身份和来源字段的 chunk 对象。

#### 2. 在 DocumentIngestionService 里补 P2-5 入口

更新:

- [app/services/document_ingestion_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/document_ingestion_service.py>)

新增:

```text
prepare_artifacts_for_index(doc_id)
```

这条入口固定了 P2-5 的调用顺序:

```text
读取 DocumentRecord
-> validate_artifacts_for_index(doc_id)
-> artifact_chunk_builder_service.prepare(...)
```

这也明确了异常边界:

- adapter / validator 出错时，状态更新为 `index_failed`
- 异常继续抛出
- 调用方不能把这类失败误当作成功或空结果

这个选择对应用户前面确认的处理方式:

```text
process_deferred_document() 和 P2-5 调用链不吞异常，
但生命周期状态必须明确记录失败。
```

### 这轮补了哪些测试

新增:

- [tests/test_artifact_chunk_builder_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_artifact_chunk_builder_service.py>)

覆盖三类行为:

1. `chunks.json` 正文和 `tables.json` 表格能被规范化成 index-ready `ChunkRecord`
2. 坏 chunk 缺少正文内容时，会标记 `index_failed` 并重新抛异常
3. `quality_report.fatal_errors` 非空时，不允许继续进入索引准备

### 这轮后的中间结论

第一小步完成后，
`P2-5` 已经有了:

```text
artifact contract adapter / validator
```

但当时还不能整体标成完成，
因为还没有做:

- 把 prepared LangChain `Document` 写入向量库
- 把 `ChunkRecord` 持久写回 metadata store
- 验证索引路径里确实能看到 `doc_id/chunk_id/page/source_ref`

### 这轮继续补齐了 P2-5 的索引写入路径

随后继续更新:

- [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)

现在 `VectorIndexService.index_document_record()` 的行为是:

```text
plain_text -> 继续走原来的 md/txt 切分和索引路径
mineru -> consume prepared artifacts -> add_documents -> replace_chunks -> indexed
```

也就是说，
`mineru` 文档不会再被 `VectorIndexService` 拒绝，
也不会回退去读原始 PDF 文本。

实际路径变成:

```text
DocumentRecord(index_pending, parser_engine=mineru)
-> prepare_artifacts_for_index(doc_id)
-> PreparedIndexArtifacts.documents
-> vector_store_manager.add_documents()
-> KnowledgeMetadataStore.replace_chunks(doc_id, chunk_records)
-> DocumentStatus.INDEXED
```

失败时仍然保持明确状态:

```text
vector 写入失败
-> DocumentStatus.INDEX_FAILED
-> error_message 记录异常
-> 异常继续抛出
```

### 这次补充的验证

继续扩展:

- [tests/test_artifact_chunk_builder_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_artifact_chunk_builder_service.py>)

新增覆盖:

1. `mineru` prepared artifacts 能通过 `VectorIndexService.index_document_record()` 写入 fake vector store
2. `KnowledgeMetadataStore` 能持久保存正文 chunk 和表格 chunk 的 `ChunkRecord`
3. fake vector-store 中的 LangChain `Document.metadata` 带 `chunk_id`
4. 持久化的 chunk metadata 带 `source_ref.doc_id`
5. 向量写入失败时文档状态变为 `index_failed`

### P2-5 当前正式结论

`P2-5` 可以按逻辑回归口径标成完成。

完成的是:

- 正文只从 `chunks.json` 建 chunk
- 表格只从 `tables.json` 建 chunk
- 不从 `cleaned.md` 猜结构
- `doc_id/chunk_id/page/content_type/parser_engine/source_ref` 进入 vector document metadata 和 metadata store
- MinerU 文档可以从 `index_pending` 推进到 `indexed`

但要注意这个完成口径不包含:

- live Milvus + DashScope smoke
- P2-6 doc_id 幂等清理
- P2-7 retrieval citation 基线

P2-5 收口当时本机 `.env` 仍然是 placeholder DashScope key，
因此真实向量库 smoke 不能在那一步被诚实声明为完成。

## 18. 阶段 T-补验: live Milvus + DashScope smoke 补验

- 当前状态: 已完成
- 本次目标:
  - 在 `P2-5` 逻辑回归完成之后，补做一次真实外部依赖 smoke，确认当前项目路径里的 DashScope embedding、Milvus 写入、检索和清理都能实际跑通。

### 为什么这一步是“补验”，不是重新定义 P2-5

`P2-5` 收口时，
我把结论刻意限制在:

```text
artifact adapter / validator + prepared artifacts 索引代码路径 + 逻辑回归完成
```

原因不是不想跑真实向量库，
而是当时本机 `.env` 里的 `DASHSCOPE_API_KEY` 仍然是 placeholder，
同时 `localhost:19530` 没有可用 Milvus。

如果在那个时候把 P2-5 写成“live 向量链路也已验证”，
就是把外部环境没有满足的事情误写成完成。
所以当时正确做法是先诚实收住边界:

- P2-5 可以完成代码路径和逻辑回归
- live Milvus + DashScope smoke 等环境就绪后补验

到 2026-05-15，
环境条件变化了:

- `.env` 中的 `DASHSCOPE_API_KEY` 已经不是 placeholder
- Docker Milvus 可以从 [vector-database.yml](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/vector-database.yml>) 启动
- `127.0.0.1:19530` 和 `http://127.0.0.1:9091/healthz` 在沙箱外可访问

所以这一步补的是“真实依赖层可用性”，
不是把 P2-5 的验收口径从代码逻辑扩大成效果验收。

### 这轮实际验了什么

先启动 Milvus:

```bash
/Applications/Docker.app/Contents/Resources/bin/docker compose -f vector-database.yml up -d
```

当时 Docker compose 状态是:

```text
milvus-etcd: healthy
milvus-minio: healthy
milvus-standalone: healthy
milvus-attu: up
```

然后不是手写一套绕过项目代码的 Milvus 插入脚本，
而是走项目自己的 [app/services/vector_store_manager.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_store_manager.py>)。

实际验证路径是:

```text
VectorStoreManager.delete_by_source("__live_smoke_dashscope_milvus__")
-> VectorStoreManager.add_documents([smoke_doc])
-> DashScope text-embedding-v4 返回 1024 维向量
-> Milvus biz collection 写入 1 条记录
-> VectorStoreManager.similarity_search(...)
-> VectorStoreManager.delete_by_source("__live_smoke_dashscope_milvus__")
```

结果是:

```text
live_smoke_ok=True
inserted_count=1
retrieved_count=1
deleted_before=0
deleted_after=1
collection=biz
```

### 这一步解决的真实风险

在 P2-5 之前，
我们只能说 fake vector-store 回归能证明:

- adapter 产出的 LangChain `Document` 形状对
- `ChunkRecord` 能落 metadata store
- 索引状态能从 `index_pending` 到 `indexed`

但 fake vector-store 不能证明:

- DashScope key 真的可用
- `text-embedding-v4` 输出维度和 Milvus collection schema 匹配
- 当前 `MilvusClientManager` 能创建并加载 `biz` collection
- `VectorStoreManager.add_documents()` 真的会触发 embedding 并写入 Milvus
- `similarity_search()` 能从真实 collection 里检索回来

这次 smoke 把这些外部依赖风险补上了。

### 这一步仍然不能扩大说明什么

仅就 2026-05-15 这次通用 vector smoke 而言，
不能扩大成:

- P2-6 doc_id 幂等清理已经完成
- P2-7 citation 基线已经完成
- 真实 MinerU 文档全链路已经做过大样本效果验收
- 检索质量已经达标

它证明的是:

```text
真实 DashScope + 真实 Milvus + 当前 VectorStoreManager 的最小写入/检索/清理链路可用。
```

### 如果按中国大厂项目深挖来问：你怎么区分逻辑回归和真实环境 smoke?

建议回答:

```text
我把它拆成两层。

第一层是逻辑回归，
用 fake vector-store 验证 artifact adapter、ChunkRecord、metadata 和状态流转。
这层不依赖外部服务，适合快速防回归。

第二层是真实环境 smoke，
在 DashScope key 和 Docker Milvus 都就绪后，
走项目自己的 VectorStoreManager 做一次真实 embedding、写入、检索、清理。

这样不会因为外部环境没起就误判代码坏了，
也不会因为单测过了就夸大成真实向量链路已验证。
```

#### 追问 2: 为什么这次要同时保留 fake vector-store 单测和真实 smoke?

建议回答:

```text
因为两层覆盖的是不同风险。

fake vector-store 负责快速验证逻辑和契约，
真实 smoke 负责证明外部依赖、embedding 和 Milvus 链路真的能跑通。
```

#### 追问 3: 真实 smoke 这一步到底证明了什么、没证明什么?

建议回答:

```text
它证明的是最小写入/检索/清理链路可用，
不是证明大样本效果已经达标。

所以我只把它当成环境和主链路可用性的证据，
不把它扩大成检索质量已经最终稳定的结论。
```

---

## 19. 阶段 U: P2-6 doc_id 幂等清理收口

- 当前状态: 已完成
- 本次目标:
  - 把“同一 `doc_id` 重索引前先清旧 chunk 和旧向量行”做成 `plain_text` 与 `mineru` 两条索引路径共享的固定前置步骤。

### 为什么 P2-6 必须接在 P2-5 后面

`P2-5` 已经让 MinerU prepared artifacts 能进入主项目索引路径:

```text
chunks.json / tables.json
-> ArtifactChunkBuilderService
-> ChunkRecord + LangChain Document
-> VectorIndexService.index_document_record()
-> vector_store_manager.add_documents()
-> KnowledgeMetadataStore.replace_chunks()
```

这时如果没有幂等清理，
同一份文档重解析或重索引时，
系统会出现两类脏数据:

1. `KnowledgeMetadataStore` 里残留旧 `ChunkRecord`
2. Milvus `biz` collection 里残留旧向量行

更麻烦的是，
历史 `md/txt` 路径里已经存在只带 `_source` 的旧向量行，
而 P2 新路径要逐步迁到更稳定的 `doc_id` 身份。

所以 P2-6 不是继续扩 parser，
也不是提前做 citation，
而是先把索引层的“重复写入可预期”补上。

### 这轮实际改了什么

#### 1. 在 VectorStoreManager 里收出统一删除 helper

更新:

- [app/services/vector_store_manager.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_store_manager.py>)

这轮先把原来的 `_source` 删除逻辑抽成窄 helper:

```text
_delete_by_metadata_field(field_name, value, label)
```

然后用同一套 helper 实现:

```text
delete_by_doc_id(doc_id)
delete_by_source(file_path)
```

代码层面的关键点是:

```text
expr = f'metadata["{field_name}"] == {json.dumps(value)}'
```

这里用 `json.dumps(value)` 不是装饰性写法，
而是为了让 Milvus metadata filter 里的值做安全转义。
如果 `doc_id` 或路径里出现引号，
就不会拼出非法表达式。

这一步没有把 vector store 重构成全新 DAO，
因为 P2-6 的目标很窄:

```text
补 doc_id 删除能力，并复用旧 _source 删除能力。
```

#### 2. 在 VectorIndexService 里固定清理顺序

更新:

- [app/services/vector_index_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_index_service.py>)

新增:

```text
_cleanup_existing_document_data(document_record)
```

它把 P2-6 的顺序固定成:

```text
knowledge_metadata_store.delete_chunks_by_doc_id(doc_id)
vector_store_manager.delete_by_doc_id(doc_id)
vector_store_manager.delete_by_source(normalized_source)
vector_store_manager.add_documents(documents)
```

这个顺序有明确含义:

- 先清本地 metadata-store chunk，避免旧 chunk 和新 chunk 混在一起
- 再按 `doc_id` 清正式新链路产生的向量行
- 再按 `_source` 清历史 legacy 脏行
- 最后才写入新 documents

这条前置清理同时进入了:

- `plain_text` 旧路径
- `mineru` prepared-artifact 路径

也就是说，
P2-5 新接入的 MinerU 索引不会绕过幂等逻辑。

#### 3. 测试重点放在“重复写入”和“legacy 兼容”

新增:

- [tests/test_p2_6_idempotent_cleanup.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_p2_6_idempotent_cleanup.py>)

这组测试不是只证明“索引能成功”，
而是专门覆盖 P2-6 的风险点:

1. MinerU 同一个 `doc_id` 重索引时，旧 chunk 和旧向量行会被清掉。
2. plain-text 同一个 `doc_id` 重索引时，也走同一套清理顺序。
3. 清理调用顺序必须是:

```text
delete_chunks_by_doc_id -> delete_by_doc_id -> delete_by_source -> add_documents
```

4. 只有 `_source`、没有 `doc_id` 的 legacy stale row，仍能靠 `_source` 清掉。

测试里专门用 `TrackingVectorStoreManager` 记录调用顺序，
这是为了防止未来有人把清理放到 `add_documents()` 后面，
导致表面测试还能过、真实重索引却已经污染。

### 这轮补了一次真实 Milvus + DashScope smoke

为了确认不是 fake vector-store 自己演得很好，
这一轮又跑了一次真实环境 smoke。

关键步骤是:

1. 用 Docker 启动 [vector-database.yml](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/vector-database.yml>)。
2. 沙箱内 PyMilvus 连接超时后，改用沙箱外 `MILVUS_HOST=127.0.0.1 MILVUS_TIMEOUT=30000` 执行。
3. 索引一个临时 markdown 文件。
4. 手工插入一条只有 `_source` 的 legacy stale row。
5. 再次索引同一文件，也就是同一 `doc_id`。
6. 查询 Milvus metadata，确认重索引后没有重复脏数据。
7. 最后清理 smoke 数据，确认 collection 回到干净状态。

结果是:

```json
{
  "p2_6_live_smoke_ok": true,
  "before_reindex": {"doc_id_rows": 1, "source_rows": 2, "chunk_records": 1},
  "after_reindex": {"doc_id_rows": 1, "source_rows": 1, "chunk_records": 1},
  "cleanup": {"doc_id_rows": 0, "source_rows": 0},
  "collection": "biz"
}
```

这个结果的含义是:

- 第一次索引后有 1 条当前文档向量行
- 手工插入 legacy stale row 后，按 `_source` 能看到 2 条
- 第二次同 `doc_id` 索引后，只剩 1 条有效当前行
- 最后清理后，smoke 数据不残留

### 这轮实际怎么验的

本轮验证包括:

```bash
.venv/bin/python -m unittest discover tests -v
.venv/bin/python -m compileall app tests
```

并补了上面那次真实 Milvus + DashScope smoke。

当时全量 unittest 是 25 项通过，
其中包含 [tests/test_p2_6_idempotent_cleanup.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_p2_6_idempotent_cleanup.py>)。
`compileall` 也通过。

### P2-6 当前正式结论

`P2-6 doc_id 幂等清理` 可以标记为完成。

完成口径是:

- 同一 `doc_id` 重索引前先清 metadata-store chunk。
- 再按 `doc_id` 清 Milvus 向量行。
- 再按 `_source` 兼容清 legacy 向量行。
- 最后写入新 vector documents 和新 chunk records。
- 单元测试和 live Milvus + DashScope smoke 都通过。

这一步不能扩大成:

- 大样本 MinerU 全链路效果达标。
- 线上级批量并发幂等已经压测完成。
- retrieval citation 已经完成。
- metadata store 的全量刷盘性能问题已经优化。

### 如果按中国大厂项目深挖来问：为什么要先按 doc_id 清，再保留 _source 清理?

建议回答:

```text
因为主身份已经从文件路径迁到 doc_id 了。
P2-5 之后，ChunkRecord、vector metadata、后续 retrieval/citation 都要围绕 doc_id 串起来。

但系统之前有 legacy md/txt 路径，
历史向量行可能只有 _source，没有稳定 doc_id。

所以我先用 doc_id 清正式新数据，
再用 _source 兜底清历史脏行。
这样新链路往稳定身份迁移，旧数据兼容也不会断。
```

### 如果继续追问

#### 追问 1: 为什么不顺手把 MetadataStore 全量刷盘也优化掉?

建议回答:

```text
因为那不是 P2-6 的直接阻塞。

P2-6 要解决的是重复索引导致旧 chunk 和旧 vector row 残留的问题。
当前文档量还小，KnowledgeMetadataStore 每次全量保存是可接受的开发阶段实现。

如果这一步顺手引入批量写、异步 flush 或数据库迁移，
改动面会明显扩大，还会干扰当前最关键的幂等行为验证。

所以我把全量刷盘记录成后续规模化优化点，
但不把它混进 P2-6。
```

#### 追问 2: 如果以后 legacy 脏数据变多，这种 `_source` 兜底会不会拖慢重索引?

建议回答:

```text
现在这一步只处理少量历史脏行，目标是先把清理顺序和身份边界定住。

如果后面 legacy 数据量上来，清理可以再拆成更明确的批处理或后台任务，
但那是规模化优化，不应该挤占 P2-6 现在的幂等验证范围。
```

#### 追问 3: 这轮怎么证明自己没有误删新数据，只是在清历史脏数据?

建议回答:

```text
我用的是重索引前后对比的 smoke。

第一次索引后、手工插入 legacy stale row、第二次同 doc_id 索引后，
before/after 里的 doc_id_rows 都保持为 1，
最后 cleanup 之后 collection 回到 0 残留。

这说明删除目标是按身份精确收敛的，不是把新数据一起清掉。
```

---

## 20. 阶段 V: P2-7 Retrieval citation 基线

- 当前状态: 已完成
- 本次目标:
  - 在已经稳定的 `doc_id/chunk_id/page/source_ref` 基础上，把检索结果从“上下文字符串”提升为“结构化证据对象”。

### 为什么 P2-7 要等 P2-6 之后再做

引用不是只在回答文本后面拼一句“来源见某文件”。

真正能站住的 citation 至少要有:

- `kb_id`
- `doc_id`
- `chunk_id`
- `source_file`
- `page_start/page_end`
- `heading_path`
- `content_type`
- `parser_engine`

这些字段是在 P2-5/P2-6 才真正稳定进入索引与 metadata 的。

如果在 P2-6 之前先做 citation，
很容易变成:

```text
检索层把不稳定 metadata 包装得更漂亮，
但实际仍然无法证明命中内容来自哪份文档、哪一页、哪个 chunk。
```

所以 P2-7 的真实目标不是“让回答看起来有引用”，
而是让检索命中第一次成为可消费、可追源的证据对象。

### 这轮实际改了什么

#### 1. 在领域模型里补 retrieval DTO

更新:

- [app/models/knowledge.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/models/knowledge.py>)

新增:

- `RetrievalQuery`
- `RetrievalResult`
- `RetrievalResponse`

这一步不是为了多加几层模型，
而是把检索层的输入输出正式化。

`RetrievalResult` 里最关键的是这些字段:

```text
kb_id
doc_id
chunk_id
content
score
source_ref
citation_text
metadata
```

这让下游不再只拿到一段 `context_text`，
而是能拿到每条命中的身份、来源、页码、章节和 citation 文本。

#### 2. 新增 RetrievalService 作为结构化证据边界

新增:

- [app/services/retrieval_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/retrieval_service.py>)

这里没有重写底层向量搜索，
而是继续复用已有:

- [app/services/vector_search_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/vector_search_service.py>)

`RetrievalService` 做的是 raw hit 到 evidence 的适配:

```text
vector_search_service.search_similar_documents()
-> _normalize_metadata()
-> _build_source_ref()
-> _build_citation_text()
-> _format_context()
-> RetrievalResponse
```

这里有一个重要选择:

```text
缺少稳定引用字段的命中会被跳过。
```

原因是 citation 的底线是“可追源”，
如果命中缺少 `kb_id/doc_id/chunk_id/source_file`，
就不能把它伪造成可靠证据。

#### 3. citation_text 的格式被固定下来

当前 citation 示例是:

```text
[来源: manual.pdf, 页码: 2-3, 章节: 第一章 > 概述, chunk: doc_pdf:c00001]
```

这个格式不是最终 UI 设计，
但它在 P2-7 阶段解决了一个更基础的问题:

```text
每条 retrieval result 都能稳定表达来源文件、页码范围、章节路径和 chunk 身份。
```

#### 4. retrieve_knowledge 保持工具名不变，但返回 content_and_artifact

更新:

- [app/tools/knowledge_tool.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/tools/knowledge_tool.py>)

这一步我刻意保留了 public tool name:

```text
retrieve_knowledge
```

原因是 planner / executor / replanner 这些上层调用方已经认识这个工具名。
如果为了 citation 改工具名，
会制造不必要的调用面破坏。

真正改变的是返回格式:

```text
@tool(response_format="content_and_artifact")
```

现在返回的是:

- `content`: 给模型继续生成回答用的上下文文本
- `artifact`: 给系统或后续调用方消费的结构化检索结果

我还专门在 artifact 中把调用方输入的 `query` 写回去，
并保证每条 `source_ref.kb_id/doc_id/chunk_id` 与 result 本身一致，
避免内部 service response 和 tool artifact 出现身份漂移。

### 为什么没有在这一步重写 vector search / hybrid search / rerank

这一步容易被扩做成“顺手把检索质量也优化了”。

我没有这么做，
原因是 P2-7 的核心边界是:

```text
让已有检索命中变成结构化证据。
```

而不是:

```text
提升召回算法、引入 reranker、重做 hybrid search。
```

底层搜索已经能返回 raw hit，
这轮真正缺的是:

- raw hit 的 metadata 能不能被规范解释
- 命中能不能恢复 `SourceRef`
- citation 文本能不能稳定生成
- tool artifact 能不能被调用方直接消费

所以这轮保留 raw vector search，
只在它上面加结构化 evidence boundary。

### 这轮补了哪些测试

新增:

- [tests/test_retrieval_service.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_retrieval_service.py>)

覆盖三类行为:

1. `RetrievalService` 能从 raw hit 构造结构化 citation artifact。
2. 没有命中时返回空 results 和统一空消息，不伪造 citation。
3. `retrieve_knowledge` tool 返回 `content_and_artifact`，并保留 `query/source_ref/citation_text`。

测试里专门断言了这个 citation:

```text
[来源: manual.pdf, 页码: 2-3, 章节: 第一章 > 概述, chunk: doc_pdf:c00001]
```

这比只看“返回里有来源两个字”更有约束力。

### 这轮实际怎么验的

本轮实际执行:

```bash
.venv/bin/python -m unittest tests.test_retrieval_service -v
.venv/bin/python -m unittest discover tests -v
.venv/bin/python -m compileall app tests
```

结果:

- retrieval 专项测试通过
- 当时全量 unittest 通过
- `compileall app tests` 通过

### P2-7 当前正式结论

`P2-7 Retrieval citation 基线` 可以标记为完成。

完成口径是:

- 检索结果已经是结构化证据对象。
- `doc_id/chunk_id/page/source_ref/citation_text` 可以端到端返回。
- `retrieve_knowledge` 工具名保持不变，调用面没有断。
- 工具返回从单纯字符串提升为 `content_and_artifact`。

这一步不能扩大说明为:

- answer prompt 已经系统性改造完成。
- hybrid search / rerank 已经接入。
- 底层向量召回质量已经提升。
- citation UI 或前端展示已经完成。

### 如果按中国大厂项目深挖来问：为什么不直接重写底层检索，而是在上面加 RetrievalService?

建议回答:

```text
因为 P2-7 的问题不是召回算法本身，
而是命中结果有没有稳定身份、稳定来源和稳定引用格式。

底层 vector_search_service 已经能返回 raw hit，
我需要的是把这些 hit 变成证据对象。

所以我保留 raw hit layer，
在它上面补一个结构化 evidence boundary。

这样以后要换 hybrid search 或 rerank，
只要仍然产出相同的 evidence shape，
下游 tool 和 gate 都不需要跟着乱改。
```

### 如果继续追问

#### 追问 1: 为什么缺字段的命中要跳过，而不是尽量返回?

建议回答:

```text
因为 citation 的底线是可追源。

如果一个命中没有 kb_id/doc_id/chunk_id/source_file，
我可以把内容塞给模型，
但不能诚实地把它说成可引用证据。

P2-7 的目标是建立 citation baseline，
所以宁愿少返回不可靠证据，
也不伪造来源完整性。
```

#### 追问 2: 为什么这里一定要返回结构化证据对象，而不是继续返回纯文本?

建议回答:

```text
因为纯文本只能给模型看，不能给系统做稳定引用。

P2-7 要的是 doc_id/chunk_id/source_ref/citation_text 这种可追源形状，
这样工具调用方、门禁和后续 hybrid/rerank 都能沿同一份证据边界工作。
```

#### 追问 3: 如果后面切到 hybrid 或 rerank，这一层怎么保证不用重写?

建议回答:

```text
我把可变的部分放在召回和排序，把不变的部分放在证据形状。

底层检索可以换实现，但只要还是输出同一套 evidence 字段，
下游就不需要跟着改协议。
```

---

## 21. 阶段 W: P2-8 P2 端到端门禁

- 当前状态: 已完成
- 本次目标:
  - 把 P2 的完成标准压成一组可重复执行的正式 gate，确认 P2 不是“某个功能点跑通”，而是主链路关键边界都没有退化。

### 为什么 P2-8 不是普通 smoke

到 P2-7 为止，
各个功能点已经分别完成:

- P2-1 有 parser router
- P2-2 有 ingestion service
- P2-3 有 MinerU parser adapter
- P2-4 有 artifact manifest
- P2-5 有 ChunkBuilder / Indexer
- P2-6 有 doc_id 幂等清理
- P2-7 有 retrieval citation

这时最容易出的问题不是“某个单点完全没做”，
而是链路边界互相挤压后出现退化:

- 新 PDF/MinerU 路径把旧 `md/txt` 兼容链路弄坏
- artifact manifest 在单测里能写，但 index 前不一定真校验
- MinerU prepared artifacts 能索引，但 `source_ref/page/chunk_id` 在中间丢了
- 上传 API 的旧响应 envelope 被新字段改坏
- retrieval 能返回文本，但 citation artifact 不稳定

所以 P2-8 的职责是:

```text
把 P2 完成标准变成可重复执行的门禁，而不是靠人读 checklist 后主观判断。
```

### 这轮把哪些检查固化成 gate

新增:

- [tests/test_p2_8_gate.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/tests/test_p2_8_gate.py>)

它不是一个大而模糊的 smoke，
而是拆成 5 个独立检查。

#### 1. md/txt 回归门禁

测试函数:

```text
test_md_txt_regression_gate_preserves_stable_ids_and_source_ref
```

它走真实:

```text
VectorIndexService.index_single_file()
```

验证 legacy markdown 样本索引后仍然有:

- `DocumentRecord.status=indexed`
- `parser_engine=plain_text`
- 稳定 `doc_id`
- `chunk_id` 以前缀 `doc_id:c...` 生成
- `source_ref.doc_id` 与 chunk 自身一致
- 旧 `_source` 兼容字段仍在

这对应 P2 的“不退化”底线。

#### 2. artifact 完整性门禁

测试函数:

```text
test_artifact_completeness_gate_accepts_full_mineru_bundle
```

它直接走:

```text
DocumentIngestionService.validate_artifacts_for_index()
DocumentIngestionService.prepare_artifacts_for_index()
```

验证 manifest 与六件套文件一致，
并确认 prepared artifacts 能产出 2 条 chunk records:

- 1 条正文 chunk
- 1 条表格 chunk

这对应 P2-4/P2-5 的 artifact contract。

#### 3. MinerU 参考门禁

测试函数:

```text
test_mineru_reference_gate_preserves_source_ref_through_indexing
```

它走真实:

```text
VectorIndexService.index_document_record(record)
```

并用 fake vector-store 拦住外部依赖，
专门验证 prepared artifacts 进入索引后仍保留:

- `doc_id`
- `chunk_id`
- `source_ref`
- `parser_engine=mineru`
- 页码与 metadata 对齐

这条门禁不是看“写入成功”，
而是看“写入后还能不能追源”。

#### 4. 非降级门禁

测试函数:

```text
test_non_degradation_gate_keeps_upload_api_envelope
```

它通过 FastAPI `TestClient` 调 `/api/upload`，
确认新 ingestion 接入后，
旧响应主结构仍然是:

```text
code / message / data
```

同时 data 中包含:

- `filename`
- `doc_id`
- `parser_engine`
- `status`
- `artifact_dir`
- `file_path`

这避免 P2 为了内部结构升级，
把外部调用面悄悄改坏。

#### 5. citation 门禁

测试函数:

```text
test_citation_gate_returns_structured_evidence_artifact
```

它验证 [app/tools/knowledge_tool.py](</Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/tools/knowledge_tool.py>) 的 `retrieve_knowledge` 返回:

- 给模型看的 `content`
- 给系统消费的 `artifact`
- `artifact.query.query`
- `artifact.results[0].citation_text`
- `artifact.results[0].source_ref.doc_id/kb_id/chunk_id`

这对应 P2-7 的 citation baseline。

### 为什么用 unittest + fake vector-store 做 gate

这一步没有把 gate 设计成“必须每次都起真实 Milvus 和 DashScope”。

原因是 P2-8 的核心目标是防回归，
它需要在普通本地开发环境里稳定执行。

所以这里的设计是:

- gate 测代码路径和契约边界
- live Milvus + DashScope smoke 作为外部依赖证明另行记录
- fake vector-store 用来稳定观察 metadata、调用顺序和 chunk identity

这样门禁不会被网络、密钥、Docker 状态频繁干扰，
但仍然约束 P2 最重要的结构边界。

### 这轮实际怎么验的

本轮实际执行:

```bash
.venv/bin/python -m unittest tests.test_p2_8_gate -v
.venv/bin/python -m unittest discover tests -v
.venv/bin/python -m unittest tests.test_p2_8_gate tests.test_retrieval_service -v
.venv/bin/python -m compileall app tests
```

结果:

```text
33 tests passed
compileall passed
```

### P2-8 当前正式结论

`P2-8 P2 端到端门禁` 可以标记为完成。

完成口径是:

- P2-1 至 P2-7 已完成。
- P2 的 5 个核心门禁已被测试代码固化。
- `md/txt` 兼容、artifact 完整性、MinerU 引用链、上传非降级、citation 输出都可重复验证。
- P2-8 gate、retrieval 专项测试、全量 unittest、compileall 都通过。

这一步不能扩大说明为:

- 大样本真实文档效果已经达标。
- 线上级并发、重试、恢复、观测体系已经全部完成。
- 下一阶段已经自动定义。

P2 到这里是一个清楚的工程闭环:

```text
可接入 -> 可解析 -> 可声明 artifact -> 可索引 -> 可幂等 -> 可引用 -> 可门禁
```

### 如果按中国大厂项目深挖来问

#### 追问 1: 为什么还要额外做 gate，而不是把 P2-7 的测试结果直接当完成标准?

建议回答:

```text
因为 P2-7 只能证明 retrieval 证据对象能返回，
但 P2 的完成标准不只这一件事。

它还包括旧 md/txt 链路有没有退化，
artifact 完整性有没有被真正校验，
MinerU prepared artifacts 进入索引后 source_ref 有没有丢，
上传 API 的旧响应 envelope 有没有被破坏，
citation artifact 能不能被工具调用方稳定消费。

所以我把 P2-8 做成一组 gate，
不是一个大 smoke。
每个 gate 失败时都能定位到具体边界，
这比“我跑了一下看起来没问题”更像工程项目里的完成标准。
```

#### 追问 2: 为什么 P2-8 用 fake vector-store 门禁，而不是每次都起真实 Milvus 和 DashScope?

建议回答:

```text
因为 gate 的目标是稳定做回归，不是重复证明外部依赖健康。

真实 Milvus + DashScope smoke 我已经单独做过了，
但正式 gate 需要在普通本地环境也能跑，
所以这里用 fake vector-store 先把调用顺序、metadata 和 chunk identity 约住。
```

#### 追问 3: 为什么 P2-8 主要看契约边界，而不是直接看召回效果?

建议回答:

```text
因为 P2 的职责是把链路边界固定下来，不是调召回质量。

召回质量、hybrid、rerank 这些是 P3 的内容；
P2-8 只负责证明前面的解析、入库、幂等、引用和工具返回都没有退化。
```

---

## 2026-05-17 P3 计划清单补充: Hybrid Recall / Rerank / Offline Eval

### 为什么现在补 P3 计划

P2-8 已经把 P2 的主链路门禁固定下来，
当前项目已经具备继续讨论检索质量层的前提。

用户明确要求按 DataWhale all-in-rag 教程补齐:

- BM25 + 向量的混合召回
- 一个明确的 rerank 层
- 一套离线评估指标和脚本，包括 `Recall@k / MRR / Hit / citation correctness / latency`

所以本轮不是直接改检索代码，
而是先把 P3 的执行清单写成与 P1/P2 相同粒度的正式计划。

### 本轮改了哪些文件

本轮修改:

- `docs/p1_p2_execution_checklist.md`
- `PROJECT_STATE.md`

### P3 计划的核心顺序

P3 被固定为下面的执行顺序:

```text
P3-1 离线评测集与 dense baseline 固化
P3-2 BM25 + 向量混合召回
P3-3 明确 rerank 层
P3-4 离线评估指标和脚本
P3-5 P3 回归门禁
P3-6 文档、状态与默认策略收口
```

这个顺序刻意把评测集和 dense baseline 放在 hybrid/rerank 前面。

原因是如果没有 dense-only baseline，
后续即使 hybrid 或 rerank 的结果看起来更好，
也无法证明提升来自哪一层，
更无法定位失败样本是 sparse recall、fusion、rerank 还是 citation assembly 的问题。

### 和 DataWhale all-in-rag 的对应关系

DataWhale all-in-rag 的混合检索章节强调稀疏检索与密集检索并行，
再通过融合策略合并候选结果。

本项目的 P3 计划采用同样方法顺序，
但不照搬 demo 项目结构。

落到当前仓库时，对应为:

```text
DenseSearchService / VectorSearchService
        +
SparseSearchService / BM25 retriever
        ->
RRF fusion
        ->
RerankService
        ->
RetrievalResult / RetrievalResponse
```

其中最重要的边界是:

- BM25 不直接生成最终回答。
- RRF 只合并候选和分数。
- rerank 只改变排序和 rerank score。
- citation 身份仍由 P2-7 的 `RetrievalResult` / `SourceRef` 承接。

### 为什么不直接把 hybrid/rerank 塞进 RetrievalService

`RetrievalService` 在 P2-7 的职责是把 raw hit 变成结构化证据。

P3 如果直接把 BM25、RRF、rerank 全塞进去，
会让一个 service 同时负责:

- dense search
- sparse search
- fusion
- rerank
- citation assembly
- context formatting

这样后续评测和故障定位都会变差。

所以 P3 计划要求显式分层:

```text
recall -> fusion -> rerank -> evidence assembly
```

这样每一层都有明确输入输出，
也符合用户强调的“每一层都有边界，每一个模块都有职责，每次调用都是可预期的”。

### P3 不能扩大说明为什么

P3 计划只证明项目准备进入检索质量增强阶段，
不能提前声称:

- hybrid search 已经实现。
- rerank 已经实现。
- 离线评估已经跑出有效提升。
- 大样本真实业务效果已经达标。
- 多模态图像检索、GraphRAG 或完整 WeKnora 服务已经接入。

这些都必须等对应 P3 子任务完成并通过门禁后再更新。

### 如果按中国大厂项目深挖来问：为什么 P3 第一件事不是写 BM25，而是先做评测集?

建议回答:

```text
因为 BM25、向量、RRF、rerank 都是检索质量优化手段，
但优化必须有对照组。

当前系统已经有 dense-only 的 citation-aware retrieval baseline。
如果不先固定 golden queries 和 dense baseline，
后面加 hybrid/rerank 时就只能凭主观感觉判断好坏。

我把 P3-1 放成离线评测集和 baseline，
是为了让每一次检索层改动都能回答三个问题:

1. 召回有没有提升。
2. 排序有没有提升。
3. 返回的 citation 是否仍然正确。

这比直接堆功能更符合可维护系统的做法。
```

#### 追问 2: 为什么 dense baseline 必须先固化，而不是边做边调?

建议回答:

```text
因为边做边调会让对照组一直变动，最后很难判断提升来自哪一层。

先把 dense baseline 固化下来，后面 hybrid / rerank 的每一次变化
才有稳定参照，也更容易把效果和边界讲清楚。
```

#### 追问 3: 如果没有先固定 baseline，后面怎么判断 hybrid/rerank 的结果到底是进步还是噪声?

建议回答:

```text
那就很容易把数据漂移、样本波动和真正的算法收益混在一起。

所以我先把 query set、gold evidence 和 dense baseline 锁住，
后面的比较才有可解释性。
```

---

## 2026-05-17 P3-0 执行前检查完成

### 这一步确认了什么

P3-0 的目标不是写 BM25 或 rerank 代码，
而是先把 P3 的技术边界固定下来。

本轮确认:

- `P2-8` 已经完成，P3 可以建立在 P2 的 evidence contract 之上。
- DataWhale all-in-rag 作为 P3 的方法参考，提供混合检索与评估指标的执行顺序。
- 本项目不照搬 DataWhale demo 项目结构，而是保留当前 Python 应用和已有 service 边界。
- P3 不重写 parser、artifact contract、ChunkBuilder、doc_id 幂等清理。
- P3 新增的 recall/fusion/rerank 层最终仍必须产出 P2-7 已固定的 `RetrievalResult` / `RetrievalResponse`。

### P3-0 落下来的分层边界

P3 的正式边界是:

```text
recall -> fusion -> rerank -> evidence assembly
```

对应到当前项目:

```text
dense vector search
        +
BM25 sparse search
        ->
RRF fusion
        ->
RerankService
        ->
RetrievalService evidence assembly
        ->
retrieve_knowledge content_and_artifact
```

这里每一层只做自己的事:

- recall 负责召回候选。
- fusion 负责合并多路候选。
- rerank 负责重排候选。
- evidence assembly 负责恢复 `doc_id/chunk_id/source_ref/citation_text`。

### 本轮改了哪些文件

本轮修改:

- `docs/p1_p2_execution_checklist.md`
- `PROJECT_STATE.md`
- `docs/rag_fusion_development_record.md`

### P3-0 当前正式结论

`P3-0 执行前检查` 可以标记为完成。

完成口径是:

- P3 的方法参考已经确认。
- P3 的实现边界已经确认。
- P3 不重写 P2 主链路的约束已经写入清单。
- P3-1 的前置条件已经满足，可以开始离线评测集与 dense baseline 固化。

这一步不能扩大说明为:

- BM25 已经实现。
- hybrid search 已经接入。
- rerank 已经接入。
- 离线评估脚本已经可运行。
- 检索效果已经比 dense-only 更好。

### 如果按中国大厂项目深挖来问：为什么 P3-0 要强调“不照搬 DataWhale demo 结构”?

建议回答:

```text
因为 DataWhale all-in-rag 给的是通用 RAG 方法路径，
而当前项目已经有自己的 P2 工程契约:

parser 由 ParserEngineRouter 控制，
artifact 由六件套 manifest 约束，
chunk 由 ChunkBuilder 从 chunks.json/tables.json 生成，
retrieval 已经有 RetrievalResult/SourceRef/citation_text。

如果直接照搬 demo 结构，
短期可能更快写出 hybrid search，
但会绕开已有文档状态、chunk 身份和 citation 契约。

所以 P3-0 把 DataWhale 定位成方法参考，
把本仓库的 RetrievalResult / RetrievalResponse 定位成落地边界。
这样既吸收成熟教程的检索方法，
又不破坏当前项目已经建好的架构层次。
```

#### 追问 2: 既然参考教程，为什么不直接复用它的目录和模块划分?

建议回答:

```text
因为当前项目已经有自己的 P2 工程契约，
包括 parser、artifact、chunk 身份和 citation 输出边界。

如果直接照搬教程结构，短期看似更快，
但会把现有边界打散，后面维护和定位问题都会更难。
```

#### 追问 3: 这一轮最重要的工程判断是什么?

建议回答:

```text
教程只作为方法参考，不作为架构权威。

我先把项目已有的 retrieval / citation 边界认清，
再把 BM25、RRF、rerank 这些方法按现有边界接进去，
这样才不会为了追教程而重写主链路。
```

---

## 2026-05-17 P3-1 离线评测集与 dense baseline 固化完成

### 为什么这一步先做评测集

P3 后面要补 BM25、RRF fusion 和 rerank。

这些都是检索质量优化，
必须先有一个可复跑的 dense-only baseline，
否则后续每一次调参都只能靠感觉判断。

所以 P3-1 的目标是:

```text
固定 query -> 固定 gold evidence -> 跑当前 dense-only -> 写出对比报告
```

### 本轮新增了什么

新增:

- `evals/rag_retrieval/run_dense_baseline.py`
- `evals/rag_retrieval/golden_queries.jsonl`
- `evals/rag_retrieval/reports/dense_only_baseline_20260517_172313.json`
- `evals/rag_retrieval/reports/dense_only_baseline_20260517_172313.md`

`golden_queries.jsonl` 当前包含 4 条样本:

- `cpu_alarm`: markdown 文档 `cpu_high_usage.md`
- `memory_alarm`: markdown 文档 `memory_high_usage.md`
- `mineru_text`: MinerU 正文 chunk fixture
- `mineru_table`: MinerU table chunk fixture

每条样本都包含:

- `query`
- `gold_doc_ids`
- `gold_chunk_ids`
- `gold_source_refs`
- `expected_keywords`

这样后续不仅能测“搜到了哪个文档”，
也能测“命中的 chunk 和 citation 身份是否正确”。

### baseline runner 怎么做隔离

`run_dense_baseline.py` 没有直接往 `biz` collection 混入评测数据。

它会创建一个临时隔离 collection:

```text
p3_dense_baseline_<timestamp>
```

然后索引:

- 两个现有 `aiops-docs/*.md` 文档
- 一个合成的 MinerU fixture，含正文 chunk 和 table chunk

报告写完后，
脚本会删除这个临时 collection。

这样 baseline 能真实经过:

```text
DashScope text-embedding-v4 -> Milvus -> vector_search_service -> retrieval_service
```

同时不会污染主项目的 `biz` collection。

### 本轮实际怎么验的

第一次直接在普通 sandbox 内跑:

```bash
.venv/bin/python evals/rag_retrieval/run_dense_baseline.py
```

失败点是 PyMilvus 连接 `localhost:19530` 超时。

这和前面 live smoke 的经验一致:
Docker Milvus 健康，
但 sandbox 内 PyMilvus 对本地端口访问不稳定。

随后把 baseline runner 固定为 `127.0.0.1`，
并在 sandbox 外执行:

```bash
.venv/bin/python evals/rag_retrieval/run_dense_baseline.py
```

这次通过，
并生成报告。

### baseline 指标

本轮 dense-only baseline 结果:

```text
query_count=4
doc_recall@1=1.000
doc_recall@3=1.000
hit@1=1.000
hit@3=1.000
citation_correctness@3=1.000
mrr@3=1.000
latency_ms p50=170.5
latency_ms p95=177
```

这些指标不能被扩大解释为“大样本效果达标”。

它们的作用是:

- 给 P3-2 hybrid recall 提供对照组。
- 给 P3-3 rerank 提供排序对照组。
- 给 P3-4 离线评估脚本提供最小指标形状。
- 给后续失败样本定位提供固定 query 与 gold evidence。

### P3-1 当前正式结论

`P3-1 离线评测集与 dense baseline 固化` 可以标记为完成。

完成口径是:

- 评测集已落盘。
- dense-only baseline 已跑通。
- baseline 报告有 JSON 和 Markdown 两种格式。
- 指标包含 `doc_recall`、`hit`、`MRR`、`citation correctness`、`latency`。
- 后续 P3-2/P3-3 必须与这版 baseline 对比。

这一步不能扩大说明为:

- hybrid search 已经完成。
- rerank 已经完成。
- 评测脚本已经是最终通用版本。
- 大规模真实业务效果已经达标。

### 如果按中国大厂项目深挖来问：为什么 baseline 要用临时 collection，而不是直接用 biz?

建议回答:

```text
因为 baseline 的目的是建立固定对照组，
它不能被历史测试数据、临时 smoke 数据或用户上传数据污染。

如果直接用 biz，
即使 query 和 gold evidence 固定，
检索候选池也可能因为已有数据不同而变化，
指标就不稳定。

所以我用临时隔离 collection 跑 baseline，
跑完后清理 collection。

这样既能真实经过 DashScope embedding 和 Milvus search，
又能保证评测语料是这次脚本明确写入的固定集合。
```

#### 追问 2: 为什么 baseline 不能直接复用业务 collection 里的现成数据?

建议回答:

```text
因为业务 collection 里的候选池会随历史数据变化，
那样 baseline 就失去了可重复性。

我这里需要的是固定 query、固定 gold evidence、固定候选池，
这样后续做 hybrid / rerank 对比时结果才稳定。
```

#### 追问 3: 这个 baseline 除了做对照，还承担什么作用?

建议回答:

```text
它还承担失败定位的起点。

当后面 hybrid 或 rerank 出现回退时，
我可以直接拿这版 dense baseline 对照，而不是重新猜问题来自哪一层。
```

## 2026-05-17 P3-2 BM25 + 向量混合召回完成

### 为什么现在做

P3-1 已经把 dense-only baseline 固化出来了，
现在需要把“稀疏召回 + 密集召回 + 融合”真正补进系统，
才能开始做可解释的比较。

### 本轮新增/修改

- 新增 `app/services/sparse_search_service.py`
- 新增 `app/services/hybrid_search_service.py`
- 扩展 `RetrievalMode` 为 `dense_only / sparse_only / hybrid / hybrid_rerank`
- 在 `knowledge_metadata_store` 上加了 `list_chunks()`，让 BM25 sidecar 直接读持久化 chunk 元数据
- 在 `hybrid_search_service` 里做了 RRF fusion，并把 `recall_score` / `fusion_score` 记回 metadata

### 关键实现形状

`SparseSearchService` 没有新造平行 chunk schema，
而是直接复用 `ChunkRecord` 和 `KnowledgeMetadataStore.list_chunks()`。
BM25 的分词策略也刻意做得很轻:

- 英文和数字按 token 切分
- 中文按字和 2-gram 组合做弱分词

这样能先把结构和边界站稳，
不会因为引入额外依赖把 P3 变成另一个工程。

`HybridSearchService` 负责:

- dense recall
- sparse recall
- RRF fusion
- `HYBRID` / `HYBRID_RERANK` 模式分发

### 风险和处理

风险是 BM25 看起来很“检索工程化”，
但如果它吃的是另一套没有 citation 身份的 chunk，
就会把 P2 的证据边界拆掉。

所以这里强制继续使用 `kb_id/doc_id/chunk_id/source_ref`，
没有另外造平行 chunk schema。

### 验证

- `tests/test_p3_hybrid_retrieval.py` 通过
- `tests/test_p3_retrieval_gate.py` 通过
- `compileall` 通过

### 面试里怎么讲

可以讲成:

> 我没有把 BM25 直接塞进 Retriever 里，而是把它做成一个独立 recall sidecar，再通过 RRF 和 dense candidate 融合。这样后面想比较 dense / sparse / hybrid 的收益时，边界是清晰的，而且不会破坏原来的 citation contract。

### 如果被追问

#### 追问 1: 为什么不是直接上 Milvus 原生 hybrid search?

回答是:

> 这一步先追求可解释和可对比。app 层 BM25 sidecar 能快速和 P2 的 metadata / citation contract 对齐，后面如果需要再考虑更底层的索引形态迁移。

#### 追问 2: 为什么这里用 RRF，而不是把 dense 和 sparse 的分数直接相加?

建议回答:

```text
因为 dense 和 sparse 的分数尺度不在一条线上，直接相加很容易把校准问题藏起来。

RRF 主要看排序位置，先把 dense/sparse 的候选合并稳定，
再谈后续效果比较会更清楚，也更容易解释。
```

#### 追问 3: 你怎么避免 hybrid 变成另一套平行 schema?

建议回答:

```text
我没有新造 chunk schema，而是继续复用 ChunkRecord 和 KnowledgeMetadataStore.list_chunks()。

检索侧还是同一套 kb_id/doc_id/chunk_id/source_ref，
只是多了一个 fusion 层来算 recall_score / fusion_score。
```

## 2026-05-17 P3-3 明确 rerank 层完成

### 为什么要把 rerank 单独拆出来

如果把 rerank 混进 fusion 或 prompt assembly，
后续就会看不清到底是 recall、fusion 还是 rerank 出的问题。
P3 的边界必须是:

```text
recall -> fusion -> rerank -> evidence assembly
```

### 本轮新增/修改

- 新增 `app/services/rerank_service.py`
- 扩展 `RetrievalMode` 支持 `HYBRID_RERANK`
- 在 `app/config.py` 里补了 rerank 的显式配置位:
  - `rerank_enabled`
  - `rerank_model`
  - `rerank_timeout_ms`
  - `rerank_top_k`
  - `rerank_fallback_on_error`
- `HybridSearchService` 现在能把 fused candidates 交给 rerank 层，而不是直接在融合阶段改顺序

### 关键实现形状

现在的 rerank 层不是一个“假装接了模型但其实没有边界”的函数，
而是一个真正独立的 service:

- `enabled=false` 时，明确回退并标记 `rerank_status=disabled`
- scorer 抛错时，明确回退并标记 `rerank_status=fallback`
- 成功时，保留原 `doc_id/chunk_id/source_ref`，只补 `rerank_score`

目前默认 scorer 是本地 lexical baseline，
它不依赖外部 rerank API，所以测试和离线评估都能稳定跑。

### 风险和处理

风险是 rerank 层把结果重新洗牌后，容易误伤 citation identity。

这里的处理方式是:

- rerank 只改排序，不改 identity
- 结果对象沿用同一个 `SearchResult` / `RetrievalResult` 结构
- `retrieval_mode` 只切换成 `hybrid_rerank`

### 验证

- `tests/test_p3_rerank_service.py` 通过
- `tests/test_p3_retrieval_gate.py` 通过

### 面试里怎么讲

可以讲成:

> 我把 rerank 做成独立层，并且保留 disabled / fallback 的明确语义。这样 rerank 即使坏了，系统也只是退回 fused candidates，不会把检索链路整体打断。

### 如果被追问

#### 追问 1: 为什么先用本地 lexical scorer，而不是上外部模型?

回答是:

> 这一步先验证架构边界和失败回退。模型型 rerank 以后可以替换，但 service boundary、timeout、fallback、score 记录这些接口先定住，后面换实现不会再动主链路。

#### 追问 2: 为什么要把 rerank 的开关、超时、top_k 和 fallback 都显式配置出来?

建议回答:

```text
因为 rerank 是可选增强，不是主链路硬依赖。

把这些参数显式化之后，默认行为、失败回退和后续替换模型的边界都更清楚，
也不会把 rerank 伪装成“自动总能成功”的黑盒。
```

#### 追问 3: 如果外部 rerank 模型以后接进来，这一层最少要改什么?

建议回答:

```text
最少只改 scorer 实现和配置，不改 retrieval 的主边界。

只要还能保留 rerank_status、rerank_score，以及原有 doc_id/chunk_id/source_ref，
下游证据结构和门禁就不用跟着重做。
```

## 2026-05-17 P3-4 离线评估脚本完成

### 为什么要补这个脚本

没有固定 query set 和统一报告，
hybrid / rerank 的效果就只能靠感觉讨论。
P3-4 的作用就是把:

- dense_only
- hybrid
- hybrid_rerank

拉到同一张表里比较。

### 本轮新增

- `evals/rag_retrieval/run_retrieval_eval.py`
- `evals/rag_retrieval/reports/retrieval_eval_20260517_174438.json`
- `evals/rag_retrieval/reports/retrieval_eval_20260517_174438.md`

### 这个脚本做了什么

它沿用了 P3-1 的固定 golden queries，
但把同一套查询分别跑在三个模式上:

- `dense_only`
- `hybrid`
- `hybrid_rerank`

每个 query 记录了:

- retrieved chunk ids
- matched gold ids
- citation correctness
- latency
- citation_issues
- 结果级 `source_ref` / `citation_text` / `score` / `metadata`

### 实际结果

这次在本地 Milvus + DashScope 上跑通了，
并且临时 collection 跑完就清理掉了。

在这个很小的固定样本上:

- 三种模式都达到了 `doc_recall@3=1.0`
- 三种模式都达到了 `hit@3=1.0`
- 三种模式都达到了 `citation_correctness@3=1.0`
- 三种模式都达到了 `mrr@3=1.0`

所以这一步的价值不是“证明 hybrid 一定更好”，
而是证明:

1. 对比链路已经存在
2. 指标已经统一
3. 结果可以复跑

### 风险和处理

风险是把一个小样本报告写成生产结论。

所以我在报告里保留了 `citation_issues` 和逐 query 明细，
并明确它只是阶段性对比，不是线上 SLA。

### 面试里怎么讲

可以讲成:

> 我先把评估脚本做成三模式可复跑的，而不是只看单一总分。这样后面调 BM25、fusion、rerank 时，能追到每个 query 的 chunk 命中和 citation 是否一致。

### 如果被追问

#### 追问 1: 为什么 current report 里 hybrid / rerank 没明显超过 dense_only?

回答是:

> 当前固定样本太小，而且 dense baseline 本身已经很强。这个阶段的任务是把可对比、可解释、可复跑的评估框架搭起来，而不是虚报效果差异。

#### 追问 2: 为什么离线评估要用固定 golden queries，而不是直接拿线上请求回放?

建议回答:

```text
因为固定 query set 才能让 dense / hybrid / rerank 做一对一对比。

线上回放会混进流量漂移、用户输入噪声和时间变化，
那样就很难判断是检索方案变了，还是输入本身变了。
```

#### 追问 3: 为什么报告里要同时保留 latency 和 citation correctness?

建议回答:

```text
因为检索不是只看命中，还要看证据是否可引用、响应是否可接受。

如果只看 recall，可能把一个又慢又不稳的方案误判成进步；
把 latency 和 citation correctness 一起放进来，才能把质量和成本都看见。
```

## 2026-05-17 P3-5 门禁与 P3-6 收口完成

### 本轮做了什么

- 新增 `tests/test_p3_retrieval_gate.py`
- 保留并扩展 `tests/test_p3_hybrid_retrieval.py`
- 保留并扩展 `tests/test_p3_rerank_service.py`
- 回写 `task_plan.md`、`PROJECT_STATE.md`、`docs/p1_p2_execution_checklist.md`

### 门禁覆盖了什么

现在 P3 的门禁不是一句“看起来能跑”，而是明确覆盖:

- dense_only 兼容
- sparse_only citation 结构
- hybrid RRF 融合
- hybrid_rerank rerank 边界
- rerank disabled / fallback
- offline eval report

### 风险和处理

风险是 P3 做成实验脚本，最后没有被收口成项目状态。

所以这一步把代码、测试、报告、清单、项目状态一起回写，
让后续打开仓库的人能直接从文件恢复上下文。

### 面试里怎么讲

可以讲成:

> 我不是只补了算法，而是把算法、评估、门禁、项目状态一起闭环了。这样后面如果别人接手，能从文件里直接知道默认模式是什么、哪些能力是 opt-in、哪些只是离线验证。

### 如果被追问

#### 追问 1: 现在默认模式是什么?

回答是:

> 默认仍然是 `dense_only`。`hybrid` 和 `hybrid_rerank` 是显式模式，用于评估和受控启用，不默认替换主链路。

#### 追问 2: 为什么不把 hybrid 直接升级成默认模式?

建议回答:

```text
因为 P3 现在先证明的是边界和对比链路，不是默认策略已经可以替换主链路。

默认模式一旦切过去，影响的是所有调用方，
所以必须等更大样本的离线评估和门禁都稳定后再考虑。
```

#### 追问 3: 如果后面要把默认策略切到 hybrid_rerank，先看什么?

建议回答:

```text
先看离线评估、门禁覆盖和 citation correctness / latency 的整体表现，
再看默认模式切换后会不会破坏现有调用面。

只有当收益和回归边界都清楚了，才适合把它从 opt-in 提升成默认。
```

## 2026-05-17 增强版项目教程文档完成

### 为什么这一步现在要做

P3 已经把 BM25 + 向量混合召回、rerank、离线评估和门禁补齐。
如果只保留开发记录和 checklist，后续读者能知道“做了什么”，但不容易按教程顺序学会“为什么这样拆、怎么沿源码理解”。

所以这一步把增强后的 RAG 项目单独写成教程文档，
用“场景 -> 架构 -> 模块实现 -> 源码对照 -> 评估门禁 -> 边界”的顺序重新组织。

### 本轮新增或更新的文件

- 新增 `docs/oncall_agent_rag_enhanced_tutorial.md`
- 更新 `PROJECT_STATE.md`
- 更新 `progress.md`
- 更新 `docs/rag_fusion_development_record.md`

### 教程覆盖了什么

新教程覆盖了当前增强后项目的完整主线:

- FastAPI / RAG Agent / AIOps / MCP 的应用壳。
- `DocumentRecord`、`ChunkRecord`、`SourceRef` 这些 P1/P2 对象层。
- `ParserEngineRouter`、`DocumentIngestionService`、`MinerUParserAdapter`、artifact 六件套和 `ArtifactManifestService`。
- `VectorIndexService` 的 plain_text / mineru 双路径索引和 doc_id 幂等清理。
- `RetrievalService`、`RetrievalQuery`、`RetrievalResult`、`RetrievalResponse` 和 citation baseline。
- P3 的 `SparseSearchService`、`RrfFusionService`、`HybridSearchService`、`RerankService`。
- `evals/rag_retrieval/run_retrieval_eval.py`、golden queries、Recall / Hit / MRR / citation correctness / latency。
- 与 `/Users/cici/oncall agent/项目源码/super_biz_agent_py-release-2026-05-17` 原始源码快照相比增强了什么。

### 风险和处理

风险是教程写成“项目总结”，而不是“读者可以学习的教程”。

处理方式是按前面写好的 `如何写教程指南.md` 结构来写:

```text
一句话总判断
-> 场景
-> 核心设计
-> 架构图
-> 代码路径
-> 关键类 / 函数
-> 和基础教程相比增强了什么
-> 小结
```

另一个风险是把当前 P3 小样本评估写成“效果已经全面达标”。

所以教程里明确区分:

- 可以说工程链路、citation、评估脚本、门禁闭环已完成。
- 不能说大样本真实业务效果已经优于 dense-only。
- 默认检索模式仍是 `dense_only`，`hybrid` 和 `hybrid_rerank` 仍是显式启用。

### 验证方式

本轮是文档交付，没有改动运行时代码。

已做的检查:

- 确认教程引用的核心模块均存在于当前增强后项目。
- 确认教程里的 P1/P2/P3 阶段边界与 `PROJECT_STATE.md`、`docs/p1_p2_execution_checklist.md` 一致。
- 确认教程没有把 `hybrid/rerank` 夸大成默认线上策略。

### 面试里怎么讲

可以讲成:

> 我把项目从开发流水账整理成了可讲解的工程教程。它不是只列功能，而是按 RAG 系统的关键边界讲: 文档身份、artifact contract、chunk/source_ref、幂等索引、citation retrieval、hybrid/rerank、offline eval 和 gate。这样别人既能沿源码学习，也能看出每一层为什么存在。

### 如果被追问

#### 追问 1: 为什么还要单独写教程，开发记录不是已经很详细了吗?

建议回答:

```text
开发记录解决的是“项目做过什么”和“每一步怎么收口”。
教程解决的是“读者怎么理解这个系统”。

这两个文档的阅读目标不同。
所以我把开发记录里的阶段事实重新整理成架构图、模块职责、代码路径和源码对照，
让读者可以按系统层次学习，而不是在时间线里找线索。
```

#### 追问 2: 教程里为什么要强调和原始源码相比增强了什么?

建议回答:

```text
因为这个项目不是从零写一个 RAG demo，
而是在已有 oncall agent 代码上补 RAG 工程化边界。

如果不和原始源码对照，
就看不出这轮增强到底是解决了哪些真实问题:
文档身份、artifact 契约、幂等清理、citation、hybrid/rerank 和评估门禁。
```

#### 追问 3: 教程里为什么反复强调边界，而不是直接展示最终效果?

建议回答:

```text
RAG 项目最容易的问题是链路看起来能回答，但内部不可追源、不可回归、不可评估。

所以教程先讲边界:
上传层不做 parser 判断，
parser 层不做索引，
index 层不做 citation 拼接，
retrieval 层不做 rerank，
rerank 层不改 source_ref。

边界清楚之后，效果优化才有稳定前提。
```

## 2026-05-17 增强版项目教程补充: 10 文件源码精读顺序

### 为什么继续补这一步

用户希望教程不只告诉读者“建议按哪些文件读”，而是按这个顺序详细解释每个文件的代码。

这一步的目标不是做逐行注释，
而是让读者沿着源码顺序理解:

- 这个文件在 RAG 链路里的位置。
- 应该优先看的类、函数和字段。
- 它和前后文件怎么衔接。
- 设计边界和面试复述点是什么。

### 本轮改动

- 扩展 `docs/oncall_agent_rag_enhanced_tutorial.md` 的 `继续学习路径`。
- 新增 `## 10. 读完源码后应该形成的主线`。
- 将教程里的“详细解释”标准和源码精读文档对齐到同一套 6 点结构，并补上深度文档入口。
- 同步更新 `PROJECT_STATE.md` 和 `progress.md`。

### 补充后的源码阅读顺序

教程现在按下面 10 个文件展开:

1. `app/models/knowledge.py`
2. `app/services/parser_engine_router.py`
3. `app/services/document_ingestion_service.py`
4. `app/services/artifact_manifest_service.py`
5. `app/services/artifact_chunk_builder_service.py`
6. `app/services/vector_index_service.py`
7. `app/services/retrieval_service.py`
8. `app/services/hybrid_search_service.py`
9. `app/services/rerank_service.py`
10. `evals/rag_retrieval/run_retrieval_eval.py`

### 这次补充的关键解释口径

这次把源码阅读路线写成一条完整调用链:

```text
knowledge.py 定义身份和契约
-> parser_engine_router.py 决定文件进入哪条解析链
-> document_ingestion_service.py 管理上传、状态和解析入口
-> artifact_manifest_service.py 把 MinerU 产物声明成 contract
-> artifact_chunk_builder_service.py 把 chunks/tables 转成可索引证据
-> vector_index_service.py 写入 metadata store 和 Milvus，并做幂等清理
-> retrieval_service.py 把 raw hits 组装成 citation-aware evidence
-> hybrid_search_service.py 增加 BM25 + dense + RRF 的召回能力
-> rerank_service.py 增加可开关、可回退的精排边界
-> run_retrieval_eval.py 用固定评估集证明三种模式可对比
```

### 风险和处理

风险是“详细解释”变成逐行翻译，读者看完还是抓不住系统结构。

所以文档里把“详细解释”定义成:

1. 文件职责。
2. 关键类、函数和字段。
3. 上下游连接。
4. 关键执行流程。
5. 设计亮点、边界和风险。
6. 面试或项目复盘时的说法。

这样既比简单目录详细，又不会把教程写成代码逐行注释。

### 面试里怎么讲

可以讲成:

> 我把源码阅读路线整理成了 10 个文件的主线: 先看领域模型，再看 parser 路由和文档接入，然后看 artifact contract、chunk builder、索引写入，最后看 retrieval、hybrid、rerank 和离线评估。这样读者不是零散看文件，而是按 RAG 工程链路理解每一层职责。

### 如果被追问

#### 追问 1: 为什么源码阅读第一步是 `knowledge.py`，不是 API 入口?

建议回答:

```text
因为增强版 RAG 的核心不是某个接口，而是文档、chunk、source_ref 和 retrieval result 的身份契约。

先读模型层，后面看 parser、indexer、retriever 时才知道每一层到底在维护什么对象。
```

#### 追问 2: 为什么把 `hybrid_search_service.py` 放在 `retrieval_service.py` 后面读?

建议回答:

```text
因为 retrieval_service 先定义了最终证据输出的形状。

hybrid search 只是召回和融合增强，
它最终仍然要回到 RetrievalResult / RetrievalResponse。
如果先看 hybrid，容易误以为算法层才是主线。
```

#### 追问 3: 为什么最后读评估脚本?

建议回答:

```text
因为评估脚本是对前面所有边界的综合验证。

只有先理解 doc_id、chunk_id、source_ref、retrieval_mode、rerank_status，
才能看懂为什么评估要同时算 recall、hit、MRR、citation correctness 和 latency。
```

## 2026-05-18

### 为什么现在先写 chunk 重构计划

这次用户没有让我直接开改代码，而是先把 chunk 重构路线写成一份项目内可复用、可继续执行的 Markdown 计划。

这个要求的关键不是“随手列一个 todo”，而是:

1. 把当前仓库 chunk 相关代码边界重新梳理清楚。
2. 把哪些问题该先修、哪些不能混着做，明确写成阶段顺序。
3. 把这条新路线同步进项目状态，而不是只留在聊天上下文里。

### 这次先核对了哪些代码边界

本次先重读了以下几层:

1. `app/services/document_splitter_service.py`
2. `app/services/vector_index_service.py`
3. `app/services/artifact_chunk_builder_service.py`
4. `app/services/mineru_parser_adapter.py`
5. `pdf_eval/scripts/mineru_postprocess.py`
6. `app/services/retrieval_service.py`
7. `app/services/sparse_search_service.py`
8. `app/services/rerank_service.py`

这次确认了一个之前容易说糙的点:

```text
当前 chunk policy 不是“两套”，而是“三套”:
md/txt splitter
-> MinerU postprocess chunking
-> ArtifactChunkBuilder 隐式要求的规范化层
```

所以如果后面说“统一 ChunkPolicy”，正确意思应该是:

```text
统一最终 chunk 边界层
不是统一原始 parser/splitter
```

### 这次形成的最终路线

这次把路线收成 4 个阶段:

1. P1: 先修 `DocumentSplitterService._merge_small_chunks()` 的跨标题误合并 bug。
2. P2: 再引入统一 `ChunkPolicy`，把 `plain_text` 和 `mineru` 的最终 chunk 边界收口。
3. P3: 再统一 dense / sparse / rerank 对标题上下文的利用，但不污染展示原文。
4. P4: 最后才做 `parent_chunk_id` 和父子 chunk 回溯。

### 为什么不直接把标题写回 content

这次专门把一个实现诱惑压住了:

```text
不要直接把 heading_path 永久拼回 ChunkRecord.content
```

原因是当前 `content` 会直接进入:

1. Milvus 存储文本
2. retrieval 返回正文
3. 用户看到的内容片段

如果现在直接把标题前缀永久写回去，后面很容易出现:

- 展示文本被污染
- citation 上下文重复标题
- 检索和展示共用一个被加工过的正文

更稳的方案是:

```text
display content = 原文
embedding/search text = heading_path + 原文
```

### 这次实际落下来的文档

本次新增了:

- `docs/chunk_refactor_execution_plan.md`

并同步更新了:

- `task_plan.md`
- `findings.md`
- `progress.md`
- `PROJECT_STATE.md`

### 如果后面继续做

下一步应从 P1 开始，不要跳到统一 `ChunkPolicy` 或 parent-child chunk。

因为现在最便宜且最确定的收益，是先把 md/txt 路径的跨标题误合并 bug 修掉，再让后面的统一方案建立在一个更干净的本地基线上。

### 计划文档这次又收紧了什么

这轮又把 5 个实现前容易含糊的点提前收到了计划里:

1. 明确 P2 落地后，MinerU 的 `chunks.json` 在主仓库里应理解为“候选最终块”，不是不可再改的最终块。
2. 明确 P2 必须新增 `tests/test_chunk_policy_service.py`，而不是只靠旧 gate 间接覆盖。
3. 明确 P3 要落在 dense 写入路径，保持 `ChunkRecord.content` 不变，并把 heading-aware 的拼接抽成公用 helper。
4. 明确 P5 与 P4.5 的先后协同，避免后面 doc 聚合和 context granularity 互相返工。
5. 明确 P1/P2/P3 每一步都要跑一次 `evals/rag_retrieval/run_retrieval_eval.py`，给 chunk 边界变化留下数字基线。

这样做的目的不是把计划写得更长，而是把真正会在开发时争论的语义边界提前锁死。

---

## 2026-05-18 P4.5 context_granularity 主线实施

### 这一步在做什么 / 为什么现在做

P4 已收尾：parent 文本通过 `RetrievalResult.metadata.parent_content` 暴露给上层，但回答阶段还没人消费。P4.5 的目标是把这层"已经准备好的父块上下文"接到回答时机，并补上 `full_doc` 选项，覆盖 SOP / 短结构化文档场景。明确划界：本期不做 P5 (doc-level dedup)、不做 P6 (domain_metadata)。

### 实现边界（落入代码的硬口径）

1. 三模式只重建 `RetrievalResponse.context_text`，**不改** `RetrievalResult.chunk_id / content / source_ref / citation_text`。这条是"P4.5 不破坏 P4 citation 主语义"的硬边界。
2. 默认仍是 `chunk`。`parent_chunk` / `full_doc` 仅显式指定时启用，`retrieve_knowledge` 工具不自动按 doc 长度切换。
3. `full_doc` 的文本来源**只能**是 `KnowledgeMetadataStore` 中非 parent 子块的有序拼接，不读 `original_path` 或 `cleaned.md`。原因：pdf/docx 原始文件无法直接拼字符串；`cleaned.md` 在 P2 之后已显式不进入入库输入路径。helper 命名为 `_assemble_full_doc_context`，避免 `_load_full_doc_text` 这种容易让人误以为去读原文的名字。
4. 同 parent 多 child / 同 doc 多 hit：**重复拉，不做合并**。这是为了让 token 浪费作为 P5 启动证据被显式量化；如果在 P4.5 内偷加 dedup fallback，会污染 P5 的判断依据。
5. `metadata["expanded_context"]` / `metadata["context_granularity_fallback"]` 只在 retrieval response 构造期存在。不写回 metadata store / 不写入 Milvus / 不进入 `retrieve_knowledge` artifact 的稳定契约字段。
6. citation 不变性以**有序** `[(chunk_id, citation_text)]` 列表相等的方式断言，不只是集合相等。理由是 P4.5 不该改命中顺序，集合相等会漏掉顺序漂移这种 bug；citation_text 内含 `source_file / page / heading_path / chunk_id`，可一次性兜住 SourceRef 漂移。
7. token 成本统计使用 `dashscope.tokenizers.qwen_tokenizer.QwenTokenizer`，与 `config.rag_model = qwen-max` 对齐。禁止 `len(text)/4`、字符数、word count 之类启发式。

### 改动了哪些文件

- `app/models/knowledge.py`: 新增 `ContextGranularity(StrEnum)`；`RetrievalQuery` 增加 `context_granularity: ContextGranularity = ContextGranularity.CHUNK`。
- `app/models/__init__.py`: 导出 `ContextGranularity`。
- `app/services/retrieval_service.py`:
  - `retrieve()` 透传 `query.context_granularity` 到 `_format_context()`。
  - `_format_context(results, granularity)` 三分支组装 + 在每条 result 上挂 `expanded_context` / `context_granularity_fallback`。
  - 新增 `_resolve_context_body()` 与 `_assemble_full_doc_context()`。
- `tests/test_p4_5_context_granularity.py`: 10 条用例（chunk 行为 / parent_chunk happy path / parent_chunk fallback / full_doc happy path / full_doc fallback / 同 parent 多 child 重复拉 / 同 doc 多 hit 重复拉 / 三模式有序 citation 相等 / 默认值是 chunk / `expanded_context` 不持久化）。
- `evals/rag_retrieval/p4_5_samples.jsonl`: 25 条样本，4 类场景 (`parent_advantage 5` / `multi_child_hit 5` / `long_doc 8` / `reverse_control 7`)。
- `evals/rag_retrieval/run_p4_5_eval.py`: 三模式跑评测、Qwen tokenizer、有序 citation 断言、per-category 区分度自检、P5 启动证据采样。
- `docs/p4_5_context_granularity_design.md`: 设计文档。三处用户审阅意见落地：(a) `full_doc` 文本来源硬口径 §1.1；(b) `expanded_context` 生命周期硬口径 §1.2；(c) citation 不变性改为有序列表 §4。
- `docs/chunk_refactor_execution_plan.md` / `PROJECT_STATE.md` / `task_plan.md`: 状态推进至 P4.5 已完成，P5/P6 仍 deferred。

### 评测过程中遇到的真实阻塞与处理

第一轮评测 (`evals/rag_retrieval/reports/p4_5_eval_20260518_151005.json`) 区分度自检 `parent_advantage` **0/5** 失败：

| mode | tokens_avg | keyword_coverage_avg | signal_density_avg |
|---|---|---|---|
| chunk | 1681 | 0.96 | 0.0055 |
| parent_chunk | 2302.6 | 0.96 | 0.0052 |
| full_doc | 7405 | 0.96 | 0.0039 |

`parent_chunk` token 是真在涨（说明 `parent_content` 真挂上了、没误进 fallback、实现没坏），但 `keyword_coverage` 三模式完全一致，所以阈值过不了。诊断是**评测样本设计问题**：第一轮 5 条 query 的 `expected_keywords` 全部落在被命中那个 child 里，parent 拉进来的兄弟 child 文本只贡献 token，不贡献 keyword 命中。

按硬口径不能私自跑后调阈值（C 路径被禁），也不能私自把"parent_advantage 持平"写进结论，所以停下来汇报。最终选 A 路径（改样本不改实现 + 阈值不变），并设了 stop loss：A 单轮失败即转 B (扩语料)，C 始终禁用。

第二轮重写 5 条 `parent_advantage` query：query 锚定 c00003 一侧（窄 query 让 dense recall 不会把 c00004 拉进 top-3），但 `expected_keywords` 强制跨 c00003 + c00004 边界，迫使 chunk 模式 kw_cov < 1.0、parent_chunk 模式 kw_cov = 1.0。

在重写前先做了 keyword 唯一性 grep（`logrotate / find /var/log` 等只在 c00003，`docker prune / 多阶段构建 / LRU / Redis` 等只在 c00004），避免改完 keyword 又被其他 top-3 候选 chunk 顺手覆盖。

### 第二轮评测结果

报告路径 `evals/rag_retrieval/reports/p4_5_eval_20260518_154233.{json,md}`。

| 类别 | 命中 / 总数 | 比例 | 通过 |
|---|---|---|---|
| parent_advantage | 4 / 5 | 0.80 | PASS |
| multi_child_hit | 3 / 5 | 0.60 | PASS |
| long_doc | 8 / 8 | 1.00 | PASS |
| reverse_control | 6 / 7 | 0.86 | PASS |

`citation_invariant_all_ok = true`，25 条样本三模式 `[(chunk_id, citation_text)]` 有序列表完全相等。

三模式 token 成本（Qwen tokenizer）：

| 模式 | tokens_avg | tokens_p95 | tokens_max | signal_density_avg | keyword_coverage_avg |
|---|---|---|---|---|---|
| chunk | 1376.1 | 1831 | 2305 | 0.0103 | 0.964 |
| parent_chunk | 1660.3 | 2804 | 2986 | 0.0111 | 0.992 |
| full_doc | 6715.4 | 7405 | 7407 | 0.0067 | 0.992 |

### 不回归证据

- `unittest discover tests`: **88/88 pass**（78 原有 + 10 P4.5 新增）。
- `evals/rag_retrieval/run_retrieval_eval.py` 4 条 P3 golden queries：`dense_only` `recall@1=1.0/mrr@3=1.0`、`hybrid` 同、`hybrid_rerank` `0.75/0.875`，与 P4 baseline 完全持平。

### P5 启动证据（不实现，仅记）

- `multi_child_parent_chunk_waste_>=30%_ratio = 0.6`（multi_child_hit 60% 样本 parent_chunk token ≥ 1.30× chunk）。
- `any_full_doc_waste_>=50%_ratio = 1.0`（每条样本 full_doc ≥ 1.50× chunk）。
- 同时满足 `parent_waste_30 >= 0.5` 与 `full_doc_waste_50 >= 0.5`，按 P4.5 设计 §10 视为稳定启动证据。

### 评测集真实约束（写下来给后续用）

5 篇 aiops-docs 在 splitter (`chunk_max_size=800`, `chunk_max_size×2=1600`, `min_size=300`) 下产出：

```
cpu_high_usage      8 children, 0 parents
memory_high_usage  11 children, 0 parents
disk_high_usage    12 children, 1 parent  (常见原因分析: c00003+c00004)
service_unavailable 12 children, 0 parents
slow_response      11 children, 0 parents
```

整套语料里**只有 1 个 section parent**，覆盖 `disk_high_usage.md` "常见原因分析"两段。这是为什么 P4.5 评测 `parent_advantage` 与 `multi_child_hit` 都被迫围绕同一段语料设计 query；这条结构性约束在 `PROJECT_STATE.md` 的 Open Problems 也已记下。后续如要强化 P4.5 类信号，需要在 MinerU 解析的长文档语料上做（连续同 heading 多段更常见），或扩 aiops-docs 写更多多段同节正文。

### 这一步如果在面试场景被问到，可解释的细节

1. **为什么 citation 不变性要用有序列表 + citation_text 双重断言，不只是 chunk_id 集合？** P4.5 理论上不该影响命中顺序、source_ref 与 citation 显示，集合断言只兜身份漂移，不兜排序漂移与 SourceRef 漂移；citation_text 内含 `source_file / page / heading_path / chunk_id`，一次兜住四类回归。
2. **为什么 same-parent 多 child 不做 dedup？** 这是 P4.5 与 P5 的边界。P4.5 内部偷加合并会让 P5 判断重复浪费的信号失真。我们专门让重复浪费在 P4.5 评测里被显式量化（`token_ratio_parent_chunk_over_chunk` / `token_ratio_full_doc_over_chunk`），作为下一阶段开工的硬证据，而不是依赖事后回忆。
3. **为什么 `full_doc` 不让默认？** 长文档 token 膨胀严重（评测里 full_doc 平均 6715 tokens，是 chunk 模式的 4.9×），如果默认开就直接把 LLM 上下文打爆；短结构化文档场景下才有收益。所以默认只开 `chunk`，`parent_chunk` / `full_doc` 显式按业务场景按 KB 决定。
4. **为什么 `_assemble_full_doc_context` 只读 metadata store，不读 `original_path`？** pdf/docx 是二进制源，无法直接拼字符串；`cleaned.md` 在 P2 后已显式不进入入库输入路径。索引时落入 metadata store 的非 parent 子块就是 P4 之后唯一被授权进入回答上下文的文本载体；从同一处取，跟检索阶段的真值绑定。
5. **第一轮 0/5 之后为什么没改阈值或合并 P5？** 阈值跑前固定（设计 §6/§9），跑后调阈值会污染评测公信力；合并 P5 会把 dedup 信号做没。所以选 A 改样本，并明确 A 单轮失败即转 B，C 始终禁用。

---

## 2026-05-18 P5 doc-level dedup 主线实施

### 这一步在做什么 / 为什么现在做

P4.5 收尾时显式量化出两条 P5 启动证据 (`multi_child_parent_chunk_waste_>=30%_ratio = 0.6`、`any_full_doc_waste_>=50%_ratio = 1.0`)，触发 P4.5 设计 §10 的 P5 启动条件。P5 的目标是把"同 doc 多 chunk 挤满 top-K"在召回结束后、组装上下文前显式 dedup。明确划界：本期不做 P6 (`domain_metadata` enricher)。

### 实现边界（落入代码的硬口径）

1. dedup 不动召回：`RetrievalService` 把原 `retrieve()` 的核心逻辑抽成 `_retrieve_candidates()`，dedup 只在它返回后做。dense / sparse / hybrid / rerank 一律不动。
2. dedup 不改 citation：返回 result 的 `chunk_id / content / source_ref / citation_text` 与候选池里同 chunk_id 那条**逐字段**相等。设计 §4 用 4 条代码断言锁这条不变量（不只是 chunk_id 集合断言）。
3. 默认 `none` 字节级等价 P4.5：单测 `test_none_path_byteforbyte_equivalent_to_p45_baseline` 锁 chunk_ids、citation_text、context_text 三者全相等；`test_none_path_ignores_top_chunks_per_doc_and_oversample_factor` 锁两个高级字段在 NONE 下绝对 no-op（即使被显式调到 99 也不放大候选池、不挂 `aggregation_*` 观测位）。
4. `doc_level` 是显式开关：`retrieve_knowledge` 工具不传 `result_aggregation`，依赖默认 `none`，工具行为零变化。`doc_oversample_factor` 标为高级参数不暴露到工具层。
5. 候选池放大不能递归：`_retrieve_with_doc_aggregation` 构造 pool_query 时强制 `result_aggregation = NONE`，避免 dedup 嵌套。
6. doc 间排序键跑前固定：`doc_hit_count` 降 → `doc_max_score` 降（`None` 视为 -∞）→ `doc_id` 升。这条单测 `test_doc_level_ranks_docs_by_hit_count_then_max_score_then_doc_id` 用一个三键都不平凡的样本锁。
7. `top_k` 主语义是 doc 数：默认 `top_chunks_per_doc=1` 时 `len(results) ≤ top_k`，与现状一致；调高后 `len(results)` 允许大于 `top_k`，硬上限 `top_k * top_chunks_per_doc`。`test_doc_level_length_caps` 锁这两条。
8. 三个观测位生命周期：`aggregation_doc_hit_count / aggregation_doc_max_score / aggregation_dropped_chunk_ids` 与 P4.5 `expanded_context` 同口径——构造期临时、不写回 metadata store、不入 Milvus、不进 `retrieve_knowledge` artifact 稳定契约。`test_aggregation_observability_not_persisted_to_metadata_store` 锁这条。
9. 与 P4.5 三 granularity 正交：`DOC_LEVEL` 在 `parent_chunk` / `full_doc` 下顺带消除 P4.5 §3 的"重复拉"语义，但仅在用户**显式**选 `doc_level` 时生效；P4.5 在 `none` 下的硬口径不变。这不是 P4.5 偷加 fallback，是用户显式选择的另一个旋钮。

### 改动了哪些文件

- `app/models/knowledge.py`: 新增 `ResultAggregation(StrEnum)`；`RetrievalQuery` 增加 `result_aggregation` (默认 `NONE`) / `top_chunks_per_doc` (默认 1) / `doc_oversample_factor` (默认 4，高级参数)。
- `app/models/__init__.py`: 导出 `ResultAggregation`。
- `app/services/retrieval_service.py`:
  - `retrieve()` 按 `query.result_aggregation` 分支：`NONE` 走 `_retrieve_candidates()` 与 P4.5 baseline 字节等价；`DOC_LEVEL` 走 `_retrieve_with_doc_aggregation()`。
  - `_retrieve_candidates()` 抽出原召回路径主体。
  - `_retrieve_with_doc_aggregation()` 候选池放大 + 强制 NONE 防递归。
  - `_aggregate_by_doc()` 三键排序 + 每 doc 上限 + 三观测位挂载。
- `tests/test_p5_doc_level_dedup.py`: 13 条用例覆盖默认值、字节等价、绝对 no-op、候选池放大、doc 排序、per-doc 上限、长度上限、citation 字段逐条等价、观测位生命周期、`DOC_LEVEL × {chunk, parent_chunk, full_doc}` 三 granularity 交互。
- `evals/rag_retrieval/p5_samples.jsonl`: 20 条样本 / 3 类。
- `evals/rag_retrieval/run_p5_eval.py`: pool / NONE / DOC_LEVEL 三次 retrieve；4 条 §4 不变性强断言；3 类区分度自检；P6 启动证据采样。
- `docs/p5_doc_level_dedup_design.md`: 设计文档。三处用户审阅意见落地：(a) 高级参数不暴露到工具层 §1 表格；(b) NONE 绝对 no-op 写死 §1.1；(c) `top_k` 长度上限写死 §1.2。
- `docs/chunk_refactor_execution_plan.md` / `PROJECT_STATE.md` / `task_plan.md`: 状态推进至 P5 已完成，P6 仍 deferred。

### 评测过程中遇到的真实阻塞与处理

第一轮 (`evals/rag_retrieval/reports/p5_eval_20260518_201140.json`) `cross_doc_already` 区分度自检 **3/6 (50%)** 失败：003 (OOM/GC) NONE distinct=1，004 (重启) NONE distinct=2，005 (限流降级熔断) NONE distinct=2。诊断是评测样本归类问题：dense recall 把这三条 query 推到单簇（`GC` 12/0/0/0/0 集中 memory；"重启"集中 memory+svc；"降级/熔断" 0/0/0/5+2/4+1 集中 svc/slo）。

按用户给的 stop loss 走 A 路径单轮重写，规则：阈值不动，只改 003/004/005。重写前先用实际语料 grep 验证关键词分布。

第二轮 (`reports/p5_eval_20260518_201949.json`) `cross_doc_already` **4/6 (67%)** 仍未达 70%：grep 频次平衡的"排查步骤/验证步骤/联系方式/ap-guangzhou"在 dense recall 下被推到 `service_unavailable.md` 单簇（NONE distinct=1）；"5分钟内立即操作/30分钟内/持续监控"被推到 `slow_response.md` 单簇。重要发现：**grep 频次均衡 ≠ dense recall 命中均衡**。dense embedding 还吃两个 grep 看不见的因子：(a) chunk 内关键词聚集度，(b) query 整体语义偏向。

按 stop loss 转 B-1 单轮（用户拍板：B-1 优于 B-2，B 也走单轮 stop loss，失败即承认语料边界）。

第三轮 B-1 (`reports/p5_eval_20260518_202904.json`):
- 把 round-2 的 cross_004 / cross_005 两条 query 内容**移到** `same_doc_redundant_007 / 008`（数据已证明它们是 NONE distinct=1 → DL distinct=3 的真阳性 same_doc_redundant 形态）。
- 003 留在 `cross_doc_already`（round-2 数据已是 NONE distinct=3 真分散）。
- 新补 `cross_004 / cross_005` 严格只用已通过形态的安全词集合："查询语句/查询示例/查询条件"以及"ap-guangzhou/30分钟/时间范围"，切面与 003 / 006 正交。
- 区分度阈值 §9 一字未改。

### 第三轮 B-1 评测结果

| 类别 | 命中 / 总数 | 比例 | 通过 |
|---|---|---|---|
| same_doc_redundant | 8 / 8 | 1.00 | PASS |
| cross_doc_already | 6 / 6 | 1.00 | PASS |
| reverse_control (退化率) | 0 / 6 | 0.00 | PASS |
| **overall_passed** |  |  | **true** |

`citation_invariant_all_ok = true` (4 条断言 × 20 样本)。

两策略 token 与 doc 多样性汇总（Qwen tokenizer / qwen-max）：

| 策略 | tokens_avg | distinct_doc_count_avg | top1_doc_match_avg |
|---|---|---|---|
| NONE | 1085.0 | 1.75 | 0.95 |
| DOC_LEVEL | 949.6 | 2.75 | 0.90 |

DOC_LEVEL 在 `same_doc_redundant` 类上 distinct doc 从 1.13 拉到 2.63，token 从 1456 降到 1192（−18%），符合 P5 设计核心收益假设；在 `cross_doc_already` 类上 distinct=3 完全不变；在 `reverse_control` 类上 0/6 退化。

### 不回归证据

- `unittest discover tests`: **101/101 pass**（88 P4.5 收尾后 + 13 新增 P5 单测）。
- `evals/rag_retrieval/run_retrieval_eval.py` 4 条 P3 golden queries 三模式与 P4.5 baseline 完全持平。
- `evals/rag_retrieval/run_p4_5_eval.py` 默认模式 `citation_invariant_all_ok = true`、4 类区分度自检与 P4.5 收尾结果完全一致，证明 P5 改动对 P4.5 baseline 零污染。

### P6 启动证据（不实现，仅记）

- `p6_evidence.trigger_p6 = false`：当前 aiops-docs 语料没有 path / 目录 / domain 显式 metadata，本次评测里没有 ≥ 3 条查询需要 path/folder filtering，反向控制类也没有出现仅靠 `kb_id` 不足以表达的稳定信号。
- 结论：P5 评测**未触发** P6 启动证据。开 P6 thread 时需要先扩样本到带显式领域过滤需求的语料，不允许直接基于"语义直觉"启动 P6。

### 评测集真实约束（写下来给后续用）

5 篇 aiops-docs 语料天然偏向 single-doc semantic anchor。`cross_doc_already` 信号在本语料上窄到只能用"程序性框架词组合"（查询规范、扩容/告警同模板术语）；任何带"章节标题词"或"时序紧急处理"措辞的 query 都容易被 dense embedding 推到单簇，**无视 grep 频次均衡**。这条边界以"评测限制"形式记入 `PROJECT_STATE.md` Open Problems。

### 这一步如果在面试场景被问到，可解释的细节

1. **为什么把 `_retrieve_candidates` 抽出来，而不是在 `_aggregate_by_doc` 内部直接调召回？** 抽出来才能让 NONE 路径的语义和 P4.5 baseline 字节等价被单测可证伪——一个明确的"原召回路径主体"比一个内嵌的 callback 更容易锁不回归。同时让 DOC_LEVEL 用 `query.model_copy(update={"top_k": pool_k, "result_aggregation": NONE})` 显式构造 pool_query，把"防递归"这条规则写进数据流而不是注释里。
2. **为什么 doc 排序主键是 `doc_hit_count` 不是 `doc_max_score`？** 用户痛点是"同文档多 chunk 挤满 top-K"，hit_count 是直接对应的信号；max_score 作次键。反过来用 max_score 作主键会让某 doc 一条强命中加多条弱命中的情况下还是优于另一个 doc 多条均匀命中，与"列表分散到不同 doc"的目标相悖。
3. **为什么 `top_chunks_per_doc=1` 时 `len(results) ≤ top_k`，而调高后允许超过？** 设计 §1.2 写死了 top_k 是 doc 数主语义，这条选择把"用户调高 per-doc cap"显式视为用户自负责的 token 预算决策，而不是在内部偷偷做截断。否则，每次 token 预算变化都得在 retrieval 层做一份和 LLM 协商语义相同的策略，复杂度会爆。
4. **为什么 §4 citation 不变性是 4 条断言而不是 1 条？** chunk_id 集合断言只能兜身份漂移；4 条加起来兜：身份不发明（DL ⊆ pool）、源池可比（NONE ⊆ pool）、字段逐条相等（chunk_id/content/source_ref/citation_text）、长度上限。这是把"dedup 不该改 result 的 5 个维度"分别打成断言，而不是依赖一句"dedup 不改 citation"。
5. **第一轮 3/6 失败、第二轮 4/6 仍失败、第三轮 B-1 一次过线，过程的关键决策？** 关键有三个：(a) 阈值跑前固定，**禁用 C** 路径全程不动；(b) A 单轮 stop loss 防"无限刷样本到过线"；(c) 第二轮失败的诊断"grep 频次均衡 ≠ dense recall 命中均衡"是新发现的语料边界——用 dense embedding 真实命中分布做归类，不再用语义直觉，所以 B-1 的归类是数据驱动的，不是我把样本硬塞过线。

---

## 2026-05-18 P5 close-out / P6 前置门槛锚定

### 这一步在做什么

P5 评测过线后，在开 P6 之前先把"已验证范围"和"P6 前置门槛"显式写死，避免后续把 P5 当成"已经在生产语料上验证过"误用，也避免 P6 被语义直觉提前启动。这一步只动文档，不动代码。

### 已验证范围（写进 `PROJECT_STATE.md` "P5 Validated Scope"）

P5 仅在以下口径下被签字：

- 解析路径：仅 `plain_text`；MinerU 端到端未走过 `DOC_LEVEL`。
- 语料：5 篇 aiops-docs / 共 1 个 section parent / 总计 ~50 个 chunk；长文档、大语料、多 KB 未验。
- 检索模式：仅 `dense_only`；`hybrid` / `hybrid_rerank` × `DOC_LEVEL` 结构上支持但未评测。
- granularity 覆盖：单测层 `DOC_LEVEL × {chunk, parent_chunk, full_doc}` 全有；评测层只跑了 `DOC_LEVEL × chunk`。
- LLM 端到端：未验。`citation_invariant_all_ok` 只证明 retrieval 侧不漂。
- 参数：仅默认 `top_chunks_per_doc=1` / `doc_oversample_factor=4`。
- 工具层：`retrieve_knowledge` 不传 `result_aggregation`，所有 agent / planner caller 仍走 NONE。

### P6 前置门槛 5 项 follow-up（写进 `PROJECT_STATE.md` Next Step 与 `task_plan.md` Phases）

P6 不允许在以下 1–3（条件性 4）任一未完成时启动：

1. **P5.f1 MinerU 长文档 follow-up eval**：dedup 在长文档上稳吗、`doc_oversample_factor=4` 够吗、token 不会被放大到不可接受。
2. **P5.f2 P4.5 + P5 联合验证**：`DOC_LEVEL × parent_chunk` / `DOC_LEVEL × full_doc` 在长文档上的真实 token / doc 多样性，看 dedup 与 P4.5 expansion 会不会互相放大 token 浪费。
3. **P5.f3 LLM 端 citation 漂移验证**：小规模接 LLM 跑端到端，覆盖 child-only / parent_chunk / full_doc / doc_level。
4. **P5.f4 P5 参数调优（条件性）**：仅在 f1 / f2 暴露明显问题时单开一轮。
5. **P6 启动证据判定**：必须在真实语料里**稳定**出现 (a) 需要 path/folder/domain 过滤、(b) 仅靠 `kb_id` 不够、(c) "如果有 domain metadata 会明显更好"的稳定案例。当前 `trigger_p6 = false`。

### 这一步不允许偷跑的事

- 不允许把 P5 状态从 "P1-P5 complete" 改成 "P5 deferred"。P5 实现层已通过、不变性已锁，是真完成。
- 不允许把 P5 Validated Scope 移到 Open Problems 或注释里。它是 P5 close-out 共识的一部分，必须显式写在 `PROJECT_STATE.md` 主体。
- 不允许把 5 项 follow-up 写成 "建议"。它们是 P6 前置硬门槛，按顺序执行，不允许跳。
- 不允许在 P5.f1 / f2 / f3 任一未完成时把 P6 状态改成 pending；P6 在文档里固定为 `gated`。
- P5.f1/f2/f3 不允许合做一个 PR；与 P4.5 / P5 同样精神，每一步独立证据、独立报告。

### 这一步如果在面试场景被问到

1. **为什么 P5 评测过线了还要先做 follow-up，不直接开 P6？** P5 评测的过线区间是 plain_text / 5 篇 aiops-docs / dense_only / 默认参数 / 无 LLM 一字。这个区间和"P5 在生产语料上稳定"之间还差 3 块证据：长文档、与 P4.5 联合、LLM 端到端。任何一块没补就开 P6，等于把 P5 假设当成事实，是工程上常见的越权 close-out。
2. **为什么不把 P6 直接禁用，而是写成 `gated`？** 禁用是消极信号，gated 是带条件的允许。前置门槛一旦满足，P6 就可以开；这种写法把判断逻辑显式化，避免后续讨论时反复绕"P6 到底能不能做"。
3. **P5.f4 为什么是 conditional 而不是 mandatory？** 默认值如果在 f1 / f2 上够用，调参是浪费；只有在 f1 / f2 暴露 token 放大或 dedup 不稳时才有信号去调。提前调参等于在没有问题前优化解，违背 YAGNI。

---

## 2026-05-18 P5.f1 MinerU 长文档 follow-up eval

### 这一步在做什么 / 为什么现在做

P5 close-out 共识里把 P6 前置门槛拆成 5 项，第 1 项就是验证 `DOC_LEVEL` 在长文档 + MinerU 解析下还稳不稳。原始 P5 主评测只跑了 plain_text + 5 篇 aiops-docs（总 ~50 chunks），离生产语料还有 (a) 解析路径、(b) 体量、(c) 文档结构 三个维度的差距。本步只做验证，不动 P5 实现层。

### 决策定在哪里（跑前固定，不允许跑后调）

按你的拍板顺序写死了 6 条：

- **A1→A2→A3 路径**：先复用现成 MinerU artifact，没有再现解析 PDF，再没有就回合成 plain text proxy。
- **B3 阈值**：长文档定义为同时满足 ≥30 children + ≥20K Qwen tokens。chunks 维度兜结构、tokens 维度兜成本，单维度都不够。
- **C 18 条 / 3 类**：与 P5 主评测可比。
- **D1 单 factor 跑**：默认 `factor=4` 跑一次，用 pool 信号判定够不够；只有触发"不够"才单开 P5.f4 网格。
- **E3 token 双阈值**：DL `tokens_avg ≤ 4000` AND `DL/NONE ≤ 2.0`，绝对值兜上下文上限，相对值兜膨胀。
- **F3 旧阈值不变 + 新阈值用新维度**：F3 区分度自检沿用 70 / 70 / 10；长文档新风险用 D1 + E3 表达，**不放宽 F3**。

### 实际走的路径与发现

**A1 探查**意外发现仓库 `pdf_eval/outputs/postprocessed/mineru/expanded_corpus/` 里 5 月 13 日的批处理 (`run_expanded_corpus_batch.py`) 已经把 15 篇 PDF 全部解析过，4 篇目标 PDF 全在位。原本以为要花 30+ min 跑 MinerU CLI，实际 0 成本。

**B3 验证**暴露第 1 个偏差：你给的 4 篇组合里 `arxiv_attention_is_all_you_need` token 只 10503，距 20K 差 48%。仓库内没有第二篇过 B3 的 arxiv 论文。按 F3 不放宽阈值，唯一选择是降到 3 篇（2 cn manuals + 1 en paper），承认语言平衡偏移。

**Probe-1 暴露第 2 个结构性问题**：15 条候选 query 里仅 2 条满足 `same_doc_redundant` 的"NONE distinct=1 且 pool ≥ 2"模式，离 6 条需求差 4 条。dense recall 在 3-doc 长文档语料上的 base rate 极低（~13%）。这和 P5 round-1/2 cross_doc_already 信号不足同形态。

按你定的 stop-loss 走 1（再跑一轮 probe，专门构造"NONE=1 且 pool=2"模式 query）；失败转 4（承认语料边界）；2 / 3 都禁掉。

**Probe-2 单轮成功**：13 条新 query 拿到 5 条新 same_doc_redundant 候选 + 4 条 cross_doc_already 候选；总池 7 + 8 + 9 满足 6/6/6 设计需求。

**Sample 设计的关键纪律**：keyword probe 验证显示 16/18 条提议 keywords 在 NONE@top-3 命中文本里有词缺失（凭语义直觉选词的常见陷阱，与 P5 round-1/2 同病根）。`_p5_long_doc_hit_dump.py` dump NONE@top-3 命中文本前 500 字，再逐条挑实际出现的词，recheck 17/18 通过 → 替最后 1 条（cross_002）→ 18/18 通过。整个 keyword 调整不动 query / 不动归类，只调辅助观察字段，不违反 sample 单轮 stop-loss。

### 第三轮 eval 结果（B-1 单轮过线）

报告路径：`evals/rag_retrieval/reports/p5_long_doc_eval_20260518_224445.{json,md}`。

4 项门槛全过：

| 门槛 | 阈值 | 结果 | 通过 |
|---|---|---|---|
| §4 不变性 | 4 条断言 × 18 样本 | all OK | PASS |
| F3 same_doc_redundant | ≥ 70% distinct(DL) > NONE | 6/6 (100%) | PASS |
| F3 cross_doc_already | ≥ 70% distinct(DL) == NONE | 6/6 (100%) | PASS |
| F3 reverse_control | top1_match 退化率 ≤ 10% | 0/6 (0%) | PASS |
| D1 factor=4 enough | < 30% same 样本 saturate | 0/6 (0%) | factor_enough=true |
| E3 token absolute | DL tokens_avg ≤ 4000 | 640 | PASS |
| E3 token relative | DL/NONE ≤ 2.0 | 0.54 | PASS |

策略对比（Qwen tokenizer / qwen-max）：

| 策略 | tokens_avg | distinct_doc_count_avg | top1_match_avg |
|---|---|---|---|
| NONE | 1178 | 1.39 | 1.00 |
| DOC_LEVEL | 640 | 2.50 | 0.94 |

DOC_LEVEL 在长文档语料上：distinct doc 1.39 → 2.50（+80%），token 1178 → 640（-46%），top1_match 退化 0.06 但 reverse_control 0/6 退化（即 NONE 命中而 DL 不命中的样本 0 例）。

### 不回归证据

- `unittest discover tests`: **101/101 pass** (Step 2 没动 app/* 代码)
- 报告 §4 不变性 18/18 通过
- F3 阈值与 P5 主评测同口径不变（6/6 + 6/6 + 0/6 全过）

### P5.f4 是否触发？

**不触发**。D1 saturation_ratio = 0/6 = 0.00，远低于 30% 触发阈值。`doc_oversample_factor=4` 在长文档语料上已足够；3 doc 候选池 (size=12) 总能换到第二个 doc。这条结论按你的执行口径写成"P5.f4 是后续工作，不在本轮内实现"——且现在不触发即不进入。

### 这一步如果在面试场景被问到

1. **为什么 A1 这么走运直接命中现成 artifact？这是 luck 还是工程纪律？** 是工程纪律：A1 探查是按 stop-loss 顺序的第一步，目的就是"先看仓库里有没有现成产物"，不是"赌一把试试"。能命中是因为 `pdf_eval/outputs/postprocessed/mineru/expanded_corpus/` 这个路径在批处理脚本里就是约定俗成的产物落点，正确做 A1 探查（grep `manifest.json` / `chunks.json`）必然能找到。如果当时跳过 A1 直接跑 A2，就会浪费 30+ min CPU。
2. **P5.f1 一遍过，比 P5 主评测顺很多（主评测要 B-1 单轮调整），怎么解释？** 两点：(a) keyword 这一层提前用 `_p5_long_doc_hit_dump.py` 拿到真实命中文本再选词，避免 P5 round-1/2 凭语义直觉选词的覆辙；(b) sample 类别归类先用 probe 跑 NONE / pool 实际命中分布，按数据落类，而不是按"我觉得这条 query 应该是哪类"。Probe-1 + probe-2 + keyword probe + hit dump + recheck 这一串 probe 加起来 ~3 hr，把"评测前能犯的错"全部前移到不进 sample 的纯探查阶段。
3. **D1 factor=4 enough 凭什么不需要再跑 8 / 16 网格？** D1 用的是 saturation 信号 (`pool top_doc_hit_share == 1.0`)：候选池 12 条全在一个 doc 时，dedup 没 doc 可换；这是 factor 不够的最直接证据。当前 0/6 saturate，意味着每条 same_doc_redundant 样本的 pool 至少有 2 个 doc 出现，dedup 总能换出去。用更松的指标（比如 top_doc_hit_share ≥ 0.8）也能判，但 1.0 是最严的二元判定，能简化结论。如果业务上 want 更高 doc 多样性，那是另一个目标，不是 D1 的判定范围。
4. **E3 token 比预期低很多 (DL avg 640 vs 4000 阈值)，为什么这么宽松？** DOC_LEVEL 在 same_doc_redundant 类上反而比 NONE 更省 token (640 vs 1178)，原因是 dedup 把"同 doc 多 chunk 拥挤"压缩成"3 个不同 doc 各 1 chunk"。token 阈值 4000 是按 P4.5 评测里 `full_doc` 模式 6715 tokens 设的上限——给 P5.f2 (`DOC_LEVEL × full_doc`) 留 token 预算，不是按 `DOC_LEVEL × chunk` 当前用量定的。所以这个阈值现在看宽松，到 P5.f2 才真正会被压。
5. **3 篇语料够不够代表"MinerU 长文档"？** 不够。这就是为什么 PROJECT_STATE 里把"same_doc_redundant 5/6 集中在 mc101"这条专门标成"corpus property, must not be extrapolated"。3 篇是 P5.f1 在 stop-loss 范围内能拿到的数据，结论只能写"在这 3 篇上 dedup 稳定 + token 不爆 + factor=4 够用"，不能直接外推。真要外推需要扩到 10+ 篇 + 多领域，那是 P5.f2 / 后续工作。

---

## 2026-05-19 P5.f2 P4.5 + P5 联合验证（complete with caveats）

### 这一步在做什么 / 为什么现在做

P5.f1 收尾后，P6 前置门槛剩 4 项，最自然的下一步是 P5.f2：把 dedup 与 P4.5 三 granularity 放到一起跑，看两者会不会互相放大 token 浪费。这一步是验证-only，不动 P5 / P4.5 实现。

### 决策定在哪里（跑前固定，按用户拍板 7 条逐条执行）

- A1 sample 来源：复用 P5.f1 18 条样本，唯一变量是 granularity
- B  评测策略矩阵：6-cell 矩阵 `{NONE, DOC_LEVEL} × {chunk, parent_chunk, full_doc}`，且复现 P5.f1 NONE×chunk / DL×chunk 作 sanity
- C  分档 token 阈值：chunk DL≤4000 AND DL/NONE≤2.0、parent_chunk DL≤6000 AND DL/NONE≤2.0、full_doc 只 ratio≤1.5；**用户补的硬要求**：full_doc 绝对 token 在报告中显式高亮作软观察，但不进 pass/fail
- D1 fallback rate 只观测，不设门槛
- E1 joint_amplification 只观测，不设门槛
- F  §4 不变性扩到 6 条：原 1–4 + 新 5（同 chunk_id 跨 cells byte-equality） + 新 6（P4.5 ordered-list invariance 复测）
- G  P5.f1 D1 不复测（granularity 不影响候选池），只 restate

### 6-cell 核心数据

| cell | tokens_avg | distinct_avg | top1_match | fallback_rate |
|---|---|---|---|---|
| NONE × chunk | 1178 | 1.33 | 1.000 | 0.000 |
| NONE × parent_chunk | 1642 | 1.33 | 1.000 | 0.833 |
| NONE × full_doc | 83492 | 1.33 | 1.000 | 0.000 |
| DL × chunk | 640 | 1.67 | 1.000 | 0.000 |
| DL × parent_chunk | 744 | 1.67 | 1.000 | 0.833 |
| DL × full_doc | 46302 | 1.67 | 1.000 | 0.000 |

### 4 项硬门槛全过

- §4 不变性 6 条 × 18 样本：all OK（其中 §4(5)/(6) 是这次新加的）
- token 分档阈值：chunk PASS、parent_chunk PASS、full_doc ratio PASS
- P5.f1 sanity reproduction：NONE×chunk drift=0.000、DL×chunk drift=0.000
- D1 anchor restated（P5.f4 仍未触发）

### joint_amplification（核心问题答案）

定义：`joint_amplification(g) = (DL_avg(g)/DL_avg(chunk)) / (NONE_avg(g)/NONE_avg(chunk))`

| granularity | NONE g/chunk | DL g/chunk | joint_amplification |
|---|---|---|---|
| chunk | 1.000 | 1.000 | 1.000 (basis) |
| parent_chunk | 1.394 | 1.163 | **0.835** |
| full_doc | 70.853 | 72.371 | **1.021** |

结论：**dedup 与 P4.5 不互相放大 token 浪费**。parent_chunk 上 dedup 反而把膨胀压回去（0.835）；full_doc 上几乎完全独立（1.021）。这是 P5.f2 想回答的核心问题，答案明确。

### 两条 caveats（按用户 A1/B1 拍板，写进 PROJECT_STATE Open Problems）

**caveat (a)**: `DOC_LEVEL × full_doc` tokens_avg=46,302 / p95=57,901 / max=57,906。`config.rag_model = qwen-max` context window = 32,768 tokens。即使 dedup 把 full_doc 从 83K 压到 46K，**仍超 1.4×**。`NONE × full_doc` 更超 2.5×。模式结构上 pass-through（§4 6 条不变性都过，DTO 不污染），但**无法被当前 LLM 直接消费**。

按用户 E3 决策，full_doc 没有绝对 token pass/fail（DL/NONE ratio=0.55 满足"dedup 不放大"），所以**门槛上 PASS**；但绝对值告诉我们 full_doc 在长文档语料上事实不可用。这就是为什么用户特意补了"软观察"要求：报告里必须显式高亮 full_doc 绝对 token，不能藏在表里。

**caveat (b)**: parent_chunk 模式下 fallback rate 0.833（NONE 与 DOC_LEVEL 同），15/18 样本退回 chunk content。根因是 `ChunkPolicyService.apply_with_parents` 的 parent 生成阈值（连续 ≥ 2 个同 heading 文本子块）在 3 篇长文档语料上产 parent 极少：

| doc | children | parents | 比例 |
|---|---|---|---|
| h3c_mc101 | 155 | 1 | 0.6% |
| h3c_campus | 132 | 2 | 1.5% |
| arxiv_vit | 62 | 12 | 19.4% |

只有 arxiv_vit 一篇 parent 比例正常（学术论文章节结构清晰）。P5 / DOC_LEVEL / P4.5 retrieval 机制都正常工作，**瓶颈在 parent 生成阶段的稀疏度**。修这条要重新设计 `ChunkPolicyService` parent 阈值，明确不在 P5 / P5.f1 / P5.f2 / P5.f3 范围内。

### 状态写法：complete with caveats

- 主目标已答（dedup vs expansion 互相放大 = no），4 项硬门槛单轮全过 → 不能写 "in_progress" 或 "blocked"
- 但 full_doc 在长文档不可用、parent_chunk 在长文档高 fallback 都是模式有效性边界 → 不能写纯 "complete" 而藏起来
- 折中：`complete with caveats`，硬门槛过 + 两条 caveats 显式挂在 Open Problems

### 不回归证据

- `unittest discover tests`: 101/101 仍持平（Step 2 P5.f2 没动 app/* 代码）
- §4 6 条不变性 18/18 全过（其中新加的第 5 / 6 条是这次最硬的边界证明）
- P5.f1 sanity reproduction drift=0.000（说明 P5.f2 插桩没干扰 P5.f1 已验证 cell）

### 这一步如果在面试场景被问到

1. **为什么 §4 不变性要从 4 条扩到 6 条？** P5 主评测的 4 条断言只覆盖单一 granularity（dedup 在 chunk 模式下不破坏 citation）。一旦把 granularity 与 dedup 联合跑，就要兜两个新维度：(5) granularity 是否真的只动 context_text 不动 identity 字段（这是 P4.5 §1.2 的核心承诺，P5.f2 第一次在长文档上跨 6 cells 实测）；(6) P4.5 §4 ordered-list invariance 在长文档上是不是仍然成立（P4.5 主评测在 5 aiops-docs 上证过，长文档上没证过）。这两条加起来一次性兜住了 P4.5 / P5 在 6-way 矩阵下的 identity 边界。
2. **joint_amplification(parent_chunk)=0.835 < 1，是不是 dedup 真的"省 token"？意外吗？** 不意外。机制是：parent_chunk 模式下，每条 hit 的 context body 是它所属 parent 的全文（可能 800–1600 字符）。NONE × parent_chunk 因为 P4.5 设计 §3 的"同 parent 多 child 重复拉"硬口径，会把同一个 parent 拼多次；而 DOC_LEVEL 把 same-parent 多 hit dedup 掉了（每 doc 一条），相当于顺带消除了 parent 重复。所以 parent_chunk 模式下 dedup 的省 token 收益**比 chunk 模式更大**，joint_amplification < 1 是结构性结果。
3. **full_doc DL avg 46K 怎么处理？为什么不在 P5.f2 里直接禁掉这个模式？** 因为 P4.5 / P5 的设计原则是"granularity 与 dedup 都是用户显式 opt-in"，P5.f2 是评测，不是修实现。评测能做的是把"长文档 + full_doc 不可用"这个事实显式写进 Open Problems，让后续 P5.f3 / P6 / 生产配置都能看到。修法有三种（升级 LLM context、partition corpus、加 P4.5 长文档 truncation policy），都不在 P5 范围内。
4. **3 个软观察（fallback / joint amp / full_doc 绝对值）为什么都不进 pass/fail？** 因为 P5.f2 是这条线上第一次跑 6-way 矩阵评测，没有先验数据建阈值。提前定阈值会有两种风险：(a) 阈值太松，评测过线但漏掉真问题；(b) 阈值太严，把"corpus 性质"误当成"P5 bug"，触发不该触发的修复。所以这一轮先观测 + 把不寻常的数字显式高亮，等 P5.f3 / 后续工作有更多数据再决定要不要 lock 成阈值。这也是为什么用户特意在 C 里补了"full_doc 绝对值要软观察"——防止 ratio 通过就把绝对成本忽略掉。
5. **为什么全程没动 P5 / P4.5 实现？这种"硬不动实现"原则会不会过头？** 不过头。P5 / P5.f1 / P5.f2 三阶段都在做的事是"扩验证范围"，每次扩范围都在不动实现的前提下检查既有契约还成立不。如果中间任何一步破了 §4，那就是 P5 实现 bug，必须停下来汇报让用户决定是否 patch。这种纪律的核心是把"扩范围"和"修实现"显式分开，避免因为 sample / corpus / mode 扩到新区域就顺手改实现，从而污染已经验证过的边界。

---

## 2026-05-19 P5.f3 LLM 端 citation 漂移验证

### 这一步在做什么 / 为什么现在做

P5.f1 / P5.f2 把 retrieval / context 侧在长文档 + 6-way granularity × dedup 矩阵上证完了，但仍然没有"接真 LLM"的证据：P4.5 / P5 / P5.f1 / P5.f2 全部都用 deterministic `signal_density` proxy 度量。P5.f3 是 P6 前置门槛 5 项的第 3 项，目的就是补上"主链路最后一公里"——retrieval `context_text` 喂给 LLM 后，回答里引用的 chunk_id 是否还指向 retrieval 真正给的位置。

设计原则继承 P5.f1 / P5.f2 的"validation-only"：不动 `app/*`、不动 `tests/*`、不重写 prompt、不调阈值；唯一新维度是 LLM call。

### 决策定在哪里（跑前固定，不允许跑后调）

设计文档 `docs/p5_f3_llm_citation_drift_design.md` 把所有边界写死了：

- **3-cell 主矩阵**：`NONE×chunk` / `DOC_LEVEL×chunk` / `DOC_LEVEL×parent_chunk`，共 18 × 3 = 54 次 LLM 调用。
- **`full_doc` 显式 out-of-scope**：P5.f2 caveat (a) 已证 DL × full_doc tokens_avg = 46K 超 qwen-max 32K context；评测层不因为接了 LLM 就把 `full_doc` 偷偷带回主矩阵。
- **`NONE × parent_chunk` 排除**：P5.f2 caveat (b) 显示 fallback rate 0.833，15/18 sample 实际 context 等同于 `NONE × chunk`，信号高度重叠只增加调用数与解释噪音。
- **proxy 限制写进报告 markdown header**：LLM 指标只衡量 prompt 与 answer 之间 chunk_id 是否对齐，不衡量"LLM 答得对不对"；事实级 citation correctness 需要 human / LLM-as-judge，**out-of-scope here**。
- **prompt 简单化**：4 行规则 + reference + query，不加"必须每句引用"等强化约束（避免人为压低 hallucination_rate，掩盖真实漂移）。
- **LLM 配置**：`qwen-max`、temperature=0.0、max_tokens=1024、timeout=30s、retry=2、串行调用。
- **硬断言只有一条**：retrieval §4 不变性 6 条（与 P5.f2 完全一致），任一失败立即停。
- **所有 LLM 指标都是软观察**：hallucination_rate / coverage_rate / citation_jaccard / empty_answer_rate / no_citation_rate 全部不设 pass/fail（设计 §5.1）——P5.f3 是这条线上第一次有 LLM 数据，提前定阈值要么太松漏问题、要么太严把 corpus 性质误判成 bug。
- **stop-loss 三条**：§4 不变性失败 → 停；LLM 调用失败 ≥ 50% → 停；任何 P5 / P4.5 实现层问题 → 停。

### 实现切片

- 新增 `evals/rag_retrieval/_p5_llm_smoke.py`：1-call 前置自检（DashScope key、ChatOpenAI compat、prompt 渲染、citation regex、retry/timeout），不索引 corpus。
- 新增 `evals/rag_retrieval/run_p5_llm_eval.py`：corpus indexing + isolated Milvus + metadata store 框架沿用 P5.f1 / P5.f2；新增 LLM call layer、citation parser（regex `\[chunk:\s*([^\]]+?)\s*\]`，严格 string equality 不做 fuzzy match）、3-cell × 5 软观察聚合表、per-sample 明细、corner case 高亮（hallucinated samples / coverage<0.5 cells / empty>0.2 cells）、abort-on-≥50%-failure。

### 实际执行结果

**Smoke**（1 次调用）：DashScope 接通、prompt 475 字符、回答正确引用 retrieval 内 chunk_id (`smoke:c00001`)、no outside-retrieval citation、no_citation_rate=0。

**Main run**（2026-05-19, 54 calls）：

- §4 不变性 6 条 × 18 样本 × 3 cells：`invariants_all_ok = true`。
- LLM 调用：54/54 succeeded，`abort_should_trigger = false`。
- 软观察主表：

| cell | hall | cov | jaccard | empty | no_cit | fallback |
|---|---|---|---|---|---|---|
| `none__chunk` | 0.056 | 0.889 | 0.509 | 0.111 | 0.000 | 0.000 |
| `doc_level__chunk` | 0.000 | 0.833 | 0.694 | 0.167 | 0.000 | 0.000 |
| `doc_level__parent_chunk` | 0.000 | 0.833 | 0.722 | 0.167 | 0.000 | 0.833 |

- 唯一 hallucinated sample：`p5_long_reverse_004` 在 `NONE×chunk` 引用 malformed doc-id `doc_p5_long_arxiv_transformer`（真名 `doc_p5_long_arxiv_vision_transformer`），DOC_LEVEL 两 cell 都把它压到 0。
- §9.3 三类 corner case（coverage<0.5 / empty>0.2 / no_citation>0）均未触发。
- 报告：`evals/rag_retrieval/reports/p5_llm_eval_20260519_131538.{json,md}`，markdown header 显式列出 §5.5 proxy 限制与 §4 范围限制。

### 怎么读这组数

- **DOC_LEVEL 把 hallucination 从基线 0.056 压到 0.000**：唯一 hallucinated sample 是 `reverse_control` 类（设计就是要让模型容易答错的"反向控制"问题），它在 `NONE×chunk` 下因为 retrieval 给了 ViT 论文 chunk 让 LLM 在 doc-id 上写漏字，DOC_LEVEL 通过 dedup 让 retrieval 集合更紧凑，模型反而不漂。**P5 doc-level dedup 是 LLM citation 对齐这一维度上的净正向**。
- **DOC_LEVEL 的 coverage 略降 0.056（0.889 → 0.833）**：DL 把 `cross_doc_already` 类的 retrieval 集合压窄了，少数 sample 在严格集合相等比对下变成"LLM 答了但没 mention 那一条"。这是 dedup 带来的副作用，不是 bug；jaccard 从 0.509 升到 0.694 / 0.722 同时印证 retrieval-LLM 集合相似度更高。
- **`empty_answer_rate` 在两个 DOC_LEVEL cell 都是 0.167**：3/18 sample 的 LLM 答了"参考资料中未找到相关信息"，主要集中在 `cross_doc_already` 类（cross_002 / cross_003 / reverse_002）。这是 prompt 协议层的预期分支（"找不到答案直接说"），不是 drift；报告里被显式标 `empty_answer = True` 但没 trigger >0.2 高亮门槛。
- **`fallback_rate_avg = 0.833` 在 `doc_level__parent_chunk` cell**：与 P5.f2 caveat (b) 完全一致，证明这条边界在 P5.f3 引入 LLM call 后仍然 0 漂移，是 corpus / ChunkPolicy 性质而非 P5 实现 bug。

### 状态写法：complete（不是 with caveats）

- 硬断言全过、54/54 调用成功、3 类 corner case 均未触发。
- 唯一异常 sample 出现在基线 cell 且被 DOC_LEVEL 修复，是正向佐证。
- P5.f2 的两条 caveats（full_doc out-of-scope、parent_chunk 0.833 fallback）在 P5.f3 仍然有效，但这是**复测一致**而不是 P5.f3 新增 caveat。
- 因此 P5.f3 状态 = `complete`，不需要 with caveats；P5.f2 caveats 仍单独挂在 `PROJECT_STATE.md` Open Problems 上。

### P6 trigger 判定：仍 false / gated

P5.f3 是 **citation drift 评测**，不是 **domain-filter 评测**。设计天然不产生 P6 启动证据三要素（path/folder/domain 过滤需求 / `kb_id` 不足 / domain metadata 显著改善）。P5.f3 完成只勾掉了 P6 前置门槛 5 项中的第 3 项；要开 P6 thread 仍需要换一套显式有 path/folder/domain 过滤痛点的语料 + 样本集，**不是再做一次 P5 线 follow-up**。

### 不回归证据

- `unittest discover tests`: 101/101（P5.f3 没动 `app/*` / `tests/*`）。
- retrieval §4 6 条不变性: 18/18 全过。
- 54 LLM calls 0 失败。
- P5.f1 / P5.f2 报告未动；既有 cell 在 P5.f3 跑里复测一致。

### 这一步如果在面试场景被问到

1. **为什么 P5.f3 不设 LLM 指标的 pass/fail？这不是评测吗？** 这条线第一次接 LLM 之前没有任何先验数据。提前定阈值有两种典型错误：太松会让"过线但实际有漂移"的结果蒙混过关；太严会把 corpus 性质（比如长文档语义偏移）误判成 P5 / LLM bug，触发不该做的修。所以 P5.f3 的策略是：硬断言只放在 retrieval 不变性这条已经验证过的边界，LLM 指标全部先观测。报告里把"该高亮的 corner case"都写明（hallucinated samples 列出 outside-retrieval ID、coverage<0.5 cells 高亮、empty>0.2 cells 高亮），但不擅自 fail。等 P5.f3 数据本身成为后续阶段建阈值的依据。

2. **唯一 1 个 hallucinated sample 是不是说明 LLM 不靠谱？为什么不 fail？** 看具体场景：(a) 这 1 个 sample 的"幻觉"是把 doc-id 写漏字（`arxiv_transformer` 漏写 `vision_`），不是引用了完全不存在的 chunk_id；(b) 它出现在 `reverse_control` 类，这一类设计就是用反向 query 试图诱导模型出错的；(c) 同 sample 在两个 DOC_LEVEL cell 都没漂。这 3 条加起来证明：基线模式下 LLM 在反向 query 上偶尔会在 doc-id 拼写上犯错，但 P5 dedup 直接修复了它。这是正向信号，不是问题。

3. **proxy 限制是不是把所有结论都打了折扣？那评测意义在哪？** Proxy 限制只说一件事："本评测不能证明 LLM 答得事实正确"。但它能证明的事仍然有价值：(a) retrieval 不变性（硬断言）证 LLM call 没污染 retrieval 路径；(b) hallucination_rate=0.056 → 0.000 证 P5 dedup 在 LLM 端有正向影响；(c) coverage_rate≥0.83 证 LLM 至少 80% sample 在用 retrieval 回答而不是 parametric。如果未来要跨过 proxy 上 LLM-as-judge / 人工评测，那是 P5.f3 之外的独立工作（设计 §15 已写明），不在这一轮范围。

4. **为什么 prompt 简单到只有 4 行？不该用 prompt engineering 把指标拉高吗？** 不该。P5.f3 测的是"chunk_id 标识符是否对齐"，prompt 里加"必须每句引用"会把 LLM 推向 over-citation（更高 coverage、更低 hallucination），人为拉漂亮指标但掩盖真实漂移。这条线和"prompt engineering 提升回答质量"是两个不同 goal；评测要测的是 baseline 行为，不是把每个能调的旋钮都拧到最优。设计 §15"不允许 prompt 里加强化约束"就是这个用意。

5. **既然 P5.f3 完成了 P6 前置 5 项中的第 3 项，为什么 P6 还是 gated？** 因为 P6 trigger 判定（第 5 项）需要的是 domain-filter 类证据，不是 citation-drift 类证据。P5.f3 评的是"现有 retrieval/context 给 LLM 后稳不稳"，跟"是否需要 path/folder/domain 过滤"是两个独立问题。即便 P5.f3 全部数据完美，如果 P5 / P5.f1 / P5.f2 / P5.f3 评测里没出现"如果有 domain metadata 会明显更好"的稳定案例（实际就是没出现），那 P6 trigger evidence 仍然 false。开 P6 必须先把语料换成显式有领域过滤痛点的，不是把 P5 线再做一遍。

---

## 2026-05-19 ChunkPolicy 原子类型 hardcap fix（A→B 路径迭代）

### 这一步在做什么 / 为什么现在做

P5.f3 收尾后开 P6 前置门槛第 4 项 corpus prep，authored `_p6_corpus_probe.py` 第一次跑在 `h3c_comware_v7_high_risk_command_reference_cn` 上挂 ingestion: `MilvusException(code=1100, varchar field content exceeds max 8000, length=21236)`。根因是 ChunkPolicy `_resplit_pass` 按 P2 设计**只**对 `TEXT_CONTENT_TYPES = {"text", "markdown_section"}` 触发再拆，原子类型（manual_table / command_table / equation_interline）全部绕过 merge / resplit；P5.fX 三套 corpus 单 chunk 最大 1,613 字符，从未暴露此边界，P6 加入 17 文档 + 命令参考类长 chunks.json 才首次撞上。这是 P5.f1 Open Problem "large-corpus headroom 未验证" 的具体爆发。

按"修根因不绕路"决策（D 路径），不删文档不改 probe 截断，回 ChunkPolicy 加一道原子类型 hardcap pass。

### 决策定在哪里（跑前固定，不允许跑后调）

设计文档 `docs/chunk_policy_atomic_hardcap_design.md`：

- **位置**：在 `_resplit_pass` 之后、`_finalize` 之前插入 `_atomic_hardcap_pass`；原子类型超 hardcap 走切分，content_type / heading / pages / metadata 全继承，quality_flags 加入 `atomic_split_by_size`。
- **A 路径阈值（第一轮）**：char-based `ATOMIC_HARD_CAP_DEFAULT = 4000`，与 P5.f2 chunk DL ≤ 4000 token 阈值"对齐"，Milvus varchar(8000) 留 2× safety margin。
- **回归清单 §4**：step 2 retrieval_eval / step 3 p4_5_eval / step 4 p5_eval / step 5 p5_long_doc_eval / step 6 p5_joint_eval / step 7 p5_llm_eval 6 步串行，retrieval byte-level drift=0 是必过门槛；LLM-side 软观察按 P5.f3 §5.1 不设 pass/fail。
- **不允许的事**：阈值不允许跑后调；不允许跳过 step 6/7 直接开 P6 corpus probe；A 路径过了不代表 close-out（必须同时验所有依赖 corpus）。

## 2026-05-20 P6 trigger eval 与 §10(b) 最终决策

### 这一步在做什么 / 为什么现在做

P5.f3 完成后，P6 前置门槛只剩最后一项：判断当前项目到底需不需要 `domain_metadata` 这一条实现线。这里必须先区分两件事：

1. **评测能证明什么**
2. **产品/架构应该选什么方案**

评测可以证明“域级过滤需求是否存在”，但不能自动替我们在“拆 `kb_id`”和“加 `domain_metadata`”之间做架构选择。所以这一段的目标不是直接开做 P6，而是把 `trigger_p6` 和 `§10(b)` 分开跑清楚。

### P6 trigger eval 真正做了什么

这轮冻结了 4 域语料：

- `contracts`
- `manuals`
- `papers`
- `aiops-docs`

并跑了两层探查：

1. `_p6_corpus_probe.py`
2. `_p6_cross_pool_probe.py`

目的是回答：

- 单域查询是否已经被 dense retrieval 做到足够干净
- 跨域查询里，`oracle domain filter` 是否能显著改善 `precision@3`

最终正式报告是：

- `evals/rag_retrieval/reports/p6_trigger_eval_20260520_152021.json`
- `evals/rag_retrieval/reports/p6_trigger_eval_20260520_152021.md`

### 跑出来的关键事实

最重要的结论不是“P6 一定要做”，而是：

```text
trigger_p6 = true
但 qualifying lift 全部集中在 aiops-docs ↔ manuals 这一对域
```

也就是说，评测证明了：

- **确实存在域级过滤需求**
- 但**还没有证明必须靠 `domain_metadata` 才能解决**

因为同一份数据也支持另一种更简单的解释：

```text
aiops-docs 和 manuals 本来就不该放在同一个 KB
```

所以这一步的真正 gap 是：

```text
§10(a) 和 §10(c) 被操作化并验证了
§10(b) “kb_id 不足以表达业务边界” 没被评测自动证明
```

### 为什么最后拍板是“P6 永久关闭”

最终 stakeholder 决策是：

```text
§10(b) = False
```

也就是：

- `aiops-docs`
- `manuals`

拆成两个 `kb_id`，而不是留在同一知识库里再靠 `domain_metadata` 细分。

这个决策的核心理由有 3 条：

1. `trigger_p6=True` 只证明“需要某种域级过滤”，没证明“必须是 metadata enricher”。
2. `kb_id` 拆分是更简单的实现面。
3. 从产品语义上看，`aiops` 与 `manuals` 本来就是两类不同知识，拆开更自然。

所以最后收口不是“P6 等以后再做”，而是：

```text
P6 permanently closed
```

### 这一步具体改了什么

这一步没有改 `app/*` 业务实现，而是完成了 5 类落档：

- `docs/p6_corpus_prep_design.md`
- `PROJECT_STATE.md`
- `task_plan.md`
- `findings.md`
- `docs/chunk_refactor_execution_plan.md`

其中最关键的是在设计文档里新增：

- `§15.1` 最终决策
- `§15.2` 永久关闭范围
- `§15.3` 重启条件
- `§15.4` follow-up

也就是把“为什么不做 P6”“什么时候才允许以后重开”都写死了。

### 这一步如果在面试或复盘里怎么讲

可以讲成：

> 我们没有把 trigger eval 的正结果机械地翻译成“立即上 P6”，而是继续追问：这个 lift 到底是在要求 `domain_metadata`，还是在暴露 KB 边界划分错误。最后发现 qualifying lift 全部集中在 aiops-docs 和 manuals 这一对域上，所以更自然的方案是拆 `kb_id`，而不是给整个系统再引一个 domain enricher 复杂度。这个判断其实是在保护系统复杂度，把评测发现和最终实现方案显式分开。

---

## 2026-05-20 C1：把 §10(b) 从文档决策变成代码约束

### 这一步为什么必须做

P6 关闭以后又回头检查了一次代码，发现一个很关键的问题：

```text
文档里已经决定 aiops 和 manuals 要拆 KB
但代码默认还在往 kb_id="default" 里灌
```

也就是说，之前只是“文档闭”，不是“代码闭”。

如果继续保持这种状态，后面任何新 ingest 仍然可能把两类知识放回同一个 KB，等于用代码把已决策的边界悄悄推翻。

所以 C1 的目标很明确：

```text
让 §10(b) 决策在代码里 fail-fast enforce
同时把 tool surface 接通 knowledge_base_ids
```

### 设计 pivot：为什么没上 kb_id_router

最开始有一个更抽象的方案：做一个 `kb_id_router`，按 path 自动分发到不同 KB。

最后否掉它，原因有 3 条：

1. 这是二元边界，不需要额外 router 抽象。
2. production 调用方其实知道自己要写进哪个 KB，最自然的边界就在 API 参数上。
3. eval 脚本仍然需要保留 isolated `default` 习惯，router 会把这个 distinction 藏起来。

最后改成“双层 required”：

- API boundary：必须传 `kb_id`
- service boundary：必须传 `kb_id`

唯一允许看到 production 默认值的地方是：

- 没有

也就是 production 不再有默认值。

### 实际改动

#### 1. API

在 [app/api/file.py](/Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/api/file.py)：

- `/upload` 增加 `kb_id: str = Form(...)`
- 空白字符串显式验证

#### 2. Service

在 [app/services/document_ingestion_service.py](/Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/services/document_ingestion_service.py)：

- 去掉 `default_kb_id`
- `ingest_upload(..., kb_id)` 改成 required positional
- `None` / 空白值直接抛 `ValueError`

#### 3. Tool

在 [app/tools/knowledge_tool.py](/Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21/app/tools/knowledge_tool.py)：

- `retrieve_knowledge(query, knowledge_base_ids=None)`
- 真正把 KB 过滤能力接到 tool surface

### TDD 与回归

这一步先写了 `tests/test_c1_kb_id_required.py` 共 9 个 case：

- service boundary 4
- API boundary 3
- tool surface 2

然后再改实现。

中间踩了一个小坑：

- 第一次直接 Edit `knowledge_tool.py`
- 没先 Read
- 改动实际没生效
- 导致 8/9 fail 一直定位不到

最后回头先 Read 再改才转绿。

这条经验后来也补进了 `findings.md`：

```text
Edit 前必须 Read
不要忽略工具返回的异常提示
```

### 为什么这一步是真闭合

因为现在 `§10(b)` 不再只是：

```text
PROJECT_STATE 里的 positive guidance
```

而是：

```text
API 不传 kb_id 就拒绝
Service 不传 kb_id 就拒绝
Tool 真的能按 kb 过滤
```

这才是“政策进代码”。

### 这一步如果在面试或复盘里怎么讲

可以讲成：

> P6 最后虽然关闭了，但我又做了一步 C1，把“aiops 和 manuals 要拆 KB”这条产品边界从文档决定推进到代码 enforce。否则这个决策只活在文档里，任何新 ingest 仍然会默认写进同一个 default KB，等于系统表面上做了架构收口，实际上还是随时会回退。我最后选择的是最小 wiring：要求 API 和 service 都显式传 kb_id，同时让 tool 支持 knowledge_base_ids 过滤，而不是再引一层 path router 抽象。

---

## 2026-05-21 S1 / S2 落地与 S3 defer

### S1：WeKnora IR metrics 港口

这一步不是为了“凑一个移植清单”，而是因为现有多个 eval 脚本都在各写各的指标，复用性很差。

真正落地的是：

- `app/services/retrieval_metrics.py`
- 5 个纯函数
- 37 个测试
- `NOTICE` 里的 MIT 归属

其中一个很关键的审计结论是：

```text
S1a 可以做
S1b 不能直接替换现有 7 个 eval 脚本
```

原因是项目里的旧脚本不只是 textbook IR，还混了领域语义：

- 布尔 `hit_at_k`
- `exact_source_ref_match`

这些不是 WeKnora 那套纯 IR 指标能无损表达的。

所以最后的决策是：

```text
模块落地
现有 7 个脚本不强接线
新脚本再逐步用
```

### S2：per-embedder token cap

S2 补的是另一条之前没完全封住的边界：

- hardcap 修了 Milvus schema
- 但 embedder 自己也有 token 上限

所以又落了一层：

- `app/services/token_estimator.py`
- `vector_embedding_service.py` 里的 `_truncate_for_embedder`

它的定位不是替代 chunking，而是：

```text
防御性边界
```

比如：

- 病理 query
- 新内容路径
- 上游 chunking 回归

都不应该直接把 embedding API 打挂。

### S3：为什么明确 defer

S3 的问题不是“做不了”，而是“现在没有证据表明值得冒这个回归面”。

因为启发式 chunking 一旦接进来，会直接改 chunk 边界，影响：

- P1-P5
- P5.f1/f2/f3
- hardcap

这一整串已经验证过的行为。

而当前并没有一个明确的失败模式证明：

```text
现有 chunker 的问题必须靠 S3 才能解
```

所以 S3 最后的状态不是 pending，而是：

```text
deferred with restart conditions
```

这比模糊地挂在 backlog 里更诚实。

---

## 2026-05-21 release 最终收口说明

### 为什么还要补这一段

到 S1 / S2 做完、S3 明确 defer 之后，功能面其实已经全闭了。

但如果只停在“代码和测试都过了”，后面接手的人仍然会问：

1. 这个 release 到底是不是已经 fully closed？
2. 为什么有状态文档、有 NOTICE、有 197/197 tests，却没有 git baseline commit？

这两个问题都不是业务代码问题，但它们是交付边界问题，所以要单独写。

### 最终闭项范围

这次 release 真正闭掉的是：

- `P1-P5`
- `P5.f1 / P5.f2 / P5.f3`
- atomic hardcap
- DashScope retry
- `P6 trigger eval`
- `§10(b)` stakeholder 决策
- `C1` code enforcement
- `S1`
- `S2`
- `S3 deferred`

### 为什么这次不打 git baseline commit

本地 `git root` 实际在：

```text
/Users/cici/oncall agent
```

而不是当前 release 目录。

父目录下还挂着：

- `WeKnora/`
- `pdf_eval/`
- `super_biz_agent_py-release-2026-05-17/`
- `实验 pdf/`
- `项目源码/`

这意味着如果此时为了“收口更像样”强行打 commit，会有 3 个风险：

1. 把多个无关工作区一起卷进来
2. 把混合工作目录误包装成单 release 基线仓
3. 在没有仓库治理决策的情况下做不可逆动作

所以最后做的是：

```text
release fully closed
但不以 git baseline commit 作为必要动作
```

交付凭据改由以下几项承担：

- `197/197` 单测通过
- 状态文档全同步
- `NOTICE`
- 本开发记录

### 这一步如果在面试或复盘里怎么讲

可以讲成：

> 这次我把“功能闭项”和“仓库治理”拆开处理。功能上，P1-P5 主线、follow-up、hardcap、retry、P6 trigger 决策、C1、S1/S2 全部完成；但本地 git root 在父目录，下面还挂着 WeKnora、pdf_eval、另一个 release 和实验素材，所以我没有为了形式上的好看去强行打 baseline commit，而是把“不 commit 的原因”显式写进状态文档和开发记录里。这样做是在保护交付范围，不是逃避收口。

## 2026-05-21 教程同步更新

### 为什么这一步现在要做

release close-out 已经收口，但主教程还停在 2026-05-17 的 P3 口径。
现在项目里已经有了 `ChunkPolicyService`、`context_granularity` / `result_aggregation`、P6 永久关闭以及 S1/S2/S3 的最终状态，
如果教程不跟着更新，后续读者会继续拿旧边界理解当前代码。

### 本轮新增或更新的文件

- 更新 `docs/oncall_agent_rag_enhanced_tutorial.md`
- 更新 `docs/oncall_agent_rag_source_code_deep_dive.md`
- 更新 `progress.md`

### 教程这次补了什么

- 架构图里补上 `ChunkPolicyService` 这条最终 chunk 边界收口。
- `app/models/knowledge.py` 的教程描述补上 `ContextGranularity` 和 `ResultAggregation`。
- 代码路径表新增 `chunk_policy_service.py`。
- “功能不是堆砌”一节把 chunk policy / hardcap 和 context granularity / doc-level aggregation 串进主线。
- “当前边界”一节改成 2026-05-21 口径，明确写出 P6 永久关闭、WeKnora S1/S2 完成、S3 deferred。
- 末尾补一节当前版本阅读口径，告诉读者要连着看哪些边界文档。

### 风险和处理

风险是教程看起来“更完整”以后，反而把后来才出现的 follow-up 误写成主线默认行为。

处理方式是把新增内容分成两层:

1. 主教程仍然讲稳定主线。
2. 最新边界单独放在“当前边界”和“当前版本的阅读口径”里，明确标出 opt-in 和已关闭项。

这样既能让新读者跟上当前 release，也不会把 release 外的扩展误讲成默认架构。

### 验证方式

- 对照 `app/models/knowledge.py`、`app/services/chunk_policy_service.py`、`app/services/retrieval_service.py` 的当前字段和行为。
- 对照 `PROJECT_STATE.md` 的 release close-out 结论。
- 确认这次只改文档，没有动运行时代码。

### 面试里怎么讲

可以讲成:

> 我把项目教程从“P3 时代的工程讲解”同步到了当前 release 口径，但没有把后续的 opt-in 边界伪装成默认主线。教程现在一眼能看出 chunk 边界怎么收口、`context_granularity` / `result_aggregation` 为什么是显式扩展、P6 为什么被永久关闭，以及当前 release 的阅读顺序应该怎么看。

## 2026-05-21 knowledge 模型注释中文化

### 为什么这一步现在要做

`app/models/knowledge.py` 里已经有一批中文字段名和中文业务背景，但类注释、模块注释和 `Field(description=...)` 还混着英文。
这会让后续看模型定义的人在同一个文件里来回切换语言，也不利于把知识库领域模型当成当前项目的正式说明入口。

### 本轮改了什么

- 把模块顶层 docstring 改成中文。
- 把 `ContextGranularity`、`ResultAggregation`、`ArtifactManifest`、`RetrievalQuery`、`RetrievalResponse` 等类注释统一改成中文。
- 把 `Field(description=...)` 里的英文说明改成中文，保留字段名、枚举值和代码语义不变。

### 风险和处理

风险是只翻译注释时，容易把语义边界写歪，尤其是 `context_granularity` 和 `result_aggregation` 这种已经带阶段约束的字段。

处理方式是只改人类可读说明，不动任何字段名、默认值、枚举值和方法逻辑，保证运行行为不变。

### 验证方式

- 直接复查 `app/models/knowledge.py`，确认没有改动类结构或默认值。
- 确认这次改动只影响说明文字，不影响模型序列化和调用接口。

### 面试里怎么讲

可以讲成:

> 我先把知识库模型文件里的说明语言统一成中文，重点不是做“翻译”，而是让这个领域模型真正变成项目里可读、可维护的正式定义。改动只动注释和描述，不碰字段和行为，所以能降低阅读成本，又不会带来接口风险。

## 2026-05-21 plain_text 状态收敛

### 为什么这一步现在要做

`DocumentIngestionService._ingest_plain_text_document()` 以前会先把 plain text 文档写成 `parse_pending -> parsing -> parsed`，但这三个状态并没有对应独立的 parser 执行结果。
实际发生的工作只有“把文档交给 `vector_index_service.index_document_record()` 继续推进索引”，所以这段状态更像流程占位，不够真实。

### 本轮改了什么

- 修改 `app/services/document_ingestion_service.py`
- 删除 plain text 分支里手工写入的 `PARSING` 和 `PARSED`
- 保留 `PARSE_PENDING` 作为“已接入、等待索引推进”的真实可见状态
- 让 plain text 直接把 `parse_pending_record` 交给 `vector_index_service.index_document_record()`
- 返回 `knowledge_metadata_store` 里最后确认过的最新记录，而不是中间构造出来的伪完成态
- 同步更新 `docs/oncall_agent_rag_source_code_deep_dive.md` 里的 plain text 状态流描述

### 风险和处理

风险是把中间态删掉以后，plain text 的状态粒度会变粗。

处理方式是接受这个收敛，因为 plain text 本来就没有独立 parser 阶段；真正可确认的状态已经由索引服务负责推进到 `INDEX_PENDING / INDEXING / INDEXED`。
这样对外输出的状态更接近事实，也避免把“还没真正发生的解析完成”写成 `parsed`。

### 验证方式

- `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_parser_engine_router`
- `.venv/bin/python -m unittest tests.test_p2_8_gate`

### 面试里怎么讲

可以讲成:

> 我把 plain text 的状态流从“先写 parsing/parsed 再去索引”收敛成“只保留真正可确认的阶段”。因为 md/txt 没有独立 parser 过程，`parsed` 只是人为占位，不是真实完成态。收掉之后，状态更诚实，索引成功与否由 `vector_index_service` 统一落库，接口返回的就是最后确认过的状态。

## 2026-05-21 确认式状态证据

### 为什么这一步现在要做

plain text 的假 `parsed` 收掉之后，下一层风险就变成“状态虽然更少了，但状态为什么成立仍然说不清”。
如果各处继续直接写 `DocumentRecord.status`，后续排障只能看到 `indexed` / `index_failed`，却看不到是谁确认的、为什么能确认、依据是什么。

所以这一步没有改 `DocumentStatus` 枚举，也没有拆 external / internal 状态，而是选择最稳的兼容方案：保留现有枚举，在 `DocumentRecord` 上补状态证据字段，并把状态迁移收口到 metadata store helper。

### 本轮改了什么

- `app/models/knowledge.py`
  - `DocumentRecord` 新增 `status_detail`
  - `DocumentRecord` 新增 `status_source`
  - `DocumentRecord` 新增 `status_evidence`
  - `DocumentRecord` 新增 `status_confirmed_at`
- `app/services/knowledge_metadata_store.py`
  - 新增 `transition_document_status(...)`
  - 要求调用方必须传 `status_source` / `status_detail` / 非空 `status_evidence`
  - 原 `update_document_status(...)` 保留为兼容包装，不再作为主写入入口
- `app/services/document_ingestion_service.py`
  - upload / parse_pending / artifact prepare failure 改成确认式状态写入
- `app/services/mineru_parser_adapter.py`
  - `PARSING` / `PARSED` / `INDEX_PENDING` / `PARSE_FAILED` 全部改成确认式状态写入
- `app/services/vector_index_service.py`
  - `INDEX_PENDING` / `INDEXING` / `INDEXED` / `INDEX_FAILED` 全部改成确认式状态写入

### 关键代码取舍

没有选择拆 `external_status` / `internal_stage`，也没有引入生命周期事件日志。

原因是当前仓库已经有一条可工作的 `DocumentStatus` 消费链路，直接拆状态会扩大 API 和前端语义面；事件日志更真实，但对现在这个 repo 偏重。
这次只增强“当前状态的证据”，让旧消费者继续读 `status`，新排障者能读 `status_source` / `status_detail` / `status_evidence`。

### 验证方式

- `.venv/bin/python -m unittest tests.test_knowledge_metadata_store`
- `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_mineru_parser_adapter tests.test_artifact_chunk_builder_service tests.test_p2_8_gate tests.test_knowledge_metadata_store`

新增和加固的测试会验证状态与证据一起落库，包括：

- metadata store helper 写入后重新加载 JSON，证据仍存在
- upload 进入 `parse_pending` 时有 `DocumentIngestionService.ingest_upload` 来源和 parser evidence
- MinerU 进入 `index_pending` / `parse_failed` 时有 adapter 来源和 artifact/error evidence
- plain text / MinerU 索引完成和失败时有 vector index 来源、chunk/vector count 或错误类型 evidence

### 面试里怎么讲

可以讲成：

> 我没有继续补更多枚举状态，而是把状态体系改成“确认式状态”。也就是说，`indexed` 这个结果本身不够，系统还要记录是谁确认的、为什么能确认、依据是什么。实现上我保留了原来的 `DocumentStatus`，避免破坏 API；新增 `status_source/status_detail/status_evidence/status_confirmed_at`，并用 `KnowledgeMetadataStore.transition_document_status()` 统一写入。这样状态既兼容旧消费者，又能支撑排障和审计。

## 2026-05-22 RQ 异步文档处理落地

### 为什么这一步现在要做

上一轮已经把 plain text 的假 `parsed` 收掉，并把文档状态写入改成“确认式状态”。
但 MinerU 文档上传后仍只是停在 `parse_pending`，后续需要手动调用 `process_deferred_document(doc_id)` 才会继续解析。

这会让“延迟处理”和“异步处理”混在一起:

```text
upload -> parse_pending
```

这只是 staged workflow，不是真正的后台任务。
本轮目标是把链路补成:

```text
upload -> parse_pending -> enqueue RQ/Redis job
worker -> process_deferred_document_job(doc_id)
worker -> process_deferred_document(doc_id)
worker -> index_document_record(record)
```

### 本轮改了什么

- `pyproject.toml`
  - 新增 `redis>=5.0.0`
  - 新增 `rq>=1.16.0`
- `uv.lock`
  - 锁定 `rq==2.9.0`
  - 锁定当前可解析依赖集合
- `app/config.py`
  - 新增 `document_processing_redis_url`
  - 新增 `document_processing_queue_name`
  - 新增 job timeout / result ttl / failure ttl 配置
- `app/services/document_processing_queue.py`
  - 新增 `DocumentProcessingQueue`
  - 新增 `DocumentProcessingJobRef`
  - 新增 worker 函数 `process_deferred_document_job(doc_id)`
- `app/workers/document_processing_worker.py`
  - 新增 `python -m app.workers.document_processing_worker` 启动入口
- `app/api/file.py`
  - `/api/upload` 在 `status == parse_pending` 时投递 RQ 任务
  - 响应新增 `async_processing`
  - 响应新增 `processing_job_id`
  - 响应新增 `processing_queue`
  - 新增 `GET /api/documents/{doc_id}` 查询状态和状态证据
- `vector-database.yml`
  - 新增 `redis:7-alpine` 服务，作为 RQ 后端
- `Makefile` / `start-windows.bat` / `README.md`
  - 同步上传示例里的必填 `kb_id=aiops`
  - README 补充 worker 启动、文档状态查询和 Redis compose 说明
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `docs/oncall_rag_weknora_fusion_analysis_plan.md`
  - 同步说明: `process_deferred_document` 仍是同步业务函数，真正异步调度由 RQ worker 承担

### 关键代码形状

上传入口现在只负责接入和投递:

```python
document_record = document_ingestion_service.ingest_upload(
    filename=safe_filename,
    content=content,
    kb_id=kb_id,
)
processing_job = None
if document_record.status == DocumentStatus.PARSE_PENDING:
    processing_job = document_processing_queue.enqueue_deferred_document(
        document_record.doc_id
    )
```

worker entrypoint 复用现有业务函数:

```python
parsed_record = document_ingestion_service.process_deferred_document(doc_id)

if parsed_record.status == DocumentStatus.INDEX_PENDING:
    vector_index_service.index_document_record(parsed_record)
```

这里没有把 parser / indexer 的异常逻辑复制到队列层。
解析失败仍由 `mineru_parser_adapter` 写 `parse_failed`；
索引失败仍由 `vector_index_service` 写 `index_failed`；
RQ 只负责投递、执行和保留任务失败信号。

### 为什么用 RQ，不直接上 Celery

Celery 更适合复杂编排、分布式 worker、beat、复杂 retry policy 和监控面板。
但当前仓库真正需要的是先把“上传请求线程”和“重解析/索引重任务”分开，并且让任务不是进程内临时 background task。

RQ 的代码面更小:

- 一个 Redis 后端
- 一个 Queue adapter
- 一个 worker module
- 一个 job function

这正好符合本阶段的工程目标: 真正异步、可独立启动、可失败重试，但不把仓库带进 Celery 级配置复杂度。

### 风险和处理

1. **Redis/RQ 投递失败时文档卡住**

   本轮选择让上传在投递失败时直接返回失败，不静默吞掉异常。
   这样不会出现用户拿到 `parse_pending`，但系统里根本没有对应后台任务的假成功。
   如果只是 worker 暂时没启动，任务通常仍会留在 Redis 队列中，等 worker 启动后再消费；这属于运行侧监控/运维问题，不是 enqueue 失败。

2. **上传接口响应语义变化**

   只在 MinerU 路径新增 `async_processing/processing_job_id/processing_queue`，plain text 仍同步索引。
   旧的 `code/message/data` envelope 保持不变。

3. **依赖锁文件和本地环境不同步**

   本轮运行 `uv lock` 更新锁文件，再运行 `uv sync` 同步 `.venv`，确认 `rq 2.9.0` 和 `redis 7.1.1` 可导入。

4. **README / Makefile 仍按旧 upload API 调用**

   因为 production upload 已要求 `kb_id`，本轮把 `README.md`、`Makefile` 和 `start-windows.bat` 的上传示例都补上 `kb_id=aiops`。

### 验证方式

本轮验证命令:

```bash
.venv/bin/python -m compileall app/api/file.py app/config.py app/services/document_processing_queue.py app/workers/document_processing_worker.py tests/test_document_processing_queue.py tests/test_document_ingestion_service.py
.venv/bin/python -m unittest tests.test_document_processing_queue tests.test_document_ingestion_service tests.test_c1_kb_id_required tests.test_p1_4_regression tests.test_p2_8_gate
uv lock
uv sync
.venv/bin/python -c "import rq, redis; print('rq', rq.__version__); print('redis', redis.__version__)"
.venv/bin/python -m unittest discover tests
```

最终结果:

- compileall 通过
- targeted unittest: `Ran 24 tests ... OK`
- `rq 2.9.0` / `redis 7.1.1` 可导入
- full unittest: `Ran 202 tests ... OK`

### 面试追问怎么答

**追问: 为什么 `process_deferred_document` 不是直接改成 async 函数?**

答:

> 因为这里的“异步”不是 Python coroutine 问题，而是任务生命周期问题。MinerU 解析和向量索引是长任务，放在请求线程里或者 `async def` 里都不会天然变成可靠后台处理。我保留 `process_deferred_document(doc_id)` 作为同步业务函数，让它继续表达“怎么把 parse_pending 文档往后推进”；再用 RQ worker 包一层任务调度，解决“谁在后台执行、失败怎么留痕、上传请求怎么尽快返回”的问题。

**追问: 为什么投递失败要让上传失败，而不是先返回 `parse_pending`?**

答:

> 因为 `parse_pending` 对用户意味着系统已经接住了后续处理。如果 Redis 不通或 enqueue 失败还返回成功，就会制造一个无人消费的假等待状态。当前阶段没有单独的任务补偿扫描器，所以 fail fast 比静默挂起更诚实。等以后需要更高可用时，可以加 outbox / reconciliation job，而不是现在先假装成功。

**追问: 为什么不用 Celery?**

答:

> Celery 当然更完整，但它也会引入 broker/result backend 配置、worker 生命周期、序列化约束、重试策略和监控面。当前仓库最需要的是把 upload 和重任务拆开，并且不要用进程内 background task。RQ + Redis 能满足这个阶段的可靠队列需求，代码面只新增一个 queue adapter 和一个 worker entrypoint，风险更小。

## 2026-05-22 文档接入状态可信性修正

### 为什么现在做

上一轮已经把 MinerU 文档上传改成 `parse_pending -> RQ job -> worker 解析/索引`，但代码里还有两个会让状态不可信的边界:

1. `DocumentIngestionService.ingest_upload()` 先 `upsert_document()`，后 `original_path.write_bytes(content)`。如果原始文件写入失败，DB 会出现一个其实没有成功接入的文档 record。
2. `/api/upload` 在 `app/api/file.py` 里直接调用 `document_processing_queue.enqueue_deferred_document(...)`，但成功投递后的 `job_id` 没有写回 `DocumentRecord.status_evidence`；如果投递失败，record 也可能停在普通 `parse_pending`，排障时看不出它根本没有进入队列。

本轮目标是让 `DocumentStatus` 只表达已经被确认的事实: 文件必须先落盘才入库；复杂文档必须成功投递队列后，`parse_pending` 才带有队列证据；投递失败必须是独立的 `enqueue_failed`，不能伪装成 parser 已经跑过的 `parse_failed`。

### 改了哪些文件

- `app/models/knowledge.py`
  - `DocumentStatus` 新增 `ENQUEUE_FAILED = "enqueue_failed"`。
- `app/services/document_ingestion_service.py`
  - `original_path.write_bytes(content)` 调到 `knowledge_metadata_store.upsert_document(document_record)` 之前。
  - 非 plain-text 文档的 RQ 投递从 API 层移入 `ingest_upload()`。
  - 投递成功后才写 `parse_pending`，并在 `status_evidence` 中写入 `processing_job_id`、`processing_queue`、`enqueued_at`。
  - 投递失败时写入 `enqueue_failed`，证据包含 `queue_name`、`error_type`、`original_path`、`artifact_dir`，然后继续抛错，让 API fail fast。
- `app/api/file.py`
  - 删除直接依赖 `DocumentStatus` 和 `document_processing_queue` 的逻辑。
  - 上传响应只从 `document_record.status_evidence` 读取 `processing_job_id/processing_queue`。
- `tests/test_document_ingestion_service.py`
  - 补充写盘失败不创建 metadata record 的测试。
  - 补充队列投递失败会写 `enqueue_failed` 的测试。
  - 原 PDF 上传测试改为验证 `parse_pending` 的队列证据。
- `docs/rag_ingestion_artifact_contract.md`
  - 状态枚举补 `enqueue_failed`。
  - 失败处理表把“原始文件保存失败”和“异步任务投递失败”分开。
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
  - 同步说明投递失败会落 `enqueue_failed`，投递成功才把 job 证据写进 `parse_pending`。

### 关键代码形状

上传接入现在先落盘，再入库:

```python
original_path.parent.mkdir(parents=True, exist_ok=True)
artifact_dir.mkdir(parents=True, exist_ok=True)
original_path.write_bytes(content)
knowledge_metadata_store.upsert_document(document_record)
```

复杂文档投递成功后，`parse_pending` 不是空口状态，而是带队列证据:

```python
processing_job = document_processing_queue.enqueue_deferred_document(doc_id)
queued_record = knowledge_metadata_store.transition_document_status(
    doc_id,
    DocumentStatus.PARSE_PENDING,
    status_evidence={
        "processing_job_id": processing_job.job_id,
        "processing_queue": processing_job.queue_name,
        "enqueued_at": datetime.now().isoformat(),
    },
)
```

投递失败不再复用 `parse_failed`:

```python
knowledge_metadata_store.transition_document_status(
    doc_id,
    DocumentStatus.ENQUEUE_FAILED,
    status_detail="deferred parser job could not be enqueued",
    status_evidence={
        "queue_name": getattr(document_processing_queue, "queue_name", ""),
        "error_type": type(exc).__name__,
    },
    error_message=str(exc),
)
raise
```

### 风险和有意不做的事

1. **不新增 `upload_failed` record**

   这次选择保持 DB 不变量: `DocumentRecord` 代表已经真实落盘、进入接入流程的文档。`write_bytes` 失败时 API 返回失败，DB 不留半成品 record。以后如果需要 admin 侧查看上传失败历史，应该新增 upload attempt/audit 表，而不是把失败上传塞进文档表。

2. **不把 `enqueue_failed` 当成 `parse_failed`**

   `parse_failed` 表示 MinerU 或 parser 真实跑过并失败；`enqueue_failed` 表示还没进入解析阶段，只是 Redis/RQ 投递失败。这两个失败的重试策略和排障入口不同，所以必须拆开。

3. **不做 uploads 目录和 DB 的 reconciliation**

   如果进程在写文件途中被 SIGKILL、电源中断或 OOM，仍可能出现孤儿半文件。彻底解决需要启动扫描、上传 session 或两阶段提交，不属于这次最小可信状态修正，作为后续可靠性增强项保留。

4. **仍接受 enqueue 后写证据前的 crash 窗口**

   本轮删掉了第一次无 job evidence 的 `parse_pending` 写入，所以普通路径上 `parse_pending` 必须带 `processing_job_id`。剩余窗口是 RQ enqueue 已经返回、但第二次 `transition_document_status(PARSE_PENDING, ...)` 尚未写入时进程崩溃；这时 Redis 可能已有任务，DB 仍停在 `uploaded`。彻底消除需要 outbox / reconciliation / 两阶段提交，本轮只记录为 known limitation。

## 2026-05-22 `parse_pending` 队列证据收紧

### 为什么现在做

上一步已经把 enqueue 移到 `DocumentIngestionService.ingest_upload()`，但实现上仍保留了一次冗余状态跃迁:

```text
UPLOADED -> PARSE_PENDING(no job evidence) -> enqueue -> PARSE_PENDING(with job evidence)
```

这会制造两个 crash consistency 窗口。第一类窗口发生在第一次 `PARSE_PENDING` 写入后、enqueue 调用前；如果此时进程崩溃，DB 会停在没有 `processing_job_id` 的 `parse_pending`。这个状态没有真实队列证据，和“系统已经接住后台任务”的语义不一致。

### 改了哪些文件

- `app/services/document_ingestion_service.py`
  - 删除 enqueue 前的第一次 `transition_document_status(..., PARSE_PENDING, ...)`。
  - 非 plain-text 文档现在保持 `UPLOADED`，直到 RQ enqueue 成功后才写入 `PARSE_PENDING`。
- `tests/test_document_ingestion_service.py`
  - 增加 `RecordingKnowledgeMetadataStore`，在 MinerU 上传成功用例中确认成功路径只出现一次 `PARSE_PENDING`，且这次 transition 必须带 `processing_job_id`。
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `PROJECT_STATE.md`
  - 同步当前语义: `parse_pending` 是“已入队并带队列证据”，不是“只要文件落盘就等待解析”。

### 当前状态流

成功路径:

```text
write original
-> upsert uploaded
-> enqueue RQ job
-> transition parse_pending with processing_job_id / processing_queue / enqueued_at
```

入队失败路径:

```text
write original
-> upsert uploaded
-> enqueue fails
-> transition enqueue_failed
-> raise
```

进程在 enqueue 前崩溃时，record 停在 `uploaded`，这比没有 job evidence 的 `parse_pending` 更容易被后续 reconciliation 识别。进程在 enqueue 成功后、写 job evidence 前崩溃时，仍可能出现 Redis 有任务而 DB 仍是 `uploaded` 的窗口；这是 outbox/reconciliation 之前接受的剩余限制。

### 验证方式

本轮验证命令:

```bash
.venv/bin/python -m compileall app/models/knowledge.py app/services/document_ingestion_service.py app/api/file.py tests/test_document_ingestion_service.py
.venv/bin/python -m unittest tests.test_document_ingestion_service
.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_document_processing_queue tests.test_c1_kb_id_required tests.test_p1_4_regression tests.test_p2_8_gate
.venv/bin/python -m unittest discover tests
```

结果:

```text
Ran 6 tests ... OK
Ran 26 tests ... OK
Ran 204 tests ... OK
```

### 面试追问怎么答

**追问: 为什么这次愿意新增 `enqueue_failed`，但不新增 `upload_failed` record?**

答:

> 两个失败点的系统事实不同。写盘失败时，文档还没有成为一个可靠的系统对象，所以我让请求失败并保持 DB 干净；入队失败时，原始文件和 DocumentRecord 已经真实存在，只是后台任务没有投递成功，所以必须把这个可重试状态写到 record 上。这样 `parse_pending` 只表示“已经有后台任务证据”，`enqueue_failed` 表示“文件已接入但还没进入解析队列”。

**追问: 为什么把 enqueue 从 API 层移进 ingestion service?**

答:

> 因为 `parse_pending` 是否可信取决于两个动作是否同时成立: 状态迁移写入成功、队列任务投递成功。之前 API 负责 enqueue，ingestion service 负责状态，两个边界分开后很容易出现 job_id 没写回或失败状态不准确。现在由 ingestion service 一次性完成状态推进和投递证据写入，API 只负责 HTTP 入参和响应 envelope，职责更清楚。

## 2026-05-24 CodeGraph 开发期代码图接入

### 为什么现在做

这一步不是业务功能改造，而是给当前 checkout 增加一个本地代码关系索引。当前项目的 RAG ingestion / retrieval / citation 链路已经跨 `app/services/*`、`app/models/*`、`app/tools/*`、`tests/*` 和 `evals/*` 多层文件，后续如果要继续定位调用关系、影响范围或写源码讲解，只靠全文搜索容易漏掉类 / 方法 / 测试之间的结构关系。

### 改了哪些文件

- `.gitignore`
  - 新增 `.codegraph/`，避免本地 SQLite 索引进入版本管理。
- `PROJECT_STATE.md`
  - 在 Recent Changes 记录本次工具索引的安装、初始化、验证结果和 MCP 配置边界。

### 实际执行结果

全局 CLI 已安装:

```bash
codegraph --version
```

结果:

```text
0.9.3
```

只在主项目目录初始化:

```bash
cd "/Users/cici/oncall agent/super_biz_agent_py-release-2026-03-21"
codegraph init -i .
```

结果:

```text
Indexed 100 files
1,944 nodes, 1,834 edges
```

随后 `codegraph status .` 确认索引当前可用:

```text
Files: 102
Nodes: 1,944
Edges: 3,912
DB Size: 4.26 MB
Backend: node:sqlite
Index is up to date
```

用核心类做了一次查询验证:

```bash
codegraph query RetrievalService --limit 10
```

能定位到:

```text
app/services/retrieval_service.py:27  class RetrievalService
app/services/retrieval_service.py:32  method retrieve
tests/test_retrieval_service.py:36    class RetrievalServiceTests
```

### 当前边界

`codegraph affected app/services/retrieval_service.py` 这次没有推导出受影响测试，说明它对本仓库 Python 测试映射偏保守。后续可以把它当作代码理解和上下文构建辅助，但不能替代 `unittest discover tests`、targeted unittest 或 RAG eval。

Codex MCP 全局接入暂未写入。`codegraph install --print-config codex` 给出的配置片段是:

```toml
[mcp_servers.codegraph]
command = "codegraph"
args = ["serve", "--mcp"]
```

但写入 `/Users/cici/.codex/config.toml` 需要越过当前项目 sandbox；执行 `codegraph install --target codex --location global --yes` 时，审批服务返回 503，因此本轮没有绕过权限手写全局配置。项目内 CLI 和本地索引已经可用。

补充验证过项目级安装路径:

```bash
codegraph install --target codex --location local --yes
```

结果:

```text
Codex CLI: skipped — does not support --location=local.
CodeGraph already initialized in this project
```

也就是说，当前能稳定落地的是“全局 CLI + 项目本地索引”；Codex MCP 要真正出现在后续会话里，仍需要一次成功的全局配置写入。

### 面试追问怎么答

**追问: 为什么不把 codegraph 放到项目依赖里?**

答:

> 因为它不是运行时依赖，也不参与 FastAPI、RAG、Milvus、MinerU 或 DashScope 的业务链路。它只是开发期代码理解工具，适合放在本机全局 CLI 和项目本地 `.codegraph/` 索引里。这样能提高后续改代码前的调用链定位效率，同时不污染 `pyproject.toml`、`uv.lock` 和生产部署面。

**追问: 为什么只在这个子目录初始化，而不是在 `/Users/cici/oncall agent` 顶层初始化?**

答:

> 父目录同时挂着 `WeKnora/`、`pdf_eval/`、另一个 release、实验素材和输出目录。顶层建索引会把多套项目混在一个图里，后续问 `RetrievalService` 或 ingestion 链路时容易把无关代码也纳入上下文。当前初始化在 `super_biz_agent_py-release-2026-03-21` 这一层，索引边界和本项目开发边界一致。

## 2026-05-24: OpenViking 记忆系统适配计划文档

### 为什么现在做

用户明确要求把“本项目的记忆系统是否可以学习 OpenViking”整理成 Markdown 计划文件。当前项目已有稳定 RAG 主链路，因此本轮只做设计落档，不改运行时代码。

### 本轮变更

新增:

- `docs/openviking_memory_adaptation_plan.md`

该文档把 OpenViking 可借鉴的目录化上下文、分层上下文、session commit、检索轨迹可观测等思想，映射成本项目的旁路记忆层计划。核心边界是: 记忆系统只作为 agent 长期上下文和工作流偏好层，不能替代 `RetrievalService`、Milvus、MinerU/WeKnora 入库链路，也不能伪装成文档引用。

### 当前边界

本轮没有修改:

- `app/models/knowledge.py`
- `app/services/retrieval_service.py`
- `app/tools/knowledge_tool.py`
- Milvus collection schema
- MinerU / WeKnora ingestion path

因此现有 P1-P6 关闭边界和 citation invariance 不受影响。

### 计划的执行顺序

文档建议先做 P0-P1:

1. 冻结记忆系统与 RAG 的边界。
2. 新增独立 `MemoryRecord` / `MemoryStore`。
3. 先用 JSON-backed store 和单元测试验证证据、namespace、status、conflict 语义。
4. 不先接 agent 默认路径，不先加 embedding。

后续若 POC 证明有收益，再做 sidecar memory retrieval、memory artifact、session commit candidate、显式开关下的 agent integration。

### 验证

本轮是文档-only 变更，未运行测试。后续进入 P1 编码时，最小验证命令应从以下开始:

```bash
python -m unittest tests/test_memory_store.py
python -m unittest tests/test_retrieval_service.py
```

若接入 agent 或检索主链路，必须再跑:

```bash
python -m unittest discover tests
```

### 面试追问怎么答

**追问: 为什么学习 OpenViking 但不直接照搬?**

答:

> 因为本项目已有稳定的 RAG 主链路，包括 MinerU artifact、Milvus 检索、结构化引用和 doc-level 上下文控制。OpenViking 对本项目最有价值的是“把 agent 上下文做成分层、命名空间化、可审计的长期记忆”，而不是替换现有向量库或文档入库系统。所以计划采用旁路记忆层，先服务用户偏好、项目事实、排障经验和 workflow 记忆，再根据评测决定是否接入 agent 默认路径。

**追问: 为什么第一阶段不用向量检索?**

答:

> 记忆系统的第一风险不是召回算法，而是语义边界: 什么能写入、证据从哪里来、冲突怎么处理、记忆和文档引用怎么隔离。先用 JSON-backed store 锁定这些语义，能避免一开始就把错误记忆高效地召回出来。等 contract 稳定后，再把 embedding 当成性能和召回增强。

## 2026-05-24: OpenViking 记忆系统计划 review 后修订

> Superseded by the next section. This revision incorrectly compared the SuperBizAgent runtime memory plan with Claude Code / development-time memory. The valid project boundary is the oncall agent runtime `MemorySaver` / `session_id` / AIOps Plan-Execute-Replan path documented below.

### 为什么修订

收到 review 后，确认原计划存在一个关键问题: 它把 OpenViking 的 memory 架构当成了足够强的实现动机，但没有先证明本项目运行时 agent 存在明确痛点。考虑到当前 RAG release 已关闭且测试通过，不能把“上游有 memory 架构”当成移植 mandate。

### 本轮修订

修改:

- `docs/openviking_memory_adaptation_plan.md`

核心修订:

1. 新增 P0 前置门槛 `Gate A: Runtime Pain Evidence`，要求先证明运行时痛点，否则停止在设计文档阶段。
2. 新增 `Gate B: Relationship To Claude Code Memory`，明确 Claude Code / `~/.claude/.../memory` 是开发期 memory；本计划只允许讨论 SuperBizAgent 运行时 memory，且 P1 不做镜像、不做双向同步、不复制开发期 memory。
3. 删除 P1 数据模型里的 `confidence: float`，因为没有可操作的校准来源。
4. 将 P4 从 `Session Commit Candidate Flow` 改为 `Runtime Interaction Boundary And Candidate Flow`，明确没有运行时 session 边界就不能实现 commit。
5. 将 `wrong-memory injection rate` 从直接 gate 降级为“只有构造了错误/过期 memory 标注集后才能成为 gate”。
6. 增加 prompt-level 要求: memory 进入 LLM 前必须标注为非文档 guidance，不能被当作事实 citation。
7. 删除已被代码强制的 DashScope batch retry 作为 memory 示例，避免把代码 policy 存进 memory 后变 stale。

### 当前结论

P1 仍然不能启动，除非先完成 P0 前置门槛:

- 写清一个真实的运行时 memory 痛点；
- 证明这个痛点不能由 Claude Code memory、repo docs、request 参数、配置、代码或测试解决；
- 明确 runtime memory 的消费者是 SuperBizAgent 运行时用户，而不是 Codex/Claude 开发环境。

### 验证

本轮仍是文档-only 变更，未运行单元测试。检查重点是文档语义边界，而不是代码行为。

### 面试追问怎么答

**追问: 为什么先加 prerequisite gate?**

答:

> 因为本项目当前 RAG 主链路已经 release close-out，不能因为 OpenViking 有 memory 架构就启动移植。先要证明运行时 agent 确实存在跨会话偏好、上下文、判断规则丢失等痛点，并且这些痛点不能用现有 Claude Code memory、repo docs、配置或代码 policy 解决。否则做出来的是开发期 memory 的镜像，不是产品能力。

**追问: 为什么不和 Claude Code memory 同步?**

答:

> Claude Code memory 是开发助手的工作记忆，服务 Codex/Claude 写代码；SuperBizAgent memory 如果存在，应服务运行时 oncall 用户。两者 owner、生命周期和风险都不同。同步会把开发期反馈污染到产品运行时，还会制造双源一致性问题，所以 P1 明确不做同步。

## 2026-05-24: OpenViking 计划二次纠偏到 oncall agent 运行时代码事实

### 为什么修订

上一版修订把 Claude Code / 开发期 memory 拉进了 prerequisite gate，这个比较对象不属于 SuperBizAgent 产品运行时。用户指出项目是 oncall agent，不是 Claude 开发助手。重新核对代码后确认: 本项目真实已有的是 LangGraph `MemorySaver` 短期 checkpointer，而不是 durable cross-session memory。

### 代码事实

核对到的关键运行时代码:

- `app/services/rag_agent_service.py`:
  - 第 16 行导入 `MemorySaver`。
  - 第 103-104 行创建 `self.checkpointer = MemorySaver()`。
  - 第 173-177 行 `query(question, session_id)` 使用 `session_id`。
  - 第 202-207 行把 `session_id` 写入 LangGraph `thread_id`。
  - 第 306-369 行 `get_session_history(session_id)` 从 checkpointer 读取消息历史。
- `app/services/aiops_service.py`:
  - 第 8 行导入 `MemorySaver`。
  - 第 25 行创建 `self.checkpointer = MemorySaver()`。
  - 第 76 行 compile graph 时传入 checkpointer。
  - 第 81-85 行 `execute(user_input, session_id="default")` 已把 session 作为一等参数。
  - 第 108-112 行将 `session_id` 写入 LangGraph `thread_id`。
  - 第 159-162 行 `diagnose(session_id="default")` 复用同一 session 边界。
- `app/agent/aiops/planner.py`:
  - 第 41 行已有 `{experience_context}`。
  - 第 77-86 行 planner 会先调用 `retrieve_knowledge` 查询内部经验文档。
  - 第 110-120 行将相关经验文档注入 planner prompt。
- `app/agent/aiops/replanner.py`:
  - 第 111-242 行基于 `plan` / `past_steps` 做 continue / replan / respond 决策。
  - 第 169-187 行会把已执行步骤和剩余计划作为 replanner 输入。

### 本轮修订

修改:

- `docs/openviking_memory_adaptation_plan.md`

核心修订:

1. 删除 Claude Code memory 作为 gate 的内容。
2. 将 Gate B 改成 `Relationship To Existing Runtime MemorySaver`，明确现有层是 thread-scoped、process-local、message-history oriented 的短期 runtime memory。
3. 明确新增 durable memory 是 cross-session 层，用于 alert pattern、root cause、fix、plan template、runtime preference、runtime context。
4. P4 改为从现有 `session_id` 出发: `session_id` + `RagAgentService.get_session_history(session_id)` / AIOps graph state accessor，提取 candidate memory，而不是抽象的 session summary。
5. P5 明确 durable memory 不能替换 checkpointer；RAG chat 可作为 labeled system guidance 或 memory tool；AIOps planner 可接入现有 `{experience_context}` 附近，replanner 必须允许新证据推翻 stale memory。
6. P1 数据模型新增 `payload: dict | None`，用于 alert signature、root cause、fix、plan steps、runbook shape、preference shape，避免把 Plan-Execute-Replan 结构压扁成字符串。
7. P6 eval cases 改成 oncall 主场景: repeated alert pattern、plan reuse、replanner override、stale root cause conflict、document citation invariance。

### 当前结论

durable memory 的 gap 是真实存在的，但它要和现有 `MemorySaver` 分层:

- `MemorySaver`: 当前进程内、当前 `session_id` 的短期消息 / 图状态。
- durable oncall memory: 跨 session 的结构化经验，包括 alert pattern、plan template、root cause/fix、runtime preference/context。

后续如果进入 P1，不能再讨论 Claude Code memory；应该围绕 `MemorySaver`、`session_id`、AIOps planner/replanner 这三个运行时代码边界设计。

### 验证

本轮仍是文档-only 变更，未运行单元测试。验证方式是代码阅读 + CodeGraph context + 文档语义修订；未修改 `app/*` 运行时代码。

### 面试追问怎么答

**追问: 现有项目不是已经有 memory 了吗，为什么还要 durable memory?**

答:

> 现有 `MemorySaver` 是 LangGraph checkpointer，服务当前 `session_id` 的短期消息和图状态，而且是进程内的。它解决的是"当前会话怎么连续执行"。OpenViking-style durable memory 要解决的是另一个层级: 同类告警第二次出现时，agent 能不能复用过去验证过的 alert pattern、root cause 假设、成功 plan template，并且带 evidence 和 conflict 状态。这两个层级并存，不互相替代。

**追问: 为什么 P4 要从 `session_id` 开始?**

答:

> 因为代码里 `session_id` 已经是一等运行时边界: RAG chat 的 `query` / `query_stream` 和 AIOps 的 `execute` / `diagnose` 都把它写入 LangGraph `thread_id`。P4 如果要做 candidate memory，就应该先从这个现成边界读取消息或图状态，再提取可审计的候选记忆，而不是另造一个抽象 session 概念。

## 2026-05-24: OpenViking 计划 implementation-risk review 落档

### 为什么修订

上一个版本已经把计划拉回 oncall agent 运行时语境，但仍偏 design 层，缺少 P1-P6 实施时会撞到的 schema、accessor、评估和治理约束。收到 implementation-level review 后，本轮把这些风险前置到计划文档，避免 P1 写完后在 P2/P4/P5 返工。

### 代码事实复核

复核并写入计划的事实:

- `app/agent/aiops/planner.py` 第 27-60 行的 `planner_prompt` 确实包含 `{experience_context}`。
- `app/agent/aiops/planner.py` 第 77-90 行会先调用 `retrieve_knowledge` 查询内部经验文档。
- `app/agent/aiops/planner.py` 第 110-138 行将经验文档注入 `experience_context` 后调用 planner chain。
- `app/services/rag_agent_service.py` 第 306-369 行的 `get_session_history(session_id)` 当前直接解析 `MemorySaver` checkpoint tuple，注释中也承认返回形态可能是命名元组或普通元组；P4 不能直接依赖该内部形态，需先加 adapter。
- `app/services/aiops_service.py` 第 133-139 行内部使用 `graph.get_state(config_dict)` 获取最终状态，但当前没有对外稳定的 AIOps session/graph-state accessor。

### 本轮计划修订

修改:

- `docs/openviking_memory_adaptation_plan.md`

核心新增:

1. P0 增加 implementation blocker: 必须实地确认 planner `experience_context`、replanner override、RAG session accessor、AIOps graph-state accessor、P4 范围、candidate extraction timing。
2. P1 数据模型增加:
   - `schema_version: int`
   - `owner_id: str`，单租户初期填 `"default"`
   - `last_accessed_at`
   - `access_count`
3. P1 要求 typed payload schema，不再只写 `payload: dict | None`:
   - `AlertPatternPayload`
   - `PlanTemplatePayload`
   - `PreferencePayload`
   - `RuntimeContextPayload`
4. P2 增加 lexical recall manual gate。若中文/英文告警同义词召回不过阈值，触发 P2.5 embedding retrieval，不允许后续 P3/P4/P5 全建在 lexical-only 上。
5. P4 改为依赖 `SessionHistoryAccessor` adapter，而不是直接调用 `get_session_history` 内部解析逻辑；AIOps candidate extraction 也必须先有稳定 graph-state accessor。
6. P4 增加 review/promotion 决策门: 必须明确 manual JSON / admin endpoint / CLI / operator workflow，以及谁能把 `candidate` 提升为 `active`。
7. P6 指标拆层:
   - `retrieval_drift_bytes` 是硬门，期望为 0。
   - `answer_text_diff_rate` 是软观察，继承 P5.f3 §5.1 对 LLM 输出漂动的纪律。
8. P1 只预留 GC 字段，不在 P1 定 GC 策略；GC、review/promotion、多租户行为作为 deferred but recorded。

### 当前结论

计划现在可以用于 P0 review，但还不能直接进入 P1 编码。P0 必须先决定:

- runtime pain 是否成立；
- P4 首期覆盖 RAG chat、AIOps diagnosis，还是二者都等 accessor 到位；
- candidate extraction 是同步、异步，还是 operator 显式触发；
- typed payload schema 是否按计划直接在 P1 固化；
- P2 lexical recall 阈值和测试样本；
- review/promotion 工作流。

### 验证

本轮仍为文档-only 变更，未运行单元测试。验证方式是代码阅读 + 文档 diff 检查；未修改 `app/*`。

### 面试追问怎么答

**追问: 为什么 P1 就要定 payload schema?**

答:

> 因为 memory 的核心价值是复用结构化 oncall 经验，不只是存一段文字。alert pattern、plan template、preference 的字段完全不同；如果 P1 只放一个任意 dict，P2 排序、P4 去重/冲突检测、P5 prompt 组装都会退化成字符串猜测。所以 P1 至少要有 typed payload model，哪怕第一版字段很小。

**追问: 为什么 lexical recall 过不了就要 P2.5 embedding?**

答:

> oncall 场景里同一个告警可能有英文缩写、中文描述和服务别名，比如 `CPUHigh` / `CPU 利用率告警` / `CPU 使用率过高`。如果 lexical-only 召回不了这些同义表达，后面的 dedup、conflict detection 和 plan reuse 都会建立在错误基础上。P2 先做低成本 lexical，但必须有召回门；不过门就先补 embedding，而不是把返工拖到 P5。

## 2026-05-24: OpenViking 计划中文化与剩余风险收口

### 为什么修订

用户指出计划文档应为中文，并补充了进入开发后仍会出现的 10 条真实风险。上一版计划虽然覆盖了 design 层和部分 implementation 风险，但仍有几个关键风险没有变成 P0/P1/P4/P5/P6 的硬条件，例如 Gate A 证据可能被软化、P0 决策可能“先建后想”、JSON 并发写风险、P6 gate 可能错把 `retrieval_drift_bytes = 0` 当价值证明。

### 本轮变更

修改:

- `docs/openviking_memory_adaptation_plan.md`

本轮将计划整体改写为中文正式版，并新增:

1. P0 必须产出:
   - `docs/openviking_memory_p0_pain_evidence.md`
   - `docs/openviking_memory_p0_decision_table.md`
2. Gate A 痛点证据必须表格化记录 `case_id / occurred_at / document_kb_coverage / memory_saver_enough / why_durable_memory`，写不出就停止实现。
3. P0 决策表必须覆盖 P4 范围、candidate extraction 时机、存储层、owner_id 来源、review/promotion、P2 lexical 阈值、active memory audit 阈值、A/B rollout。
4. P1 schema 增加:
   - `candidate_review_deadline`
   - `schema_version`
   - `owner_id`
   - `last_accessed_at`
   - `access_count`
5. JSON store 明确受 P0 决策约束: 如果选择 async extraction 或存在并发 promote/review，不能用无锁 JSON 覆盖写，必须 file lock + atomic replace 或 SQLite。
6. P2 lexical recall threshold 必须跑前冻结，例如 10 条同义告警 query 至少召回 7 条 expected memory。
7. P4 必须定义 per-memory_type 的 `dedup_key` / `conflict_key` / `is_conflict`，否则不实现 conflict detection。
8. P4 review/promotion 未定义时，memory 只能保持 `candidate`，不能 active。
9. P5 要求 prompt 暴露 memory `updated_at`、`evidence_refs`、`status`，否则 replanner 无法判断 stale。
10. P5/P6 之间新增 A/B rollout 计划: off -> shadow -> limited_on -> broader_on。
11. P6 明确 `retrieval_drift_bytes = 0` 只是 sanity check，不是价值证明；真正 gate 是 repeated alert / plan reuse / stale override 等 oncall case。
12. 运营治理增加 active memory 数量阈值，超过 N 必须 audit 或告警。

### 当前结论

计划现在是中文正式版，可以进入 P0 review，但仍不能直接进入 P1 编码。P0 的核心产物不是代码，而是证据表和决策表。证据不足时应停止实现，而不是放松 Gate A。

### 验证

本轮为文档-only 变更，未运行单元测试。检查方式:

- 重新读取计划主文档；
- 检查关键风险项是否落入 P0/P1/P2/P4/P5/P6；
- 未修改 `app/*` 运行时代码。

### 面试追问怎么答

**追问: 为什么 P0 还要单独写 pain evidence 和 decision table?**

答:

> 因为 durable memory 很容易从 problem-driven 变成 architecture-driven。如果没有案例 ID、出现时间、现有 KB 是否覆盖、MemorySaver 是否够用这些证据，就无法证明要做的是产品运行时能力，而不是因为 OpenViking 有这个架构所以想移植。decision table 则保证 P1 schema 和 P4/P5 的真实产品决策对齐，避免先写 schema 后发现 async 抽取、owner_id 来源、review/promotion 都没定。

**追问: 为什么 `retrieval_drift_bytes = 0` 不能算 P6 价值证明?**

答:

> 因为 memory 层按计划不动 retrieval 路径，所以 retrieval byte drift 为 0 只能证明没有破坏现有 RAG 检索，是 sanity check。memory 的价值要靠 oncall 场景证明，比如重复告警是否召回旧根因、planner 是否复用成功计划、replanner 是否能用新证据推翻 stale memory。

## 2026-05-24: Memory 工作记录分流

### 为什么修订

用户要求 OpenViking memory 适配计划开头明确写好 record 纪律，并允许单独新建 `memory_fusion_development_record.md`。此前 memory 计划讨论暂时记录在本 RAG 融合开发记录里，但后续 memory 工作会涉及 P0 痛点证据、P1 schema、P4 candidate review、P5 prompt 注入、P6 oncall 场景评估和 rollout，已经超出 RAG / WeKnora 融合主线。

### 本轮变更

新增:

- `docs/memory_fusion_development_record.md`

修改:

- `docs/openviking_memory_adaptation_plan.md`
- `docs/rag_fusion_development_record.md`
- `AGENTS.md`

后续规则:

- RAG / WeKnora 融合工作继续记录在本文件。
- OpenViking-style durable memory 适配工作记录在 `docs/memory_fusion_development_record.md`。
- 如果某一步同时影响 RAG 和 memory 两条线，两个 record 都要写清各自受影响的部分。

### 验证

本轮为文档-only 变更，未运行单元测试。未修改 `app/*` 运行时代码。

## 2026-05-25: Vector index batch hardening

### 为什么修订

用户明确要求把 `vector_index_service.py` 的入口和数据一致性先收稳，再补批量任务。这里的问题不是单纯“支持更多后缀”，而是目录入口还在绕开正式接入链路，`index_single_file` 的默认 `default` 也还在隐式撑着旧路径；同时向量写入先删旧数据再做准备，准备阶段失败会把旧 chunk/vector 一起清掉。

### 本轮变更

修改:

- `app/services/vector_index_service.py`
- `app/services/vector_store_manager.py`
- `app/services/document_processing_queue.py`
- `app/api/file.py`
- `tests/test_vector_index_batching.py`
- `tests/test_document_processing_queue.py`
- `tests/test_parser_engine_router.py`
- `tests/test_p1_4_regression.py`
- `tests/test_p2_6_idempotent_cleanup.py`
- `tests/test_p2_8_gate.py`
- `tests/test_c1_kb_id_required.py`
- `evals/rag_retrieval/run_retrieval_eval.py`
- `evals/rag_retrieval/run_dense_baseline.py`
- `evals/rag_retrieval/run_p4_5_eval.py`
- `evals/rag_retrieval/run_p5_eval.py`
- `evals/rag_retrieval/run_p6_trigger_eval.py`
- `evals/rag_retrieval/_p6_corpus_probe.py`
- `evals/rag_retrieval/_p6_corpus_kw_probe.py`
- `evals/rag_retrieval/_p6_cross_pool_probe.py`
- `PROJECT_STATE.md`
- `task_plan.md`
- `docs/rag_ingestion_artifact_contract.md`
- `docs/p6_corpus_prep_design.md`
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `docs/weknora_oncall_agent_textbook_guide.md`

### 解决了什么风险

1. 目录索引不再只看 `*.txt` / `*.md`，而是按 `parser_engine_router.supported_file_types()` 递归扫描 `md/txt/pdf/docx/xlsx`，并通过 `DocumentIngestionService.ingest_upload(...)` 走正式接入链路。
2. `index_directory(...)` 和 `index_single_file(...)` 都要求显式 `kb_id`，把“隐式 default KB”从服务入口里收紧掉。
3. `/api/index_directory` 不再同步阻塞，而是投递目录批量索引 job，返回 batch job reference。
4. 向量写入先 `prepare_documents()` 再做旧数据清理，再 `add_prepared_documents()`，这样 embedding / payload 准备失败时不会先删掉旧 chunk/vector。
5. 同步更新教程 / contract / P6 设计说明，把旧的 `default_kb_id`、`index_single_file(..., kb_id="default")` 隐式默认、目录只扫 md/txt 等说法改成当前代码口径。

### 取舍

数据一致性只做到了“准备失败不破坏旧数据”，没有上复杂事务或跨 Milvus / metadata 的原子提交。原因是这次要的是最小可验证收口，不是一次把写入协议重做。batch 任务也先落成 RQ job reference + worker 入口，后续如果要进度百分比、暂停、取消，再往 job meta 继续长。

### 验证

最新收口运行 `.venv/bin/python -m unittest discover tests`，结果 `Ran 258 tests in 0.584s`，`OK`。额外用 `rg` 检查活文档中的旧签名和旧示例，确认 `index_single_file(...)` 示例已显式传 `kb_id`；剩余 `default_kb_id` 字样只出现在“已不再依赖 / 已移除旧口径”的说明里。

### 面试追问怎么答

**追问: 为什么目录索引不直接继续调用 `index_single_file`？**

答:

> 因为那条路是 legacy 便捷入口，适合单文件和 eval helper，不适合批量目录。目录场景真正需要的是先经过正式 ingest 路由，再按 parser 结果决定是同步 plain_text 还是异步 MinerU。直接调 `index_single_file` 会把目录批量和正式接入链路分叉。

**追问: 为什么准备失败要前移到清理之前？**

答:

> 因为最常见的失败点其实不是 Milvus delete，而是 embedding / payload 准备。先准备，失败就直接停在旧数据上；只有准备成功后才清旧数据，至少能保证“新写入没准备好时不会把旧索引先擦掉”。

## 2026-05-25: Directory ingestion ownership unification

### 为什么继续收口

上一轮已经让目录批量不再只处理 `md/txt`，但目录扫描逻辑仍然放在 `VectorIndexService.index_directory(...)` 里。用户指出这会让入口语义不统一：真正正确的模型应该是“统一入口分发 -> 自动判断文件类型 -> 走不同解析逻辑”。因此本轮把目录扫描从 vector 写入层移回 document ingestion 层。

### 本轮变更

修改:

- `app/models/ingestion.py`
- `app/models/__init__.py`
- `app/services/document_ingestion_service.py`
- `app/services/vector_index_service.py`
- `tests/test_document_ingestion_service.py`
- `tests/test_vector_index_batching.py`
- `docs/rag_ingestion_artifact_contract.md`
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `PROJECT_STATE.md`
- `task_plan.md`

### 具体做法

1. 新增 `DirectoryIngestionResult`，把目录批量结果模型从 vector 层概念里拆出来。
2. 新增 `DocumentIngestionService.ingest_directory(...)`，目录扫描按 `parser_engine_router.supported_file_types()` 找 `md/txt/pdf/docx/xlsx`，然后逐个调用 `ingest_upload(...)`。
3. `VectorIndexService.index_directory(...)` 改成兼容 wrapper，只创建 `DocumentIngestionService(upload_root=self.upload_path)` 并委托 `ingest_directory(...)`。
4. 测试明确锁住职责边界: `tests.test_document_ingestion_service` 验证目录入口真实走统一接入链路；`tests.test_vector_index_batching` 验证 vector 层只委托，不再自己枚举文件。

### 取舍

这次没有删除 `VectorIndexService.index_directory(...)`，因为当时 API worker 仍通过它调用，外部脚本也可能还在用。更稳的做法是先保留兼容面，但把真实逻辑挪走。后续 worker 直连 ingestion 的 follow-up 已在下一节完成；再下一步则把这个临时兼容面彻底删除。

### 验证

TDD 红测先确认 `DocumentIngestionService` 缺少 `ingest_directory(...)`，且 vector 层仍在自己扫目录；实现后运行 `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_vector_index_batching`，结果 `Ran 10 tests ... OK`。收口验证继续运行相关 bundle `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_vector_index_batching tests.test_document_processing_queue`，结果 `Ran 15 tests ... OK`；`.venv/bin/python -m compileall app tests` 通过；完整 `.venv/bin/python -m unittest discover tests` 结果 `Ran 259 tests in 0.633s`，`OK`。

### 面试追问怎么答

**追问: 现在到底哪个是文件入口？**

答:

> 文件接入入口是 `DocumentIngestionService.ingest_upload()` / `ingest_directory()`；索引执行入口是 `VectorIndexService.index_document_record()`。前者负责保存原件、建 `DocumentRecord`、按 parser router 分流；后者只处理已经确定 parser_engine 的文档记录，把 plain_text 或 MinerU artifacts 写入 metadata store 和 Milvus。这样入口层和写入层职责分开，目录批量也不会再绕开正式生命周期。

## 2026-05-25: Directory batch worker 直接进入 ingestion 层

### 为什么继续收一刀

上一小步已经把目录扫描逻辑移到 `DocumentIngestionService.ingest_directory(...)`，但 RQ worker 的 `process_directory_index_batch_job(...)` 仍然通过 `VectorIndexService.index_directory(...)` 这个兼容 wrapper 间接调用。这样运行结果是对的，但阅读代码时仍会产生“目录批处理是不是 vector 层入口”的歧义。

### 本轮变更

修改:

- `app/services/document_processing_queue.py`
- `tests/test_document_processing_queue.py`
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `PROJECT_STATE.md`
- `task_plan.md`
- `progress.md`
- `findings.md`

### 具体做法

1. `tests.test_document_processing_queue` 先改成 patch `document_ingestion_service.document_ingestion_service`，并断言 batch worker 调用 `ingest_directory(directory_path, kb_id=..., recursive=True)`。
2. 红测确认旧实现仍绕 `VectorIndexService.index_directory(...)`，patch 不到 ingestion 单例。
3. `process_directory_index_batch_job(...)` 改为直接 import `document_ingestion_service` 并调用 `ingest_directory(...)`。
4. 教程和 source deep dive 同步改口径: API 投递 RQ batch job 后，worker 直接进入 ingestion 层；`VectorIndexService.index_directory(...)` 只保留给旧调用面。

### 取舍

这一小步仍没有删除 `VectorIndexService.index_directory(...)`，因为要先确认 active API/worker 路径已经稳定走 ingestion。后续冗余清理确认没有运行时代码依赖后，再删除 wrapper。

### 验证

先运行单测红绿循环: `.venv/bin/python -m unittest tests.test_document_processing_queue.DocumentProcessingQueueTests.test_process_directory_index_batch_job_returns_indexing_result`，改实现前失败，改实现后通过。

随后运行相关 bundle `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_document_processing_queue tests.test_vector_index_batching`，结果 `Ran 15 tests ... OK`；`.venv/bin/python -m compileall app tests` 通过；完整 `.venv/bin/python -m unittest discover tests` 结果 `Ran 259 tests in 0.582s`，`OK`。

### 面试追问怎么答

**追问: 为什么 worker 不继续走 `VectorIndexService.index_directory()`，反正它已经是 wrapper？**

答:

> 因为 wrapper 是为了不破坏旧调用面，不应该成为新主链路。RQ worker 是正式批处理入口，它直接走 `DocumentIngestionService.ingest_directory()`，读代码时就能看出“文件进入系统”的唯一业务层在哪里；vector 层只负责 `index_document_record()` 这种已进入生命周期的记录写入。

## 2026-05-25: 删除 vector 目录兼容层冗余

### 为什么删除

用户明确要求“冗余代码该删的删”。在 worker 已经直连 `DocumentIngestionService.ingest_directory(...)` 后，`VectorIndexService.index_directory(...)` 只剩下兼容转发职责，没有主链路调用者。保留它反而会继续制造“vector 层也是文件入口”的误解。

### 本轮变更

修改:

- `app/services/vector_index_service.py`
- `tests/test_vector_index_batching.py`
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`
- `PROJECT_STATE.md`
- `task_plan.md`
- `progress.md`
- `findings.md`

### 删除了什么

1. 删除 `VectorIndexService.index_directory(...)`。
2. 删除 `IndexingResult = DirectoryIngestionResult` 兼容别名。
3. 删除 `VectorIndexService.__init__()` 里只服务目录 wrapper 的 `self.upload_path`。
4. 删除 `tests/test_vector_index_batching.py` 里只为 wrapper delegation 存在的 `FakeIngestionService` 和对应测试。

### 保留了什么

1. 保留 `/api/index_directory`，它仍是外部 API 批量入口。
2. 保留 `DocumentProcessingQueue.enqueue_directory_index_batch(...)` 和 `process_directory_index_batch_job(...)`，异步批处理能力不变。
3. 保留 `DocumentIngestionService.ingest_directory(...)`，它是唯一目录文件接入入口。
4. 保留 `VectorIndexService.index_single_file(...)`，因为 eval / legacy 单文件路径仍依赖它的 path-based stable `doc_id` 语义。

### 验证

运行相关 bundle `.venv/bin/python -m unittest tests.test_document_ingestion_service tests.test_document_processing_queue tests.test_vector_index_batching`，结果 `Ran 14 tests ... OK`；`.venv/bin/python -m compileall app tests` 通过；完整 `.venv/bin/python -m unittest discover tests` 结果 `Ran 258 tests in 0.615s`，`OK`。测试数从 259 降到 258 是预期结果，因为删除了 wrapper-only delegation case。

### 面试追问怎么答

**追问: 为什么这次敢删 `VectorIndexService.index_directory()`？**

答:

> 因为 active 主链路已经不依赖它了。API 只负责投递 batch job，worker 直接调用 `DocumentIngestionService.ingest_directory()`，单文件 legacy/eval 继续用 `index_single_file()`。删掉目录 wrapper 后，文件接入入口只剩 ingestion 层，vector 层职责就更干净: 只处理已经有 `DocumentRecord` 的索引写入。

## 2026-05-25: 删除 metadata status 旧包装

### 为什么删除

继续检查其他文件里的同类冗余后，发现 `KnowledgeMetadataStore.update_document_status(...)` 已经没有任何代码调用者。它只是把旧的状态写入口包装成 `transition_document_status(...)`，并填入固定的 legacy evidence。保留它会让状态写入看起来有两套入口，但真实主链路已经全部要求显式 `status_source/status_detail/status_evidence`。

### 本轮变更

修改:

- `app/services/knowledge_metadata_store.py`
- `PROJECT_STATE.md`
- `progress.md`
- `findings.md`
- `docs/rag_fusion_development_record.md`

### 删除了什么

1. 删除 `KnowledgeMetadataStore.update_document_status(...)`。
2. 保留 `KnowledgeMetadataStore.transition_document_status(...)` 作为唯一状态迁移写入口。
3. 不改现有业务调用点，因为 app / tests 里的状态写入本来就已经直接使用 `transition_document_status(...)`。

### 取舍

这个删除和 `VectorIndexService.index_directory(...)` 的逻辑一样: 如果一个 compatibility wrapper 已经没有主链路调用者，继续保留会制造接口噪声。这里真正需要保留的是状态证据字段和确认式状态语义，不是旧 helper 名称。

### 验证

先用 CodeGraph callers 和 `rg` 复核 `update_document_status(...)` 没有调用者；删除后运行 `.venv/bin/python -m unittest tests.test_knowledge_metadata_store tests.test_document_ingestion_service tests.test_document_processing_queue tests.test_vector_index_batching`，结果 `Ran 15 tests ... OK`。随后运行 `.venv/bin/python -m compileall app tests` 和完整 `.venv/bin/python -m unittest discover tests`，结果 `Ran 258 tests ... OK`。

### 面试追问怎么答

**追问: 为什么不继续保留 `update_document_status()` 做兼容？**

答:

> 因为它已经没有调用者了，而且它只是把缺少业务证据的旧状态写法包装成新 helper 的一层薄皮。真正需要兼容的是外部 API 行为，不是内部状态写入口；既然 app code 都直接走 `transition_document_status()`，就应该把状态写入口收成一条，避免后续排障时出现“旧 helper / 新 helper”两套语义。

## 2026-05-26: API / 目录入口继续收敛到 ingestion 和 parser router

### 为什么做

用户继续指出“如果一个作用比较大的函数已经在一个文件里写了，就应该调用它，而不是在本文件中再写一遍”。上一轮已经删除了 vector 层的目录 wrapper，这一轮继续检查上传 API 和目录扫描，发现还有两个轻量重复:

1. `app/api/file.py` 仍然自己做 `kb_id` 空值校验，而 `DocumentIngestionService.ingest_upload(...)` 和 `DocumentProcessingQueue.enqueue_directory_index_batch(...)` 已经是对应业务入口。
2. `DocumentIngestionService.ingest_directory(...)` 自己用 `path.suffix.lower().lstrip(".")` 做支持类型判断，而 parser 规则实际属于 `ParserEngineRouter`。

### 本轮变更

修改:

- `app/api/file.py`
- `app/services/parser_engine_router.py`
- `app/services/document_ingestion_service.py`
- `tests/test_parser_engine_router.py`
- `tests/test_vector_index_batching.py`
- `docs/oncall_agent_rag_enhanced_tutorial.md`
- `docs/oncall_agent_rag_source_code_deep_dive.md`

### 具体怎么收敛

1. `app/api/file.py` 不再维护 `kb_id` 业务校验。上传入口把 `filename/content/kb_id` 交给 `DocumentIngestionService.ingest_upload(...)`；目录入口把 `directory_path/kb_id` 交给 `DocumentProcessingQueue.enqueue_directory_index_batch(...)`。API 只把这些入口抛出的 `ValueError` 转成 HTTP 400。
2. `app/api/file.py` 不再在每次请求里修改共享单例 `document_ingestion_service.upload_root`，而是在模块加载时创建 `DocumentIngestionService(upload_root=UPLOAD_DIR)`，避免边缘入口用请求过程改全局状态。
3. `ParserEngineRouter` 新增 `supports_file_type(...)` 和 `supports_path(...)`，由 router 自己封装“当前规则是否支持这个类型”的判断。
4. `DocumentIngestionService.ingest_directory(...)` 改为通过 `parser_engine_router.supports_path(path)` 过滤目录文件，然后仍然逐个调用 `ingest_upload(...)`。目录入口不再自己写 suffix 归一化规则。

### 保留的边界

- API 仍然保留请求层的文件名存在性和大小限制，因为这是 HTTP 上传请求本身的约束，不属于 parser 业务路由。
- `DocumentIngestionService.ingest_upload(...)` 仍然是单文件正式接入入口；`VectorIndexService.index_single_file(...)` 仍保留 legacy/eval 的 path-based stable `doc_id` 语义。
- 目录扫描仍会先过滤支持类型，不把 `.csv` 之类文件作为失败文件逐个写入结果；真正的 parser 决策仍在 `ingest_upload(...)` 内再次确认。

### 验证

运行 `.venv/bin/python -m unittest tests.test_parser_engine_router tests.test_document_ingestion_service tests.test_c1_kb_id_required tests.test_vector_index_batching`，结果 `Ran 27 tests ... OK`。

### 面试追问怎么答

**追问: 为什么这次不把所有校验都放在 API 层？**

答:

> API 层只应该处理 HTTP 请求约束，例如文件名是否存在、文件大小是否超限；知识库 ID 是否有效、文件类型如何分发、目录里哪些文件支持，属于 ingestion / queue / parser router 的业务入口。如果 API 自己也写一遍，就会出现上传、目录、worker 三条链路各自判断的风险。这次改动把 API 收成 thin adapter，让它调用中心入口并把 `ValueError` 映射成 400，业务规则只在中心入口维护。
